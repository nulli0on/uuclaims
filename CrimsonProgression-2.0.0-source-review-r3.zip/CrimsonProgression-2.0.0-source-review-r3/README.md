# Crimson Progression Suite — reviewed source package

This package contains reviewed **source code and installation configuration** for:

- `CrimsonProgression 2.0.0`
- `UltimateClaims 1.1.0`

The Maven descriptors currently request Java 25 and Paper API `26.1.2.build.74-stable`. Those dependency coordinates and the external plugin APIs must be resolved and verified in the actual build environment.

## Verification status

This is **not a compiled release**. No Maven build, Java compilation, unit-test execution, Paper startup, or live integration test was performed during this review. The original bundled JARs were deliberately excluded from the reviewed package because their correspondence to the supplied source was not reproducibly established.

Static checks completed on 20 July 2026:

- all Java files passed delimiter, package-path, public-type/file-name, and internal-import checks;
- all source and installation YAML files parsed successfully;
- plugin main classes and declared command sets resolve to source files/registrations;
- ExcellentShop, ExcellentCrates, boss, tag, cosmetic, voucher, and product references are internally consistent;
- CrimsonProgression SQLite migrations V001–V005 apply to a fresh database;
- the V005 summoner nonce index rejects replay while allowing a properly cancelled/refunded nonce lifecycle;
- `git diff --check` reports no whitespace errors.

These checks do not prove binary compatibility with Paper, MythicMobs, ExcellentCrates, ExcellentEconomy, LuckPerms, PlaceholderAPI, WorldGuard, CelestCombat, CoreDSC, TAB, or LPCPlus.

## Main corrections

### Boss fights and summoners

- Signed summoners now receive a unique nonce in addition to the HMAC signature.
- A database uniqueness rule blocks reuse of copied signed summoners.
- Legacy unsigned summoners are disabled by default.
- Summoner escrow creation and the singleton pre-spawn fight row are now one SQLite transaction.
- Crash recovery distinguishes intact, removed, consumed, refunded, and forfeited summoners.
- Administrative reset without refund now resolves escrow terminally instead of leaving it recoverable.
- Arena configuration, world availability, spawn height, passable body space, and solid floor are validated before spawning.
- Chunk-ticket radius and cooldown values are hard-capped.
- Missing boss entities trigger bounded recovery and a durable summoner refund path.
- Pre-spawn state and the exact recovery chunk window are committed before MythicMobs is called.
- Active boss recovery follows the persisted entity UUID and a bounded moving chunk-ticket window.
- Fight finalization remains locked and retries if payout persistence fails.
- Boss definitions are disabled when their configured Mythic item or mob cannot be resolved.

### Claims

- Administrative block reductions cannot erase blocks already allocated to claims.
- Used-block totals are reconciled from stored claims at startup.
- Claim creation/deletion and the matching player balance are persisted atomically.
- Mutable Bukkit-side objects are converted to immutable snapshots before asynchronous SQLite writes.
- Large claims use a bounded overflow index instead of allocating an entry for every covered chunk.
- Rapid in-memory claim reservations close overlap races while a database commit is pending.
- Trust now applies configurable practical default flags.
- Generic interactable blocks such as buttons, levers, beds, and workstations no longer bypass protection.
- Invalid or out-of-claim stored teleport points are ignored instead of being loaded.
- Claim tools require the plugin PDC marker by default; forgeable name-only legacy matching is opt-in.
- Particle rendering and spatial-index work have hard safety limits.
- Piston and off-hand interaction checks were tightened.
- Storage paths are restricted to the plugin data directory and shutdown flush time is bounded.

### Delivery/configuration reliability

- Administrative item grants report success only after immediate inventory delivery or durable SQLite queueing.
- Offline shop deliveries are retried on player join rather than every minute.
- Ambiguous failures for non-idempotent crate-key and claim-block rewards require manual review instead of blind retry.
- Idempotent shop reward types use a configurable automatic retry limit.
- Exceptional economy payout responses require manual review; explicit rejections retry only up to a configured limit.
- Voucher journal transitions now enforce compare-and-set row counts and quarantine uncertain Bukkit inventory failures.
- Malformed voucher or boss MiniMessage text falls back locally instead of disabling startup or the boss task.
- Missing bundled configuration keys are merged without replacing administrator values, with a backup first.
- Discord delivery is disabled until explicitly enabled with a valid channel configuration.

## Mandatory setup before testing

1. Set a real `arena.world` and safe `arena.spawn` in `bosses.yml`. The included `bossarena` at `0,0,0` is a placeholder, not a production-ready arena.
2. Verify every configured MythicMobs item and mob ID against the exact installed MythicMobs version.
3. Review all files under `install/` against the exact installed versions of ExcellentShop, ExcellentCrates, ExcellentEconomy, and CoreDSC.
4. Keep `legacy-summoners.enabled: false` unless a controlled migration is required.
5. Keep Discord disabled until its bridge, permission, command, and numeric channel ID are confirmed.
6. Back up the production server and databases before migration.
7. Build from source and complete the staged runtime checklist in `docs/RUNTIME_ACCEPTANCE_CHECKLIST.md`.

## Build command

From `source/`, the intended command is:

```bash
mvn clean verify
```

This command is informational only; it was not run in this review. Do not deploy a JAR merely because packaging succeeds. Inspect dependency resolution, test output, shaded contents, plugin startup, and all external integrations first.

## Known limitation: shop idempotency

The included ExcellentShop command configuration does not provide CrimsonProgression with a stable external purchase/transaction identifier. Each command invocation therefore creates a new delivery UUID. The internal journal prevents unsafe retry of a single recorded delivery, but it cannot distinguish an ExcellentShop command that was invoked twice for the same purchase. This must be tested with the exact ExcellentShop version and changed to a stable transaction placeholder only if that version documents one.
