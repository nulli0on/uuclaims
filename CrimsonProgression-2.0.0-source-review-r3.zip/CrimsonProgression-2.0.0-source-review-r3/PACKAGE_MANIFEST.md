# Reviewed package manifest

## Included

```text
README.md
PACKAGE_MANIFEST.md
source/pom.xml
source/CrimsonProgression/**
source/UltimateClaims/**
install/ExcellentCrates/**
install/ExcellentEconomy/**
install/ExcellentShop/**
install/CoreDSC/**
install/LuckPerms/**
install/TAB/**
install/LPCPlus/**
docs/STATIC_REVIEW_REPORT.md
docs/STATIC_VALIDATION_RESULTS.txt
docs/BUILD_AND_RUNTIME_VALIDATION_REQUIRED.md
docs/RUNTIME_ACCEPTANCE_CHECKLIST.md
docs/CHANGELOG-reviewed-r3.md
```

## Explicitly excluded

```text
*.jar
*.class
**/target/**
.git/**
dist/unverified-original/**
docs/original-package-claims/**
```

The original JARs contain Maven-style metadata, but metadata alone does not prove that they were reproducibly built from the supplied source. They are not part of this reviewed source package.

## Verification boundary

Included results are static source/configuration checks only. No compiled artifact is supplied, and no statement is made that the source compiles, automated tests pass, or the plugins are production-safe. Those claims require the exact dependency repositories, a successful clean build, and staged Paper runtime testing.
