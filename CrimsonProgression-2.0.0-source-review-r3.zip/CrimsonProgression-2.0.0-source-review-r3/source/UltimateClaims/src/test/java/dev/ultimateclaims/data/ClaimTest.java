package dev.ultimateclaims.data;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ClaimTest {

    @Test
    void normalizesCoordinatesAndCalculatesInclusiveArea() {
        UUID id = UUID.randomUUID();
        UUID owner = UUID.randomUUID();
        Claim claim = new Claim(id, owner, "Owner", "spawn", "world", 20, 5, 10, -5);

        assertEquals(10, claim.getMinX());
        assertEquals(20, claim.getMaxX());
        assertEquals(-5, claim.getMinZ());
        assertEquals(5, claim.getMaxZ());
        assertEquals(11 * 11, claim.getArea());
        assertEquals(121L, claim.getAreaLong());
        assertTrue(claim.contains("world", 10, -5));
        assertTrue(claim.contains("world", 20, 5));
        assertFalse(claim.contains("World", 20, 5));
        assertFalse(claim.contains("world_nether", 10, -5));
    }

    @Test
    void areaCalculationCapsLegacyIntGetterButKeepsLongArea() {
        Claim claim = new Claim(UUID.randomUUID(), UUID.randomUUID(), "Owner", "huge",
                "world", -100_000, -100_000, 100_000, 100_000);

        assertTrue(claim.getAreaLong() > Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, claim.getArea());
    }

    @Test
    void trustedAndOutlawChecksAreStable() {
        UUID owner = UUID.randomUUID();
        UUID trusted = UUID.randomUUID();
        UUID outlaw = UUID.randomUUID();
        Claim claim = new Claim(UUID.randomUUID(), owner, "Owner", "test", "world", 0, 0, 1, 1);

        claim.addTrustedPlayer(trusted, "Trusted");
        claim.addOutlaw(outlaw);

        assertTrue(claim.isTrusted(owner));
        assertTrue(claim.isTrusted(trusted));
        assertTrue(claim.isOutlawed(outlaw));
        assertFalse(claim.isTrusted(outlaw));
    }

    @Test
    void preservesCreatedAtWhenLoadedFromDiskConstructorIsUsed() {
        long createdAt = 123456789L;
        Claim claim = new Claim(UUID.randomUUID(), UUID.randomUUID(), "Owner", "old",
                "world", 0, 0, 1, 1, createdAt);

        assertEquals(createdAt, claim.getCreatedAt());
    }
}
