package dev.ultimateclaims.index;

import dev.ultimateclaims.data.Claim;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ClaimSpatialIndexTest {
    @Test
    void indexesPositiveAndNegativeChunksAndRemovesCleanly() {
        ClaimSpatialIndex index = new ClaimSpatialIndex(4096);
        Claim claim = new Claim(UUID.randomUUID(), UUID.randomUUID(), "Owner", "wide", "world", -17, -1, 17, 17);
        index.add(claim);

        assertTrue(index.candidates("world", -17, -1).contains(claim.getId()));
        assertTrue(index.candidates("world", 0, 0).contains(claim.getId()));
        assertTrue(index.candidates("world", 17, 17).contains(claim.getId()));
        assertFalse(index.candidates("world", 64, 64).contains(claim.getId()));

        index.remove(claim);
        assertTrue(index.candidates("world", 0, 0).isEmpty());
    }

    @Test
    void areaLookupReturnsAllCandidatesWithoutDuplicates() {
        ClaimSpatialIndex index = new ClaimSpatialIndex(4096);
        Claim first = new Claim(UUID.randomUUID(), UUID.randomUUID(), "A", "one", "world", 0, 0, 31, 31);
        Claim second = new Claim(UUID.randomUUID(), UUID.randomUUID(), "B", "two", "world", 32, 0, 47, 15);
        index.add(first);
        index.add(second);

        var result = index.candidates("world", 8, 8, 40, 20);
        assertEquals(2, result.size());
        assertTrue(result.contains(first.getId()));
        assertTrue(result.contains(second.getId()));
    }
    @Test
    void veryLargeClaimUsesOverflowWithoutLosingLookupAccuracy() {
        ClaimSpatialIndex index = new ClaimSpatialIndex(64);
        Claim claim = new Claim(UUID.randomUUID(), UUID.randomUUID(), "Owner", "huge", "world",
                -100_000, -100_000, 100_000, 100_000);
        index.add(claim);

        assertTrue(index.candidates("world", 0, 0).contains(claim.getId()));
        assertTrue(index.candidates("world", 90_000, 90_000).contains(claim.getId()));
        index.remove(claim);
        assertFalse(index.candidates("world", 0, 0).contains(claim.getId()));
    }

}
