package dev.ultimateclaims.restriction;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WorldNameMatcherTest {
    @Test
    void supportsExactWildcardRegexAndCaseInsensitiveMatching() {
        WorldNameMatcher matcher = new WorldNameMatcher(false,
                List.of("bossarena"), List.of("event_*", "dungeon_?"), List.of("^season-[0-9]+$"));

        assertTrue(matcher.matches("BossArena"));
        assertTrue(matcher.matches("EVENT_SUMMER"));
        assertTrue(matcher.matches("dungeon_a"));
        assertFalse(matcher.matches("dungeon_ab"));
        assertTrue(matcher.matches("Season-12"));
        assertFalse(matcher.matches("world"));
    }

    @Test
    void rejectsInvalidRegexInsteadOfSilentlyIgnoringIt() {
        assertThrows(IllegalArgumentException.class,
                () -> new WorldNameMatcher(false, List.of(), List.of(), List.of("[broken")));
    }
}
