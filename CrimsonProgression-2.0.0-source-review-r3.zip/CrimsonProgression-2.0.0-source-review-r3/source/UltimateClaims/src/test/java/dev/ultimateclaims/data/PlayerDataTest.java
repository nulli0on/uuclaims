package dev.ultimateclaims.data;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PlayerDataTest {

    @Test
    void blockAccountingDoesNotAcceptNegativeCosts() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 100);

        assertFalse(data.hasEnoughBlocks(-1));
        assertFalse(data.deductClaimBlocks(-1));
        assertEquals(100, data.getClaimBlocks());
        assertEquals(0, data.getUsedClaimBlocks());
    }

    @Test
    void deductsOnlyWhenEnoughAvailableBlocksExist() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 100);
        data.setUsedClaimBlocks(40);

        assertTrue(data.deductClaimBlocks(60));
        assertEquals(100, data.getClaimBlocks());
        assertEquals(100, data.getUsedClaimBlocks());
        assertEquals(0, data.getAvailableBlocks());
        assertFalse(data.deductClaimBlocks(1));
    }

    @Test
    void settersClampNegativeValuesAndAddBlocksAvoidsOverflow() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 100);

        data.setClaimBlocks(-5);
        data.setUsedClaimBlocks(-10);
        assertEquals(0, data.getClaimBlocks());
        assertEquals(0, data.getUsedClaimBlocks());

        data.setClaimBlocks(Integer.MAX_VALUE - 1);
        data.addClaimBlocks(100);
        assertEquals(Integer.MAX_VALUE, data.getClaimBlocks());
    }

    @Test
    void reducingTotalBlocksPreservesAlreadyClaimedArea() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 100);
        data.setUsedClaimBlocks(80);

        assertEquals(80, data.setClaimBlocks(25));

        assertEquals(80, data.getClaimBlocks());
        assertEquals(80, data.getUsedClaimBlocks());
        assertEquals(0, data.getAvailableBlocks());
    }

    @Test
    void takingBlocksOnlyRemovesAvailableEntitlement() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 100);
        data.setUsedClaimBlocks(80);

        assertEquals(20, data.takeClaimBlocks(50));
        assertEquals(80, data.getClaimBlocks());
        assertEquals(80, data.getUsedClaimBlocks());
        assertEquals(0, data.getAvailableBlocks());
    }

    @Test
    void loadingUsedAreaRaisesAnUndersizedTotalInsteadOfDiscardingUsage() {
        PlayerData data = new PlayerData(UUID.randomUUID(), "Tester", 25);

        data.setUsedClaimBlocks(80);

        assertEquals(80, data.getClaimBlocks());
        assertEquals(80, data.getUsedClaimBlocks());
        assertEquals(0, data.getAvailableBlocks());
    }

    @Test
    void nullOrBlankPlayerNamesAreNormalized() {
        PlayerData data = new PlayerData(UUID.randomUUID(), " ", 100);
        assertEquals("Unknown", data.getPlayerName());

        data.setPlayerName(null);
        assertEquals("Unknown", data.getPlayerName());
    }
}
