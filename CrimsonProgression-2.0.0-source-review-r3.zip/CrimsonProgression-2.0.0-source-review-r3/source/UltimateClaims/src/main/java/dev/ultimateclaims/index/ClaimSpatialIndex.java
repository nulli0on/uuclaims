package dev.ultimateclaims.index;

import dev.ultimateclaims.data.Claim;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chunk-based claim lookup with a bounded indexing cost. Very large claims are
 * kept in a per-world overflow set instead of being copied into every covered
 * chunk, preventing a malformed or unlimited claim from exhausting memory.
 */
public final class ClaimSpatialIndex {
    private final Map<String, Map<Long, Set<UUID>>> index = new ConcurrentHashMap<>();
    private final Map<String, Set<UUID>> overflow = new ConcurrentHashMap<>();
    private final int maxChunksPerClaim;

    public ClaimSpatialIndex(int maxChunksPerClaim) {
        this.maxChunksPerClaim = Math.max(64, maxChunksPerClaim);
    }

    public void clear() {
        index.clear();
        overflow.clear();
    }

    public void add(Claim claim) {
        if (chunkCount(claim) > maxChunksPerClaim) {
            overflow.compute(claim.getWorld(), (world, previous) -> immutableWith(previous, claim.getId()));
            return;
        }
        Map<Long, Set<UUID>> world = index.computeIfAbsent(claim.getWorld(), ignored -> new ConcurrentHashMap<>());
        forEachChunk(claim, (x, z) -> world.compute(chunkKey(x, z),
                (key, previous) -> immutableWith(previous, claim.getId())));
    }

    public void remove(Claim claim) {
        if (chunkCount(claim) > maxChunksPerClaim) {
            overflow.computeIfPresent(claim.getWorld(),
                    (world, previous) -> immutableWithout(previous, claim.getId()));
            return;
        }
        Map<Long, Set<UUID>> world = index.get(claim.getWorld());
        if (world == null) return;
        forEachChunk(claim, (x, z) -> world.computeIfPresent(chunkKey(x, z),
                (key, previous) -> immutableWithout(previous, claim.getId())));
        if (world.isEmpty()) index.remove(claim.getWorld(), world);
    }

    public Set<UUID> candidates(String world, int blockX, int blockZ) {
        Set<UUID> result = new HashSet<>(overflow.getOrDefault(world, Set.of()));
        Map<Long, Set<UUID>> worldIndex = index.get(world);
        if (worldIndex != null) {
            result.addAll(worldIndex.getOrDefault(
                    chunkKey(Math.floorDiv(blockX, 16), Math.floorDiv(blockZ, 16)), Set.of()));
        }
        return result.isEmpty() ? Set.of() : Set.copyOf(result);
    }

    public Set<UUID> candidates(String world, int minX, int minZ, int maxX, int maxZ) {
        Set<UUID> result = new HashSet<>(overflow.getOrDefault(world, Set.of()));
        Map<Long, Set<UUID>> worldIndex = index.get(world);
        if (worldIndex == null) return result.isEmpty() ? Set.of() : Set.copyOf(result);

        int minChunkX = Math.floorDiv(Math.min(minX, maxX), 16);
        int maxChunkX = Math.floorDiv(Math.max(minX, maxX), 16);
        int minChunkZ = Math.floorDiv(Math.min(minZ, maxZ), 16);
        int maxChunkZ = Math.floorDiv(Math.max(minZ, maxZ), 16);
        long count = chunkCount(minChunkX, maxChunkX, minChunkZ, maxChunkZ);

        // A huge query is cheaper and safer as an all-claims-in-world scan. The
        // caller still performs exact geometry checks before accepting matches.
        if (count > maxChunksPerClaim) {
            for (Set<UUID> ids : worldIndex.values()) result.addAll(ids);
            return result.isEmpty() ? Set.of() : Set.copyOf(result);
        }

        for (int x = minChunkX; x <= maxChunkX; x++) {
            for (int z = minChunkZ; z <= maxChunkZ; z++) {
                result.addAll(worldIndex.getOrDefault(chunkKey(x, z), Set.of()));
            }
        }
        return result.isEmpty() ? Set.of() : Set.copyOf(result);
    }

    private static Set<UUID> immutableWith(Set<UUID> previous, UUID id) {
        Set<UUID> mutable = new HashSet<>(previous == null ? Set.of() : previous);
        mutable.add(id);
        return Set.copyOf(mutable);
    }

    private static Set<UUID> immutableWithout(Set<UUID> previous, UUID id) {
        Set<UUID> mutable = new HashSet<>(previous);
        mutable.remove(id);
        return mutable.isEmpty() ? null : Set.copyOf(mutable);
    }

    private static long chunkCount(Claim claim) {
        return chunkCount(
                Math.floorDiv(claim.getMinX(), 16), Math.floorDiv(claim.getMaxX(), 16),
                Math.floorDiv(claim.getMinZ(), 16), Math.floorDiv(claim.getMaxZ(), 16));
    }

    private static long chunkCount(int minX, int maxX, int minZ, int maxZ) {
        long width = (long) maxX - minX + 1L;
        long length = (long) maxZ - minZ + 1L;
        if (width <= 0L || length <= 0L || width > Long.MAX_VALUE / length) return Long.MAX_VALUE;
        return width * length;
    }

    private static void forEachChunk(Claim claim, ChunkConsumer consumer) {
        int minChunkX = Math.floorDiv(claim.getMinX(), 16);
        int maxChunkX = Math.floorDiv(claim.getMaxX(), 16);
        int minChunkZ = Math.floorDiv(claim.getMinZ(), 16);
        int maxChunkZ = Math.floorDiv(claim.getMaxZ(), 16);
        for (int x = minChunkX; x <= maxChunkX; x++) {
            for (int z = minChunkZ; z <= maxChunkZ; z++) consumer.accept(x, z);
        }
    }

    private static long chunkKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xffffffffL);
    }

    @FunctionalInterface
    private interface ChunkConsumer {
        void accept(int x, int z);
    }
}
