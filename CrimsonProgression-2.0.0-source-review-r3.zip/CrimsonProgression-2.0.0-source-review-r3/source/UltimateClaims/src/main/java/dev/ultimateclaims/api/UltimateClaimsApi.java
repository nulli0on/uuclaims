package dev.ultimateclaims.api;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface UltimateClaimsApi {
    CompletableFuture<Boolean> addClaimBlocks(UUID playerId, int amount);
    CompletableFuture<Integer> getAvailableClaimBlocks(UUID playerId);
}
