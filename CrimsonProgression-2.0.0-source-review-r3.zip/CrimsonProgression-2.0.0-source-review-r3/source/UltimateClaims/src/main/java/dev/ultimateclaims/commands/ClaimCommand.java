package dev.ultimateclaims.commands;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimFlag;
import dev.ultimateclaims.data.ClaimSelection;
import dev.ultimateclaims.data.PlayerData;
import dev.ultimateclaims.utils.ItemUtils;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Handles the /claim command and all its sub-commands.
 */
public class ClaimCommand implements CommandExecutor, TabCompleter {

    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_\\-]{1,32}$");

    private final UltimateClaims plugin;

    public ClaimCommand(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            MessageUtils.send(sender, msg("player-only"));
            return true;
        }

        if (args.length == 0) {
            handleTool(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create"    -> handleCreate(player, args);
            case "delete"    -> handleDelete(player, args);
            case "abandon"   -> handleAbandon(player);
            case "list"      -> handleList(player, args);
            case "info"      -> handleInfo(player, args);
            case "tp", "teleport" -> handleTeleport(player, args);
            case "setspawn"  -> handleSetSpawn(player, args);
            case "clearspawn"-> handleClearSpawn(player, args);
            case "desc"      -> handleDesc(player, args);
            case "trust"     -> handleTrust(player, args);
            case "untrust"   -> handleUntrust(player, args);
            case "trustlist" -> handleTrustList(player, args);
            case "trustflag" -> handleTrustFlag(player, args);
            case "outlaw"    -> handleOutlaw(player, args);
            case "pardon"    -> handlePardon(player, args);
            case "flags"     -> handleFlags(player, args);
            case "blocks"    -> handleBlocks(player);
            case "give"      -> handleGive(player, args);
            case "take"      -> handleTake(player, args);
            case "set"       -> handleSet(player, args);
            case "nearby"    -> handleNearby(player);
            case "reload"    -> handleReload(player);
            case "version"   -> handleVersion(player);
            case "help"      -> handleHelp(player);
            default          -> MessageUtils.send(player, msg("unknown-command"));
        }
        return true;
    }

    // ── /claim (no args) — give tool ─────────────────────────────────────────

    private void handleTool(Player player) {
        if (!player.hasPermission("ultimateclaims.claim")) {
            MessageUtils.send(player, msg("no-permission")); return;
        }

        Material mat = plugin.getClaimToolListener().getConfiguredToolMaterial();
        String name = plugin.getConfig().getString("tool.name", "&6&lClaiming Tool");
        List<String> lore = plugin.getConfig().getStringList("tool.lore");

        int existingSlot = findToolSlot(player);
        if (existingSlot >= 0) {
            ItemStack existing = player.getInventory().getItem(existingSlot);
            plugin.getClaimToolListener().markAsClaimingTool(existing);

            if (existingSlot >= 0 && existingSlot <= 8) {
                player.getInventory().setHeldItemSlot(existingSlot);
            } else {
                int freeHotbarSlot = findFreeHotbarSlot(player);
                if (freeHotbarSlot >= 0) {
                    player.getInventory().setItem(freeHotbarSlot, existing);
                    player.getInventory().setItem(existingSlot, null);
                    player.getInventory().setHeldItemSlot(freeHotbarSlot);
                }
            }

            plugin.getPlayerDataManager().enterClaimingMode(player.getUniqueId());
            MessageUtils.send(player, msg("tool-already-have"));
            return;
        }

        int freeSlot = player.getInventory().firstEmpty();
        if (freeSlot < 0) {
            MessageUtils.send(player, msg("inventory-full"));
            return;
        }

        ItemStack tool = ItemUtils.build(mat, name, lore);
        plugin.getClaimToolListener().markAsClaimingTool(tool);
        player.getInventory().setItem(freeSlot, tool);
        if (freeSlot >= 0 && freeSlot <= 8) {
            player.getInventory().setHeldItemSlot(freeSlot);
        }
        plugin.getPlayerDataManager().enterClaimingMode(player.getUniqueId());
        MessageUtils.send(player, msg("tool-given"));
    }

    private int findToolSlot(Player player) {
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            if (plugin.getClaimToolListener().isClaimingTool(player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    private int findFreeHotbarSlot(Player player) {
        for (int i = 0; i <= 8; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item == null || item.getType() == Material.AIR) return i;
        }
        return -1;
    }

    // ── /claim create <name> ─────────────────────────────────────────────────

    private void handleCreate(Player player, String[] args) {
        if (!player.hasPermission("ultimateclaims.claim")) {
            MessageUtils.send(player, msg("no-permission")); return;
        }
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim create <name>"); return; }

        String name = args[1];
        if (!NAME_PATTERN.matcher(name).matches()) {
            MessageUtils.send(player, msg("claim-name-invalid")); return;
        }

        UUID uuid = player.getUniqueId();
        if (!plugin.getPlayerDataManager().hasCompleteSelection(uuid)) {
            MessageUtils.send(player, msg("selection-incomplete")); return;
        }

        ClaimSelection sel = plugin.getPlayerDataManager().getSelection(uuid);
        String world = sel.getWorld();

        int minX = Math.min(sel.getPos1X(), sel.getPos2X());
        int maxX = Math.max(sel.getPos1X(), sel.getPos2X());
        int minZ = Math.min(sel.getPos1Z(), sel.getPos2Z());
        int maxZ = Math.max(sel.getPos1Z(), sel.getPos2Z());

        var restriction = plugin.getRestrictionService().canCreate(player, world, minX, minZ, maxX, maxZ);
        if (!restriction.allowed()) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-restricted"),
                    "reason", restriction.reason(), "detail", restriction.detail()));
            return;
        }

        long areaLong = sel.getAreaLong();
        long widthLong = sel.getWidthLong();
        long lengthLong = sel.getLengthLong();
        if (areaLong > Integer.MAX_VALUE) {
            MessageUtils.send(player, MessageUtils.format(msg("area-too-large"),
                    "max", String.valueOf(Integer.MAX_VALUE)));
            return;
        }
        int area = (int) areaLong;
        int width = (int) widthLong;
        int length = (int) lengthLong;

        // Size validations
        int minSize = plugin.getConfig().getInt("min-claim-size", 9);
        long maxSize = plugin.getConfig().getLong("max-claim-size", 250000L);
        int minSide = plugin.getConfig().getInt("min-claim-side", 3);

        if (area < minSize) {
            MessageUtils.send(player, MessageUtils.format(msg("area-too-small"), "min", String.valueOf(minSize))); return;
        }
        if (maxSize > 0 && areaLong > maxSize) {
            MessageUtils.send(player, MessageUtils.format(msg("area-too-large"), "max", String.valueOf(maxSize))); return;
        }
        if (width < minSide || length < minSide) {
            MessageUtils.send(player, MessageUtils.format(msg("side-too-short"), "min", String.valueOf(minSide))); return;
        }

        // Overlap check
        if (plugin.getClaimManager().overlapsExistingClaim(world, minX, minZ, maxX, maxZ)) {
            MessageUtils.send(player, msg("overlaps-claim")); return;
        }

        // Max claims check
        int maxClaims = plugin.getConfig().getInt("max-claims-per-player", 10);
        if (maxClaims >= 0 && plugin.getClaimManager().getClaimsByOwner(uuid).size() >= maxClaims
                && !player.hasPermission("ultimateclaims.admin")) {
            MessageUtils.send(player, MessageUtils.format(msg("max-claims-reached"), "max", String.valueOf(maxClaims))); return;
        }

        // Name uniqueness
        if (plugin.getClaimManager().getClaimByName(uuid, name) != null) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-name-taken"), "name", name)); return;
        }

        // Block check
        PlayerData data = plugin.getPlayerDataManager().getOrCreate(player);
        if (!data.hasEnoughBlocks(area)) {
            MessageUtils.send(player, MessageUtils.format(msg("not-enough-blocks"),
                    "needed", String.valueOf(area), "available", String.valueOf(data.getAvailableBlocks())));
            return;
        }

        // Persist first; only acknowledge and clear the selection after the atomic commit succeeds.
        plugin.getClaimManager().createClaim(uuid, player.getName(), name, world, minX, minZ, maxX, maxZ)
                .whenComplete((claim, error) -> {
                    if (!player.isOnline()) return;
                    if (error != null || claim == null) {
                        plugin.getLogger().log(java.util.logging.Level.WARNING,
                                "Claim creation failed for " + player.getUniqueId(), error);
                        MessageUtils.send(player, msg("claim-create-failed"));
                        return;
                    }
                    plugin.getPlayerDataManager().clearSelection(uuid);
                    plugin.getPlayerDataManager().leaveClaimingMode(uuid);
                    plugin.getClaimToolListener().stopSelectionParticles(uuid);
                    MessageUtils.send(player, MessageUtils.format(msg("claim-created"),
                            "name", name, "area", String.valueOf(area)));
                    plugin.getClaimToolListener().showClaimBorder(player, claim);
                });
    }

    // ── /claim delete <name> ─────────────────────────────────────────────────

    private void handleDelete(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim delete <name>"); return; }
        String name = args[1];
        Claim claim = plugin.getClaimManager().getClaimByName(player.getUniqueId(), name);

        if (claim == null) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-not-found"), "name", name)); return;
        }

        PlayerData data = plugin.getPlayerDataManager().getOrCreate(player);
        int timeout = plugin.getConfig().getInt("confirmation-timeout", 10);

        if (data.hasPendingDelete() && name.equalsIgnoreCase(data.getPendingDeleteClaim())) {
            // Confirmed. The player is only notified after the atomic DB transaction commits.
            plugin.getClaimManager().deleteClaim(claim).whenComplete((area, error) -> {
                if (!player.isOnline()) return;
                if (error != null) {
                    plugin.getLogger().log(java.util.logging.Level.WARNING,
                            "Claim deletion failed for " + claim.getId(), error);
                    MessageUtils.send(player, msg("claim-delete-failed"));
                    return;
                }
                data.clearPendingDelete();
                MessageUtils.send(player, MessageUtils.format(msg("claim-deleted"),
                        "name", name, "area", String.valueOf(area)));
            });
        } else {
            data.setPendingDelete(name, timeout);
            MessageUtils.send(player, MessageUtils.format(msg("delete-confirm"),
                    "name", name, "timeout", String.valueOf(timeout), "area", String.valueOf(claim.getArea())));
        }
    }

    // ── /claim abandon ───────────────────────────────────────────────────────

    private void handleAbandon(Player player) {
        List<Claim> claims = plugin.getClaimManager().getClaimsByOwner(player.getUniqueId());
        if (claims.isEmpty()) { MessageUtils.send(player, msg("no-claims")); return; }

        PlayerData data = plugin.getPlayerDataManager().getOrCreate(player);
        int timeout = plugin.getConfig().getInt("confirmation-timeout", 10);

        if (data.hasPendingAbandon()) {
            List<Claim> deleting = new ArrayList<>(claims);
            plugin.getClaimManager().deleteClaims(deleting).whenComplete((totalArea, error) -> {
                if (!player.isOnline()) return;
                if (error != null) {
                    plugin.getLogger().log(java.util.logging.Level.WARNING,
                            "Bulk claim deletion failed for " + player.getUniqueId(), error);
                    MessageUtils.send(player, msg("claim-delete-failed"));
                    return;
                }
                data.clearPendingAbandon();
                MessageUtils.send(player, MessageUtils.format(msg("abandon-all"),
                        "count", String.valueOf(deleting.size()), "area", String.valueOf(totalArea)));
            });
        } else {
            data.setPendingAbandon(timeout);
            MessageUtils.send(player, MessageUtils.format(msg("abandon-confirm"),
                    "timeout", String.valueOf(timeout)));
        }
    }

    // ── /claim list [player] ─────────────────────────────────────────────────

    private void handleList(Player player, String[] args) {
        UUID target = player.getUniqueId();
        String targetName = player.getName();

        if (args.length >= 2 && player.hasPermission("ultimateclaims.list.other")) {
            OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(args[1]);
            if (op == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }
            target = op.getUniqueId();
            targetName = op.getName() != null ? op.getName() : args[1];
        }

        List<Claim> claims = plugin.getClaimManager().getClaimsByOwner(target);
        int max = plugin.getConfig().getInt("max-claims-per-player", 10);
        String maxStr = max < 0 ? "∞" : String.valueOf(max);

        if (claims.isEmpty()) {
            MessageUtils.send(player, msg("claim-list-none")); return;
        }

        MessageUtils.send(player, MessageUtils.format(msg("claim-list-header"),
                "count", String.valueOf(claims.size()), "max", maxStr));
        for (Claim c : claims) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-list-entry"),
                    "name", c.getName(), "width", String.valueOf(c.getWidth()),
                    "length", String.valueOf(c.getLength()), "world", c.getWorld()));
        }
    }

    // ── /claim info [name] ───────────────────────────────────────────────────

    private void handleInfo(Player player, String[] args) {
        Claim claim;
        if (args.length >= 2) {
            claim = plugin.getClaimManager().getClaimByName(player.getUniqueId(), args[1]);
            if (claim == null && player.hasPermission("ultimateclaims.info.other")) {
                // Try admin lookup: /claim info OwnerName:ClaimName
                String[] parts = args[1].split(":", 2);
                if (parts.length == 2) {
                    claim = plugin.getClaimManager().getClaimByOwnerAndName(parts[0], parts[1]);
                }
            }
        } else {
            claim = plugin.getClaimManager().getClaimAt(player.getLocation());
        }

        if (claim == null) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-not-found"),
                    "name", args.length >= 2 ? args[1] : "here"));
            return;
        }

        MessageUtils.send(player, MessageUtils.format(msg("claim-info-header"), "name", claim.getName()));
        MessageUtils.send(player, MessageUtils.format(msg("claim-info-owner"), "owner", claim.getOwnerName()));
        MessageUtils.send(player, MessageUtils.format(msg("claim-info-world"), "world", claim.getWorld()));
        MessageUtils.send(player, MessageUtils.format(msg("claim-info-size"),
                "width", String.valueOf(claim.getWidth()),
                "length", String.valueOf(claim.getLength()),
                "area", String.valueOf(claim.getArea())));
        MessageUtils.send(player, MessageUtils.format(msg("claim-info-corner"),
                "x1", String.valueOf(claim.getMinX()), "z1", String.valueOf(claim.getMinZ()),
                "x2", String.valueOf(claim.getMaxX()), "z2", String.valueOf(claim.getMaxZ())));
        if (claim.getDescription() != null && !claim.getDescription().isBlank()) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-info-desc"), "desc", claim.getDescription()));
        }

        // Trusted players
        String trustedStr = claim.getTrustedPlayers().values().isEmpty() ? "None" :
                String.join(", ", claim.getTrustedPlayers().values());
        MessageUtils.send(player, MessageUtils.format(msg("claim-info-trusted"), "trusted", trustedStr));

        // Outlawed
        if (!claim.getOutlawedPlayers().isEmpty()) {
            List<String> outlawNames = new ArrayList<>();
            for (UUID uid : claim.getOutlawedPlayers()) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(uid);
                outlawNames.add(op.getName() != null ? op.getName() : uid.toString().substring(0, 8));
            }
            MessageUtils.send(player, MessageUtils.format(msg("claim-info-outlawed"),
                    "outlawed", String.join(", ", outlawNames)));
        }
        MessageUtils.send(player, msg("claim-info-footer"));
    }

    // ── /claim tp <name> ─────────────────────────────────────────────────────

    private void handleTeleport(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim tp <name>"); return; }
        String name = args[1];

        UUID ownerUuid = player.getUniqueId();
        Claim claim = plugin.getClaimManager().getClaimByName(ownerUuid, name);

        // Admin can tp to others: /claim tp Owner:Name
        if (claim == null && player.hasPermission("ultimateclaims.tp.other")) {
            String[] parts = name.split(":", 2);
            if (parts.length == 2) {
                claim = plugin.getClaimManager().getClaimByOwnerAndName(parts[0], parts[1]);
            }
        }

        if (claim == null) {
            MessageUtils.send(player, MessageUtils.format(msg("claim-not-found"), "name", name)); return;
        }

        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("ultimateclaims.tp.other")) {
            MessageUtils.send(player, msg("not-your-claim")); return;
        }

        Location dest;
        if (claim.hasSpawnPoint()) {
            org.bukkit.World w = Bukkit.getWorld(claim.getSpawnWorld());
            if (w == null) w = Bukkit.getWorld(claim.getWorld());
            if (w == null) { MessageUtils.send(player, "&cWorld not loaded."); return; }
            dest = new Location(w, claim.getSpawnX(), claim.getSpawnY(), claim.getSpawnZ(),
                    claim.getSpawnYaw(), claim.getSpawnPitch());
        } else {
            // Teleport to centre of claim, safe Y
            org.bukkit.World w = Bukkit.getWorld(claim.getWorld());
            if (w == null) { MessageUtils.send(player, "&cWorld not loaded."); return; }
            double cx = (claim.getMinX() + claim.getMaxX()) / 2.0 + 0.5;
            double cz = (claim.getMinZ() + claim.getMaxZ()) / 2.0 + 0.5;
            int safeY = w.getHighestBlockYAt((int) cx, (int) cz) + 1;
            dest = new Location(w, cx, safeY, cz);
            MessageUtils.send(player, msg("no-spawn-set"));
        }

        player.teleport(dest);
        MessageUtils.send(player, MessageUtils.format(msg("teleport-success"), "name", claim.getName()));
    }

    // ── /claim setspawn <name> ────────────────────────────────────────────────

    private void handleSetSpawn(Player player, String[] args) {
        Claim claim = getOwnedClaimFromArgs(player, args, 1);
        if (claim == null) return;
        Location loc = player.getLocation();
        if (!claim.contains(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockZ())) {
            MessageUtils.send(player, msg("spawn-outside-claim"));
            return;
        }
        claim.setSpawnPoint(loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ(),
                loc.getYaw(), loc.getPitch());
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("spawn-set"), "name", claim.getName()));
    }

    // ── /claim clearspawn <name> ──────────────────────────────────────────────

    private void handleClearSpawn(Player player, String[] args) {
        Claim claim = getOwnedClaimFromArgs(player, args, 1);
        if (claim == null) return;
        claim.clearSpawnPoint();
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("spawn-cleared"), "name", claim.getName()));
    }

    // ── /claim desc set/remove <name> [desc...] ──────────────────────────────

    private void handleDesc(Player player, String[] args) {
        if (args.length < 3) { MessageUtils.send(player, "&cUsage: /claim desc <set|remove> <name> [desc...]"); return; }
        String action = args[1].toLowerCase();
        String claimName = args[2];

        Claim claim = plugin.getClaimManager().getClaimByName(player.getUniqueId(), claimName);
        if (claim == null) { MessageUtils.send(player, MessageUtils.format(msg("claim-not-found"), "name", claimName)); return; }

        if (!claim.getOwner().equals(player.getUniqueId())) {
            MessageUtils.send(player, msg("not-your-claim")); return;
        }

        if (action.equals("remove")) {
            claim.setDescription(null);
            plugin.getClaimManager().saveClaim(claim);
            MessageUtils.send(player, MessageUtils.format(msg("description-removed"), "name", claim.getName()));
        } else if (action.equals("set")) {
            if (args.length < 4) { MessageUtils.send(player, "&cProvide a description."); return; }
            String desc = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
            claim.setDescription(desc);
            plugin.getClaimManager().saveClaim(claim);
            MessageUtils.send(player, MessageUtils.format(msg("description-set"),
                    "name", claim.getName(), "desc", desc));
        } else {
            MessageUtils.send(player, "&cUse 'set' or 'remove'.");
        }
    }

    // ── /claim trust <player> [claim] ────────────────────────────────────────

    private void handleTrust(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim trust <player> [claimName]"); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[1]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }

        if (target.getUniqueId().equals(player.getUniqueId())) {
            MessageUtils.send(player, msg("trust-self")); return;
        }

        Claim claim = getOwnedClaimFromArgs(player, args, 2);
        if (claim == null) return;

        if (claim.isTrusted(target.getUniqueId())) {
            MessageUtils.send(player, MessageUtils.format(msg("already-trusted"),
                    "player", target.getName(), "claim", claim.getName())); return;
        }

        String tName = target.getName() != null ? target.getName() : args[1];
        claim.addTrustedPlayer(target.getUniqueId(), tName);
        for (String configuredFlag : plugin.getConfig().getStringList("trust.default-flags")) {
            ClaimFlag flag = ClaimFlag.fromName(configuredFlag);
            if (flag != null) claim.setTrustedPlayerFlag(target.getUniqueId(), flag, true);
            else plugin.getLogger().warning("Ignoring unknown trust.default-flags entry: " + configuredFlag);
        }
        plugin.getWorldGuardIntegration().addMember(claim, target.getUniqueId());
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("trust-added"),
                "player", tName, "claim", claim.getName()));
    }

    // ── /claim untrust <player> [claim] ──────────────────────────────────────

    private void handleUntrust(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim untrust <player> [claimName]"); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[1]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }

        Claim claim = getOwnedClaimFromArgs(player, args, 2);
        if (claim == null) return;

        if (!claim.isTrusted(target.getUniqueId())) {
            MessageUtils.send(player, MessageUtils.format(msg("player-not-trusted"),
                    "player", target.getName(), "claim", claim.getName())); return;
        }

        claim.removeTrustedPlayer(target.getUniqueId());
        plugin.getWorldGuardIntegration().removeMember(claim, target.getUniqueId());
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("trust-removed"),
                "player", target.getName() != null ? target.getName() : args[1],
                "claim", claim.getName()));
    }

    // ── /claim trustlist [claim] ──────────────────────────────────────────────

    private void handleTrustList(Player player, String[] args) {
        Claim claim = getOwnedClaimFromArgs(player, args, 1);
        if (claim == null) return;

        Map<UUID, String> trusted = claim.getTrustedPlayers();
        if (trusted.isEmpty()) {
            MessageUtils.send(player, MessageUtils.format(msg("trust-list-none"), "claim", claim.getName())); return;
        }
        MessageUtils.send(player, MessageUtils.format(msg("trust-list-header"), "claim", claim.getName()));
        for (String name : trusted.values()) {
            MessageUtils.send(player, MessageUtils.format(msg("trust-list-entry"), "player", name));
        }
    }

    // ── /claim trustflag <player> <flag> <on|off> [claim] ───────────────────

    private void handleTrustFlag(Player player, String[] args) {
        if (args.length < 4) {
            MessageUtils.send(player, "&cUsage: /claim trustflag <player> <flag> <on|off> [claimName]"); return;
        }

        OfflinePlayer target = resolveOfflinePlayer(args[1]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }

        ClaimFlag flag = ClaimFlag.fromName(args[2]);
        if (flag == null) { MessageUtils.send(player, "&cUnknown flag: " + args[2]); return; }

        boolean allowed;
        if (args[3].equalsIgnoreCase("on") || args[3].equalsIgnoreCase("true")) {
            allowed = true;
        } else if (args[3].equalsIgnoreCase("off") || args[3].equalsIgnoreCase("false")) {
            allowed = false;
        } else {
            MessageUtils.send(player, "&cUse 'on' or 'off'.");
            return;
        }

        Claim claim = getOwnedClaimFromArgs(player, args, 4);
        if (claim == null) return;

        if (!claim.isTrusted(target.getUniqueId())) {
            MessageUtils.send(player, MessageUtils.format(msg("player-not-trusted"),
                    "player", target.getName(), "claim", claim.getName())); return;
        }

        claim.setTrustedPlayerFlag(target.getUniqueId(), flag, allowed);
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("trust-flag-set"),
                "flag", flag.getDisplayName(), "value", allowed ? "ON" : "OFF",
                "player", target.getName() != null ? target.getName() : args[1],
                "claim", claim.getName()));
    }

    // ── /claim outlaw <player> [claim] ────────────────────────────────────────

    private void handleOutlaw(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim outlaw <player> [claimName]"); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[1]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }

        if (target.getUniqueId().equals(player.getUniqueId())) {
            MessageUtils.send(player, msg("outlaw-self")); return;
        }

        Claim claim = getOwnedClaimFromArgs(player, args, 2);
        if (claim == null) return;

        if (claim.isOutlawed(target.getUniqueId())) {
            MessageUtils.send(player, MessageUtils.format(msg("already-outlawed"),
                    "player", target.getName(), "claim", claim.getName())); return;
        }

        claim.addOutlaw(target.getUniqueId());
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("outlaw-added"),
                "player", target.getName() != null ? target.getName() : args[1],
                "claim", claim.getName()));
    }

    // ── /claim pardon <player> [claim] ────────────────────────────────────────

    private void handlePardon(Player player, String[] args) {
        if (args.length < 2) { MessageUtils.send(player, "&cUsage: /claim pardon <player> [claimName]"); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[1]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[1])); return; }

        Claim claim = getOwnedClaimFromArgs(player, args, 2);
        if (claim == null) return;

        if (!claim.isOutlawed(target.getUniqueId())) {
            MessageUtils.send(player, MessageUtils.format(msg("not-outlawed"),
                    "player", target.getName(), "claim", claim.getName())); return;
        }

        claim.removeOutlaw(target.getUniqueId());
        plugin.getClaimManager().saveClaim(claim);
        MessageUtils.send(player, MessageUtils.format(msg("outlaw-removed"),
                "player", target.getName() != null ? target.getName() : args[1],
                "claim", claim.getName()));
    }

    // ── /claim flags [name] ───────────────────────────────────────────────────

    private void handleFlags(Player player, String[] args) {
        Claim claim;
        if (args.length >= 2) {
            claim = plugin.getClaimManager().getClaimByName(player.getUniqueId(), args[1]);
            if (claim == null && player.hasPermission("ultimateclaims.admin")) {
                String[] parts = args[1].split(":", 2);
                if (parts.length == 2) claim = plugin.getClaimManager().getClaimByOwnerAndName(parts[0], parts[1]);
            }
        } else {
            claim = plugin.getClaimManager().getClaimAt(player.getLocation());
        }

        if (claim == null) {
            MessageUtils.send(player, msg("stand-in-claim")); return;
        }

        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("ultimateclaims.admin")) {
            MessageUtils.send(player, msg("not-your-claim")); return;
        }

        MessageUtils.send(player, MessageUtils.format(msg("flags-opened"), "name", claim.getName()));
        plugin.getFlagsGUI().open(player, claim);
    }

    // ── /claim blocks ─────────────────────────────────────────────────────────

    private void handleBlocks(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getOrCreate(player);
        MessageUtils.send(player, MessageUtils.format(msg("your-blocks"),
                "available", String.valueOf(data.getAvailableBlocks()),
                "total", String.valueOf(data.getClaimBlocks()),
                "used", String.valueOf(data.getUsedClaimBlocks())));
    }

    // ── /claim give <amount> <player> ─────────────────────────────────────────

    private void handleGive(Player player, String[] args) {
        if (!player.hasPermission("ultimateclaims.give")) { MessageUtils.send(player, msg("no-permission")); return; }
        if (args.length < 3) { MessageUtils.send(player, "&cUsage: /claim give <amount> <player>"); return; }

        int amount;
        try { amount = Integer.parseInt(args[1]); } catch (NumberFormatException e) {
            MessageUtils.send(player, MessageUtils.format(msg("invalid-number"), "input", args[1])); return;
        }
        if (amount <= 0) { MessageUtils.send(player, msg("must-be-positive")); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[2]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[2])); return; }

        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target.getUniqueId());
        if (data == null) {
            int def = plugin.getConfig().getInt("default-claim-blocks", 100);
            data = new PlayerData(target.getUniqueId(), target.getName() != null ? target.getName() : args[2], def);
            plugin.getPlayerDataManager().addPlayerDataDirectly(data);
        }
        data.addClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);

        MessageUtils.send(player, MessageUtils.format(msg("blocks-given"),
                "amount", String.valueOf(amount),
                "player", target.getName() != null ? target.getName() : args[2],
                "total", String.valueOf(data.getClaimBlocks())));
    }

    // ── /claim take <amount> <player> ─────────────────────────────────────────

    private void handleTake(Player player, String[] args) {
        if (!player.hasPermission("ultimateclaims.take")) { MessageUtils.send(player, msg("no-permission")); return; }
        if (args.length < 3) { MessageUtils.send(player, "&cUsage: /claim take <amount> <player>"); return; }

        int amount;
        try { amount = Integer.parseInt(args[1]); } catch (NumberFormatException e) {
            MessageUtils.send(player, MessageUtils.format(msg("invalid-number"), "input", args[1])); return;
        }
        if (amount <= 0) { MessageUtils.send(player, msg("must-be-positive")); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[2]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[2])); return; }

        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target.getUniqueId());
        if (data == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[2])); return; }

        int removed = data.takeClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);

        MessageUtils.send(player, MessageUtils.format(msg("blocks-taken"),
                "amount", String.valueOf(removed),
                "player", target.getName() != null ? target.getName() : args[2],
                "total", String.valueOf(data.getClaimBlocks())));
    }

    // ── /claim set <amount> <player> ──────────────────────────────────────────

    private void handleSet(Player player, String[] args) {
        if (!player.hasPermission("ultimateclaims.give")) { MessageUtils.send(player, msg("no-permission")); return; }
        if (args.length < 3) { MessageUtils.send(player, "&cUsage: /claim set <amount> <player>"); return; }

        int amount;
        try { amount = Integer.parseInt(args[1]); } catch (NumberFormatException e) {
            MessageUtils.send(player, MessageUtils.format(msg("invalid-number"), "input", args[1])); return;
        }
        if (amount < 0) { MessageUtils.send(player, msg("must-be-positive")); return; }

        OfflinePlayer target = resolveOfflinePlayer(args[2]);
        if (target == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[2])); return; }

        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target.getUniqueId());
        if (data == null) { MessageUtils.send(player, MessageUtils.format(msg("player-not-found"), "player", args[2])); return; }

        int applied = data.setClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);

        MessageUtils.send(player, MessageUtils.format(msg("blocks-set"),
                "player", target.getName() != null ? target.getName() : args[2],
                "amount", String.valueOf(applied)));
    }

    // ── /claim nearby ─────────────────────────────────────────────────────────

    private void handleNearby(Player player) {
        int radius = plugin.getConfig().getInt("nearby-radius", 100);
        List<Claim> nearby = plugin.getClaimManager().getNearbyClaims(player.getLocation(), radius);
        if (nearby.isEmpty()) { MessageUtils.send(player, msg("nearby-none")); return; }

        MessageUtils.send(player, msg("nearby-header"));
        for (Claim c : nearby) {
            // Calculate distance to nearest edge
            int nearX = Math.max(c.getMinX(), Math.min(player.getLocation().getBlockX(), c.getMaxX()));
            int nearZ = Math.max(c.getMinZ(), Math.min(player.getLocation().getBlockZ(), c.getMaxZ()));
            int dist = (int) Math.sqrt(Math.pow(player.getLocation().getBlockX() - nearX, 2)
                    + Math.pow(player.getLocation().getBlockZ() - nearZ, 2));
            MessageUtils.send(player, MessageUtils.format(msg("nearby-entry"),
                    "name", c.getName(), "owner", c.getOwnerName(), "dist", String.valueOf(dist)));
        }
    }

    // ── /claim reload ─────────────────────────────────────────────────────────

    private void handleReload(Player player) {
        if (!player.hasPermission("ultimateclaims.reload")) { MessageUtils.send(player, msg("no-permission")); return; }
        int synced = plugin.reloadAllConfigs();
        MessageUtils.send(player, MessageUtils.format(msg("reload-success"), "claims", String.valueOf(synced)));
    }

    // ── /claim version ────────────────────────────────────────────────────────

    private void handleVersion(Player player) {
        MessageUtils.send(player, "&8[&b&lUltimateClaims&8] &7Version &f"
                + plugin.getDescription().getVersion()
                + " &7by &bUltimateClaims Team");
    }

    // ── /claim help ───────────────────────────────────────────────────────────

    private void handleHelp(Player player) {
        MessageUtils.send(player, msg("help-header"));
        for (String line : plugin.getMessages().getStringList("help-lines")) {
            MessageUtils.send(player, line);
        }
        MessageUtils.send(player, msg("help-footer"));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Resolves a claim the player owns.
     * If argIndex is within args, uses that name; otherwise uses the claim at their feet.
     */
    private Claim getOwnedClaimFromArgs(Player player, String[] args, int argIndex) {
        Claim claim;
        if (args.length > argIndex) {
            claim = plugin.getClaimManager().getClaimByName(player.getUniqueId(), args[argIndex]);
            if (claim == null) {
                MessageUtils.send(player, MessageUtils.format(msg("claim-not-found"), "name", args[argIndex]));
                return null;
            }
        } else {
            claim = plugin.getClaimManager().getClaimAt(player.getLocation());
            if (claim == null) {
                MessageUtils.send(player, msg("stand-in-claim"));
                return null;
            }
        }

        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("ultimateclaims.admin")) {
            MessageUtils.send(player, msg("not-your-claim"));
            return null;
        }
        return claim;
    }

    @SuppressWarnings("deprecation")
    private OfflinePlayer resolveOfflinePlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(name);
        if (op != null && op.hasPlayedBefore()) return op;
        // Last resort
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
            if (name.equalsIgnoreCase(p.getName())) return p;
        }
        return null;
    }

    private String msg(String key) {
        String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");
        String raw    = plugin.getMessages().getString(key, "");
        return raw.replace("{prefix}", prefix);
    }

    // ── Tab completion ────────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return List.of();

        if (args.length == 1) {
            List<String> subs = new ArrayList<>(Arrays.asList(
                    "create", "delete", "abandon", "list", "info", "tp", "setspawn",
                    "clearspawn", "desc", "trust", "untrust", "trustlist", "trustflag",
                    "outlaw", "pardon", "flags", "blocks", "nearby", "help", "version"));
            if (player.hasPermission("ultimateclaims.give")) subs.addAll(Arrays.asList("give", "take", "set"));
            if (player.hasPermission("ultimateclaims.reload")) subs.add("reload");
            return filter(subs, args[0]);
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            return switch (sub) {
                case "delete", "info", "tp", "setspawn", "clearspawn", "flags", "trustlist" ->
                        filter(getOwnClaimNames(player), args[1]);
                case "trust", "untrust", "outlaw", "pardon" ->
                        filter(getOnlinePlayerNames(), args[1]);
                case "desc" -> filter(Arrays.asList("set", "remove"), args[1]);
                case "trustflag" -> filter(getOnlinePlayerNames(), args[1]);
                case "give", "take", "set" -> List.of("100", "500", "1000");
                default -> List.of();
            };
        }

        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("trustflag")) {
                return filter(Arrays.stream(ClaimFlag.values())
                        .map(ClaimFlag::getConfigKey).collect(Collectors.toList()), args[2]);
            }
            if (sub.equals("give") || sub.equals("take") || sub.equals("set")) {
                return filter(getOnlinePlayerNames(), args[2]);
            }
        }

        if (args.length == 4 && args[0].equalsIgnoreCase("trustflag")) {
            return filter(Arrays.asList("on", "off"), args[3]);
        }

        return List.of();
    }

    private List<String> getOwnClaimNames(Player player) {
        return plugin.getClaimManager().getClaimsByOwner(player.getUniqueId())
                .stream().map(Claim::getName).collect(Collectors.toList());
    }

    private List<String> getOnlinePlayerNames() {
        return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName).collect(Collectors.toList());
    }

    private List<String> filter(List<String> options, String prefix) {
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(prefix.toLowerCase()))
                .collect(Collectors.toList());
    }
}
