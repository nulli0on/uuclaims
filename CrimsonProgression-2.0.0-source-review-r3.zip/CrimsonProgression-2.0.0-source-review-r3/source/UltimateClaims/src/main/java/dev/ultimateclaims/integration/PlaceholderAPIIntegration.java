package dev.ultimateclaims.integration;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.PlayerData;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Provides PlaceholderAPI placeholders for UltimateClaims.
 */
public class PlaceholderAPIIntegration extends PlaceholderExpansion {

    private final UltimateClaims plugin;

    public PlaceholderAPIIntegration(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "ultimateclaims"; }
    @Override public @NotNull String getAuthor()     { return "UltimateClaims"; }
    @Override public @NotNull String getVersion()    { return plugin.getDescription().getVersion(); }
    @Override public boolean persist()               { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";

        return switch (params.toLowerCase()) {
            case "available_blocks" -> {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player.getUniqueId());
                yield data != null ? String.valueOf(data.getAvailableBlocks()) : "0";
            }
            case "total_blocks" -> {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player.getUniqueId());
                yield data != null ? String.valueOf(data.getClaimBlocks()) : "0";
            }
            case "used_blocks" -> {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player.getUniqueId());
                yield data != null ? String.valueOf(data.getUsedClaimBlocks()) : "0";
            }
            case "claim_count" -> {
                List<Claim> claims = plugin.getClaimManager().getClaimsByOwner(player.getUniqueId());
                yield String.valueOf(claims.size());
            }
            case "max_claims" -> String.valueOf(plugin.getConfig().getInt("max-claims-per-player", 10));
            case "current_claim" -> {
                if (!player.isOnline() || player.getPlayer() == null) yield "none";
                Claim c = plugin.getClaimManager().getClaimAt(player.getPlayer().getLocation());
                yield c != null ? c.getName() : "none";
            }
            case "current_owner" -> {
                if (!player.isOnline() || player.getPlayer() == null) yield "none";
                Claim c = plugin.getClaimManager().getClaimAt(player.getPlayer().getLocation());
                yield c != null ? c.getOwnerName() : "none";
            }
            case "current_desc" -> {
                if (!player.isOnline() || player.getPlayer() == null) yield "";
                Claim c = plugin.getClaimManager().getClaimAt(player.getPlayer().getLocation());
                yield c != null && c.getDescription() != null ? c.getDescription() : "";
            }
            default -> null;
        };
    }
}
