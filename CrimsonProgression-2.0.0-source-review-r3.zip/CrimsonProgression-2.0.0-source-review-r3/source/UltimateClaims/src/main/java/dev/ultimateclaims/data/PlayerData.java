package dev.ultimateclaims.data;

import java.util.UUID;

/**
 * Stores per-player data: claim block balance and confirmation state.
 */
public class PlayerData {

    private final UUID uuid;
    private String playerName;
    private int claimBlocks;
    private int usedClaimBlocks;

    /** Pending delete confirmation (claim name awaiting confirmation). */
    private String pendingDeleteClaim;
    private long   pendingDeleteTime;

    /** Whether the player has a pending abandon-all confirmation. */
    private boolean pendingAbandon;
    private long    pendingAbandonTime;

    public PlayerData(UUID uuid, String playerName, int claimBlocks) {
        this.uuid         = uuid;
        this.playerName   = playerName == null || playerName.isBlank() ? "Unknown" : playerName;
        this.claimBlocks  = Math.max(0, claimBlocks);
        this.usedClaimBlocks = 0;
    }

    // ── Claim block management ────────────────────────────────────────────────

    public int getAvailableBlocks() {
        return Math.max(0, claimBlocks - usedClaimBlocks);
    }

    public boolean hasEnoughBlocks(int amount) {
        return amount >= 0 && getAvailableBlocks() >= amount;
    }

    public void addClaimBlocks(int amount) {
        if (amount <= 0) return;
        long result = (long) claimBlocks + amount;
        claimBlocks = result > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) result;
    }

    /** Returns true if there were enough blocks to deduct. */
    public boolean deductClaimBlocks(int amount) {
        if (amount <= 0 || !hasEnoughBlocks(amount)) return false;
        long result = (long) usedClaimBlocks + amount;
        usedClaimBlocks = result > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) result;
        return true;
    }

    public void returnClaimBlocks(int amount) {
        if (amount <= 0) return;
        usedClaimBlocks = Math.max(0, usedClaimBlocks - amount);
    }

    /**
     * Removes only unallocated claim blocks and returns the amount actually removed.
     * Existing claims are never silently rewritten to make an administrative balance
     * reduction fit.
     */
    public int takeClaimBlocks(int amount) {
        if (amount <= 0) return 0;
        int removable = Math.min(amount, getAvailableBlocks());
        claimBlocks -= removable;
        return removable;
    }

    // ── Pending confirmation state ────────────────────────────────────────────

    public void setPendingDelete(String claimName, int timeoutSeconds) {
        this.pendingDeleteClaim = claimName;
        this.pendingDeleteTime  = System.currentTimeMillis() + (timeoutSeconds * 1000L);
    }

    public void clearPendingDelete() {
        this.pendingDeleteClaim = null;
        this.pendingDeleteTime  = 0;
    }

    public boolean hasPendingDelete() {
        if (pendingDeleteClaim == null) return false;
        if (System.currentTimeMillis() > pendingDeleteTime) {
            clearPendingDelete();
            return false;
        }
        return true;
    }

    public String getPendingDeleteClaim() { return pendingDeleteClaim; }

    public void setPendingAbandon(int timeoutSeconds) {
        this.pendingAbandon     = true;
        this.pendingAbandonTime = System.currentTimeMillis() + (timeoutSeconds * 1000L);
    }

    public void clearPendingAbandon() {
        this.pendingAbandon     = false;
        this.pendingAbandonTime = 0;
    }

    public boolean hasPendingAbandon() {
        if (!pendingAbandon) return false;
        if (System.currentTimeMillis() > pendingAbandonTime) {
            clearPendingAbandon();
            return false;
        }
        return true;
    }

    // ── Getters / setters ─────────────────────────────────────────────────────

    public UUID   getUuid()           { return uuid; }
    public String getPlayerName()     { return playerName; }
    public void   setPlayerName(String n) { this.playerName = n == null || n.isBlank() ? "Unknown" : n; }
    public int    getClaimBlocks()    { return claimBlocks; }
    /** Sets total entitlement without reducing the area already allocated to claims. */
    public int    setClaimBlocks(int b)   { this.claimBlocks = Math.max(usedClaimBlocks, Math.max(0, b)); return claimBlocks; }
    public int    getUsedClaimBlocks() { return usedClaimBlocks; }
    public void   setUsedClaimBlocks(int u) {
        this.usedClaimBlocks = Math.max(0, u);
        if (usedClaimBlocks > claimBlocks) claimBlocks = usedClaimBlocks;
    }
}
