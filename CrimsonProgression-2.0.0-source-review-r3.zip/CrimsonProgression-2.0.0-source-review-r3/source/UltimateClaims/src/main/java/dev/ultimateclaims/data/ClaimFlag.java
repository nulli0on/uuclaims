package dev.ultimateclaims.data;

/**
 * All toggleable flags for a claim.
 * defaultValue = what the flag is set to when a claim is first created.
 */
public enum ClaimFlag {

    PVP("pvp", "PvP", false),
    OPEN_DOORS("open-doors", "Open Doors", false),
    OPEN_TRAPDOORS("open-trapdoors", "Open Trapdoors", false),
    OPEN_FENCE_GATES("open-fence-gates", "Open Fence Gates", false),
    OPEN_CHESTS("open-chests", "Open Chests", false),
    HARM_ANIMALS("harm-animals", "Harm Animals", false),
    HARM_PETS("harm-pets", "Harm Pets", false),
    FIRE_SPREAD("fire-spread", "Fire Spread", false),
    EXPLOSIONS("explosions", "Explosions", false),
    SPAWN_MOBS("spawn-mobs", "Spawn Mobs", true),
    BREAK_BLOCKS("break-blocks", "Break Blocks", false),
    PLACE_BLOCKS("place-blocks", "Place Blocks", false);

    private final String configKey;
    private final String displayName;
    private final boolean defaultValue;

    ClaimFlag(String configKey, String displayName, boolean defaultValue) {
        this.configKey    = configKey;
        this.displayName  = displayName;
        this.defaultValue = defaultValue;
    }

    public String getConfigKey()   { return configKey; }
    public String getDisplayName() { return displayName; }
    public boolean getDefaultValue() { return defaultValue; }

    /**
     * Looks up a flag by its config key (case-insensitive) or enum name.
     * Returns null if not found.
     */
    public static ClaimFlag fromName(String name) {
        if (name == null) return null;
        for (ClaimFlag flag : values()) {
            if (flag.configKey.equalsIgnoreCase(name) || flag.name().equalsIgnoreCase(name)) {
                return flag;
            }
        }
        return null;
    }
}
