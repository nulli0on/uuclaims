package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimFlag;
import dev.ultimateclaims.gui.FlagsGUI;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.UUID;

/**
 * Handles all inventory GUI interactions for UltimateClaims.
 *
 * Security rule: while an UltimateClaims GUI is open, every click and drag in
 * that view is cancelled first. This prevents shift-click, number-key swap,
 * double-click collect, offhand swap and cursor based item extraction exploits.
 */
public class GUIListener implements Listener {

    private final UltimateClaims plugin;

    public GUIListener(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Inventory topInventory = event.getView().getTopInventory();
        FlagsGUI gui = plugin.getFlagsGUI();
        if (!gui.isUltimateClaimsInventory(topInventory)) return;

        event.setCancelled(true);

        // Clicks in the player's own inventory or outside the window are blocked
        // for dupe protection, but they are not GUI actions.
        int rawSlot = event.getRawSlot();
        if (rawSlot < 0 || rawSlot >= topInventory.getSize()) return;

        UUID claimId = gui.getClaimId(topInventory);
        if (claimId == null) claimId = gui.getOpenClaimId(player.getUniqueId());
        if (claimId == null) return;

        Claim claim = plugin.getClaimManager().getClaimById(claimId);
        if (claim == null) {
            player.closeInventory();
            return;
        }

        // Close button
        if (gui.isCloseButton(rawSlot)) {
            player.closeInventory();
            return;
        }

        // Check ownership
        if (!claim.getOwner().equals(player.getUniqueId()) && !player.hasPermission("ultimateclaims.admin")) {
            String msg = plugin.getMessages().getString("flags-no-permission",
                    "{prefix}&cYou can only manage flags for your own claims.");
            MessageUtils.send(player, applyPrefix(msg));
            player.closeInventory();
            return;
        }

        // Flag toggle
        ClaimFlag flag = gui.getFlagAtSlot(rawSlot);
        if (flag == null) return;

        boolean newValue = !claim.getFlag(flag);
        claim.setFlag(flag, newValue);
        plugin.getClaimManager().saveClaim(claim);

        // Update WG region if needed
        plugin.getWorldGuardIntegration().updateRegion(claim);

        String raw = plugin.getMessages().getString("flag-toggled",
                "{prefix}&aToggled &b{flag} &ato &e{value} &ain &6{name}&a.");
        String msg = applyPrefix(raw);
        msg = MessageUtils.format(msg, "flag", flag.getDisplayName(),
                "value", newValue ? "ON" : "OFF", "name", claim.getName());
        MessageUtils.send(player, msg);

        // Refresh GUI in next tick to avoid inventory flicker and stale item state.
        plugin.getServer().getScheduler().runTask(plugin, () -> gui.refresh(player, claim));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInventoryDrag(InventoryDragEvent event) {
        Inventory topInventory = event.getView().getTopInventory();
        if (!plugin.getFlagsGUI().isUltimateClaimsInventory(topInventory)) return;

        // Cancel the entire drag. Even drags that appear to touch only the lower
        // inventory can be used as part of cursor desync/item movement exploits.
        event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (plugin.getFlagsGUI().isUltimateClaimsInventory(event.getView().getTopInventory())) {
            plugin.getFlagsGUI().closeGUI(player.getUniqueId());
        }
    }

    private String applyPrefix(String raw) {
        String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");
        return raw.replace("{prefix}", prefix);
    }
}
