package dev.ultimateclaims.gui;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimFlag;
import dev.ultimateclaims.utils.ItemUtils;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Builds and manages the Claim Flags GUI.
 */
public class FlagsGUI {

    private final UltimateClaims plugin;
    /** Player UUID → claim UUID currently being edited. */
    private final Map<UUID, UUID> openGUIs = new HashMap<>();

    public FlagsGUI(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    // ── Open / Refresh ────────────────────────────────────────────────────────

    public void open(Player player, Claim claim) {
        FileConfiguration guiCfg = plugin.getGuiConfig();
        String rawTitle = guiCfg.getString("flags-gui.title",
                "&8⚑ &b&lFlags: &f{claim} &8⚑");
        String title = MessageUtils.format(rawTitle, "claim", claim.getName());

        int rows = Math.min(6, Math.max(1, guiCfg.getInt("flags-gui.rows", 4)));
        int size = rows * 9;

        FlagsGUIHolder holder = new FlagsGUIHolder(claim.getId());
        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);

        // Fill background
        if (guiCfg.getBoolean("flags-gui.filler.enabled", true)) {
            Material fillerMat = ItemUtils.parseMaterial(
                    guiCfg.getString("flags-gui.filler.material", "BLACK_STAINED_GLASS_PANE"),
                    Material.BLACK_STAINED_GLASS_PANE);
            String fillerName = MessageUtils.color(
                    guiCfg.getString("flags-gui.filler.name", " "));
            ItemStack filler = ItemUtils.build(fillerMat, fillerName);
            for (int i = 0; i < size; i++) inv.setItem(i, filler);
        }

        // Place flag items
        ConfigurationSection flagsSection = guiCfg.getConfigurationSection("flags-gui.flags");
        if (flagsSection != null) {
            for (String flagKey : flagsSection.getKeys(false)) {
                ClaimFlag flag = ClaimFlag.fromName(flagKey);
                if (flag == null) continue;
                if (!guiCfg.getBoolean("flags-gui.flags." + flagKey + ".visible", true)) continue;

                int slot = guiCfg.getInt("flags-gui.flags." + flagKey + ".slot", -1);
                if (slot < 0 || slot >= size) continue;

                boolean current = claim.getFlag(flag);
                inv.setItem(slot, buildFlagItem(guiCfg, flagKey, flag, current));
            }
        }

        // Close button
        int closeSlot = guiCfg.getInt("flags-gui.close-button.slot", size - 5);
        if (closeSlot >= 0 && closeSlot < size) {
            Material closeMat = ItemUtils.parseMaterial(
                    guiCfg.getString("flags-gui.close-button.material", "BARRIER"),
                    Material.BARRIER);
            String closeName = MessageUtils.color(
                    guiCfg.getString("flags-gui.close-button.name", "&cClose"));
            List<String> closeLore = MessageUtils.colorList(
                    guiCfg.getStringList("flags-gui.close-button.lore"));
            inv.setItem(closeSlot, ItemUtils.build(closeMat, closeName, closeLore));
        }

        openGUIs.put(player.getUniqueId(), claim.getId());
        player.openInventory(inv);
    }

    public void refresh(Player player, Claim claim) {
        player.closeInventory();
        open(player, claim);
    }

    // ── State tracking ────────────────────────────────────────────────────────

    public UUID getOpenClaimId(UUID playerUuid)  { return openGUIs.get(playerUuid); }
    public void closeGUI(UUID playerUuid)         { openGUIs.remove(playerUuid); }

    public boolean isUltimateClaimsInventory(Inventory inventory) {
        return inventory != null && inventory.getHolder() instanceof FlagsGUIHolder;
    }

    public UUID getClaimId(Inventory inventory) {
        if (inventory != null && inventory.getHolder() instanceof FlagsGUIHolder holder) {
            return holder.getClaimId();
        }
        return null;
    }

    // ── Slot → Flag mapping ───────────────────────────────────────────────────

    public ClaimFlag getFlagAtSlot(int slot) {
        FileConfiguration guiCfg = plugin.getGuiConfig();
        ConfigurationSection flagsSection = guiCfg.getConfigurationSection("flags-gui.flags");
        if (flagsSection == null) return null;
        for (String flagKey : flagsSection.getKeys(false)) {
            if (!guiCfg.getBoolean("flags-gui.flags." + flagKey + ".visible", true)) continue;
            int flagSlot = guiCfg.getInt("flags-gui.flags." + flagKey + ".slot", -1);
            if (flagSlot == slot) return ClaimFlag.fromName(flagKey);
        }
        return null;
    }

    public boolean isCloseButton(int slot) {
        return slot == plugin.getGuiConfig().getInt("flags-gui.close-button.slot",
                plugin.getGuiConfig().getInt("flags-gui.rows", 4) * 9 - 5);
    }

    // ── Item builders ─────────────────────────────────────────────────────────

    private ItemStack buildFlagItem(FileConfiguration cfg, String flagKey,
                                     ClaimFlag flag, boolean current) {
        String path     = "flags-gui.flags." + flagKey;
        String stateKey = current ? "on" : "off";

        Material mat = ItemUtils.parseMaterial(
                cfg.getString(path + ".material-" + stateKey,
                        cfg.getString(path + ".material-on", "STONE")),
                Material.STONE);

        String name = MessageUtils.color(cfg.getString(path + ".name", flag.getDisplayName()));
        List<String> lore = MessageUtils.colorList(cfg.getStringList(path + ".lore-" + stateKey));
        return ItemUtils.build(mat, name, lore);
    }
}
