package dev.ultimateclaims.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Marker holder for UltimateClaims inventories.
 *
 * Bukkit inventory titles are user-controlled and therefore must not be used as
 * security identifiers. This holder lets listeners identify the plugin GUI
 * without blocking unrelated inventories that happen to have a similar title.
 */
public final class FlagsGUIHolder implements InventoryHolder {

    private final UUID claimId;
    private Inventory inventory;

    public FlagsGUIHolder(UUID claimId) {
        this.claimId = claimId;
    }

    public UUID getClaimId() {
        return claimId;
    }

    void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        if (inventory == null) {
            throw new IllegalStateException("Inventory has not been attached to this holder yet");
        }
        return inventory;
    }
}
