package dev.ultimateclaims.data;

import org.bukkit.Location;

/**
 * Tracks a player's in-progress claim selection (two 2D corner points).
 * X and Z coordinates define the corners; Y is ignored since claims span all heights.
 */
public class ClaimSelection {

    private Integer pos1X, pos1Z;
    private Integer pos2X, pos2Z;
    private String  world;

    public ClaimSelection() {}

    public void setPos1(Location location) {
        this.pos1X = location.getBlockX();
        this.pos1Z = location.getBlockZ();
        this.world = location.getWorld().getName();
        // Clear pos2 if world changes
        if (pos2X != null) { pos2X = null; pos2Z = null; }
    }

    public void setPos2(Location location) {
        this.pos2X = location.getBlockX();
        this.pos2Z = location.getBlockZ();
    }

    public boolean hasPos1() { return pos1X != null; }
    public boolean hasPos2() { return pos2X != null; }
    public boolean isComplete() { return hasPos1() && hasPos2(); }

    public Integer getPos1X() { return pos1X; }
    public Integer getPos1Z() { return pos1Z; }
    public Integer getPos2X() { return pos2X; }
    public Integer getPos2Z() { return pos2Z; }
    public String  getWorld() { return world; }

    public int getArea() {
        return safeToInt(getAreaLong());
    }

    public long getAreaLong() {
        if (!isComplete()) return 0L;
        long width = getWidthLong();
        long length = getLengthLong();
        if (width <= 0L || length <= 0L) return Long.MAX_VALUE;
        if (width > Long.MAX_VALUE / length) return Long.MAX_VALUE;
        return width * length;
    }

    public int getWidth() {
        return safeToInt(getWidthLong());
    }

    public long getWidthLong() {
        if (!isComplete()) return 0L;
        return Math.abs((long) pos2X - (long) pos1X) + 1L;
    }

    public int getLength() {
        return safeToInt(getLengthLong());
    }

    public long getLengthLong() {
        if (!isComplete()) return 0L;
        return Math.abs((long) pos2Z - (long) pos1Z) + 1L;
    }

    private int safeToInt(long value) {
        return value > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) Math.max(0L, value);
    }

    public void clear() {
        pos1X = pos1Z = pos2X = pos2Z = null;
        world = null;
    }

    @Override
    public String toString() {
        return "Selection{pos1=(" + pos1X + "," + pos1Z + "), pos2=(" + pos2X + "," + pos2Z + "), world=" + world + "}";
    }
}
