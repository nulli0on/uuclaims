package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.integration.CelestCombatIntegration;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.vehicle.VehicleMoveEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class CelestCombatListener implements Listener {
    private final UltimateClaims plugin;
    private final CelestCombatIntegration integration;
    private final Map<UUID, SafePoint> lastSafe = new ConcurrentHashMap<>();
    private final Map<UUID, Long> messageCooldown = new ConcurrentHashMap<>();
    private final Set<UUID> vehicleSetback = ConcurrentHashMap.newKeySet();

    public CelestCombatListener(UltimateClaims plugin, CelestCombatIntegration integration) {
        this.plugin = plugin;
        this.integration = integration;
    }

    private YamlConfiguration config() {
        return plugin.getCombatConfig();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!config().getBoolean("enabled", true)
                || !config().getBoolean("block.walking", true)
                || event.getTo() == null
                || sameBlock(event.getFrom(), event.getTo())) return;

        Player player = event.getPlayer();
        Claim from = plugin.getClaimManager().getClaimAt(event.getFrom());
        Claim to = plugin.getClaimManager().getClaimAt(event.getTo());
        if (!integration.isInCombat(player)) {
            rememberSafe(player, event.getTo(), to);
            return;
        }
        if (!shouldBlock(player, from, to)) {
            rememberSafe(player, event.getTo(), to);
            return;
        }

        event.setCancelled(true);
        event.setTo(safeLocation(player, event.getFrom()));
        notify(player);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (!config().getBoolean("enabled", true)
                || !config().getBoolean("block.teleport", true)
                || !causeEnabled(event.getCause())
                || event.getTo() == null) return;
        Player player = event.getPlayer();
        if (!integration.isInCombat(player)) return;
        Claim from = plugin.getClaimManager().getClaimAt(event.getFrom());
        Claim to = plugin.getClaimManager().getClaimAt(event.getTo());
        if (!shouldBlock(player, from, to)) return;
        event.setCancelled(true);
        notify(player);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onVehicleMove(VehicleMoveEvent event) {
        if (!config().getBoolean("enabled", true) || !config().getBoolean("block.vehicles", true)) return;
        Vehicle vehicle = event.getVehicle();
        if (!vehicleSetback.add(vehicle.getUniqueId())) return;
        try {
            Claim from = plugin.getClaimManager().getClaimAt(event.getFrom());
            Claim to = plugin.getClaimManager().getClaimAt(event.getTo());
            for (Entity passenger : vehicle.getPassengers()) {
                if (!(passenger instanceof Player player) || !integration.isInCombat(player)) continue;
                if (!shouldBlock(player, from, to)) continue;
                vehicle.teleport(event.getFrom());
                notify(player);
                break;
            }
        } finally {
            vehicleSetback.remove(vehicle.getUniqueId());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        lastSafe.remove(id);
        messageCooldown.remove(id);
    }

    private boolean causeEnabled(PlayerTeleportEvent.TeleportCause cause) {
        return switch (cause) {
            case ENDER_PEARL -> config().getBoolean("block.ender-pearl", true);
            case CHORUS_FRUIT -> config().getBoolean("block.chorus-fruit", true);
            case NETHER_PORTAL, END_PORTAL -> config().getBoolean("block.portal", true);
            case PLUGIN -> config().getBoolean("block.plugin-teleports", true);
            default -> true;
        };
    }

    private boolean shouldBlock(Player player, Claim from, Claim to) {
        if (to == null || from == to) return false;
        if (player.hasPermission(config().getString("bypass-permission", "ultimateclaims.combat.bypass"))) return false;
        if (config().getBoolean("owner-bypass", false) && to.getOwner().equals(player.getUniqueId())) return false;
        if (config().getBoolean("trusted-bypass", false) && to.isTrusted(player.getUniqueId())) return false;
        if (from == null) return config().getBoolean("transitions.unclaimed-to-claim", true);
        return config().getBoolean("transitions.claim-to-other-claim", true)
                && !from.getId().equals(to.getId());
    }

    private void rememberSafe(Player player, Location location, Claim destination) {
        if (!config().getBoolean("safe-location.enabled", true)) return;
        if (destination == null) lastSafe.put(player.getUniqueId(), new SafePoint(location.clone(), System.currentTimeMillis()));
    }

    private Location safeLocation(Player player, Location fallback) {
        SafePoint point = lastSafe.get(player.getUniqueId());
        long maximumAge = Math.max(1L, config().getLong("safe-location.maximum-age-seconds", 15L)) * 1000L;
        if (point != null && System.currentTimeMillis() - point.createdAt <= maximumAge
                && point.location.getWorld() != null && point.location.getWorld().equals(fallback.getWorld())) {
            return point.location.clone();
        }
        return fallback.clone();
    }

    private void notify(Player player) {
        long now = System.currentTimeMillis();
        long delay = Math.max(250L, config().getLong("message-cooldown-millis", 1500L));
        Long previous = messageCooldown.put(player.getUniqueId(), now);
        if (previous != null && now - previous < delay) return;
        String raw = plugin.getMessages().getString("combat-prevent-entry",
                "{prefix}&cYou cannot enter this claim while in combat.");
        String message = raw.replace("{prefix}", plugin.getMessages().getString("prefix", ""));
        player.sendMessage(MessageUtils.color(message));
    }

    private static boolean sameBlock(Location first, Location second) {
        return first.getWorld() == second.getWorld()
                && first.getBlockX() == second.getBlockX()
                && first.getBlockY() == second.getBlockY()
                && first.getBlockZ() == second.getBlockZ();
    }

    private record SafePoint(Location location, long createdAt) {}
}
