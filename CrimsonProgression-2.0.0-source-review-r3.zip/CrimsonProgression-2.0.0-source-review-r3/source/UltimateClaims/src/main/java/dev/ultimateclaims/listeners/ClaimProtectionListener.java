package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimFlag;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;

import java.util.Objects;
import java.util.UUID;

/**
 * Enforces claim protection and flag based access rules.
 */
public class ClaimProtectionListener implements Listener {

    private final UltimateClaims plugin;

    public ClaimProtectionListener(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    // ── Bypass / access helpers ───────────────────────────────────────────────

    private boolean isBypass(Player player) {
        if (player.hasPermission("ultimateclaims.admin")) return true;
        if (player.hasPermission("ultimateclaims.bypass")) return true;
        return plugin.getConfig().getBoolean("op-bypass", true) && player.isOp();
    }

    private boolean canUseFlag(Player player, Claim claim, ClaimFlag flag) {
        if (claim == null) return true;
        if (isBypass(player)) return true;
        if (claim.getOwner().equals(player.getUniqueId())) return true;
        if (claim.getFlag(flag)) return true;
        return claim.isTrusted(player.getUniqueId())
                && claim.isTrustedFlagAllowed(player.getUniqueId(), flag);
    }

    private void deny(Player player, String messageKey, Claim claim) {
        MessageUtils.send(player, msg(messageKey, "claim", claim.getName()));
    }

    private String msg(String key, String... replacements) {
        String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");
        String raw = plugin.getMessages().getString(key, "");
        return MessageUtils.format(raw.replace("{prefix}", prefix), replacements);
    }

    // =========================================================================
    // Block Break / Place / Buckets / Fluids
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        if (claim == null) return;

        if (!canUseFlag(player, claim, ClaimFlag.BREAK_BLOCKS)) {
            event.setCancelled(true);
            deny(player, "protected-break", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        if (claim == null) return;

        if (!canUseFlag(player, claim, ClaimFlag.PLACE_BLOCKS)) {
            event.setCancelled(true);
            deny(player, "protected-place", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Block target = event.getBlockClicked().getRelative(event.getBlockFace());
        Claim claim = plugin.getClaimManager().getClaimAt(target.getLocation());
        if (claim == null) return;

        if (!canUseFlag(event.getPlayer(), claim, ClaimFlag.PLACE_BLOCKS)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "protected-place", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlockClicked().getLocation());
        if (claim == null) return;

        if (!canUseFlag(event.getPlayer(), claim, ClaimFlag.BREAK_BLOCKS)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "protected-break", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFluidFlow(BlockFromToEvent event) {
        Material type = event.getBlock().getType();
        if (type != Material.WATER && type != Material.LAVA) return;

        Claim from = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        Claim to = plugin.getClaimManager().getClaimAt(event.getToBlock().getLocation());

        // Prevent water/lava from crossing claim boundaries. Same-claim internal
        // flow is allowed; unclaimed-to-unclaimed is allowed.
        if (!Objects.equals(claimId(from), claimId(to)) && (from != null || to != null)) {
            event.setCancelled(true);
        }
    }


    // =========================================================================
    // Hopper / container automation
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryMoveItem(InventoryMoveItemEvent event) {
        Claim sourceClaim = getClaimAtInventory(event.getSource());
        Claim destinationClaim = getClaimAtInventory(event.getDestination());

        // Prevent hoppers, hopper minecarts and other inventory movers from
        // extracting from or injecting into a claim across its boundary.
        if (crossesClaimBoundary(sourceClaim, destinationClaim)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryPickupItem(InventoryPickupItemEvent event) {
        Claim inventoryClaim = getClaimAtInventory(event.getInventory());
        Claim itemClaim = plugin.getClaimManager().getClaimAt(event.getItem().getLocation());

        if (crossesClaimBoundary(itemClaim, inventoryClaim)) {
            event.setCancelled(true);
        }
    }

    // =========================================================================
    // Player Interact (doors, trapdoors, fence gates, containers, farmland)
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        // Only the main-hand claiming-tool event is owned by ClaimToolListener.
        // A blanket main-hand check would let off-hand interactions bypass protection.
        if (event.getHand() == EquipmentSlot.HAND
                && plugin.getClaimToolListener().isClaimingTool(event.getItem())) return;

        if (event.getAction() == org.bukkit.event.block.Action.PHYSICAL) {
            handlePhysicalInteract(event);
            return;
        }

        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK
                && event.getAction() != org.bukkit.event.block.Action.LEFT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        Block block = event.getClickedBlock();
        Material mat = block.getType();

        if (event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK
                && event.getItem() != null && isSpawnEgg(event.getItem().getType())) {
            Block targetBlock = block.getRelative(event.getBlockFace());
            Claim targetClaim = plugin.getClaimManager().getClaimAt(targetBlock.getLocation());
            if (targetClaim != null && !canUseFlag(player, targetClaim, ClaimFlag.PLACE_BLOCKS)) {
                event.setCancelled(true);
                deny(player, "protected-place", targetClaim);
                return;
            }
        }

        Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());
        if (claim == null) return;
        if (isBypass(player) || claim.getOwner().equals(player.getUniqueId())) return;

        boolean trusted = claim.isTrusted(player.getUniqueId());

        if (Tag.DOORS.isTagged(mat)) {
            if (!claim.getFlag(ClaimFlag.OPEN_DOORS)
                    && !(trusted && claim.isTrustedFlagAllowed(player.getUniqueId(), ClaimFlag.OPEN_DOORS))) {
                event.setCancelled(true);
                deny(player, "protected-interact", claim);
            }
            return;
        }

        if (Tag.TRAPDOORS.isTagged(mat)) {
            if (!claim.getFlag(ClaimFlag.OPEN_TRAPDOORS)
                    && !(trusted && claim.isTrustedFlagAllowed(player.getUniqueId(), ClaimFlag.OPEN_TRAPDOORS))) {
                event.setCancelled(true);
                deny(player, "protected-interact", claim);
            }
            return;
        }

        if (Tag.FENCE_GATES.isTagged(mat)) {
            if (!claim.getFlag(ClaimFlag.OPEN_FENCE_GATES)
                    && !(trusted && claim.isTrustedFlagAllowed(player.getUniqueId(), ClaimFlag.OPEN_FENCE_GATES))) {
                event.setCancelled(true);
                deny(player, "protected-interact", claim);
            }
            return;
        }

        if (isContainer(mat)) {
            if (!claim.getFlag(ClaimFlag.OPEN_CHESTS)
                    && !(trusted && claim.isTrustedFlagAllowed(player.getUniqueId(), ClaimFlag.OPEN_CHESTS))) {
                event.setCancelled(true);
                deny(player, "protected-chest", claim);
            }
            return;
        }

        // Buttons, levers, beds, crafting stations and other interactable blocks
        // must not become an unprotected fallback path. Existing trusted players
        // receive PLACE_BLOCKS by default, while owners and bypass users were
        // already handled above.
        if (mat.isInteractable() && !canUseFlag(player, claim, ClaimFlag.PLACE_BLOCKS)) {
            event.setCancelled(true);
            deny(player, "protected-interact", claim);
        }
    }

    private void handlePhysicalInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.FARMLAND) return;

        Player player = event.getPlayer();
        Claim claim = plugin.getClaimManager().getClaimAt(event.getClickedBlock().getLocation());
        if (claim == null) return;

        if (!canUseFlag(player, claim, ClaimFlag.BREAK_BLOCKS)) {
            event.setCancelled(true);
        }
    }

    // =========================================================================
    // Entity interaction / entity damage
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        protectEntityInteraction(event, event.getRightClicked());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent event) {
        protectEntityInteraction(event, event.getRightClicked());
    }

    private void protectEntityInteraction(PlayerInteractEntityEvent event, Entity entity) {
        Player player = event.getPlayer();
        Claim claim = plugin.getClaimManager().getClaimAt(entity.getLocation());
        if (claim == null) return;
        if (isBypass(player) || claim.getOwner().equals(player.getUniqueId())) return;

        if (isStorageEntity(entity)) {
            if (!canUseFlag(player, claim, ClaimFlag.OPEN_CHESTS)) {
                event.setCancelled(true);
                deny(player, "protected-chest", claim);
            }
            return;
        }

        if (isDecorativeOrVehicleEntity(entity)) {
            if (!canUseFlag(player, claim, ClaimFlag.PLACE_BLOCKS)) {
                event.setCancelled(true);
                deny(player, "protected-interact", claim);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityPlace(EntityPlaceEvent event) {
        if (event.getEntity() == null || event.getPlayer() == null) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null) return;

        if (!canUseFlag(event.getPlayer(), claim, ClaimFlag.PLACE_BLOCKS)) {
            event.setCancelled(true);
            deny(event.getPlayer(), "protected-place", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent event) {
        Player player = event.getPlayer();
        if (player == null) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null) return;

        if (!canUseFlag(player, claim, ClaimFlag.PLACE_BLOCKS)) {
            event.setCancelled(true);
            deny(player, "protected-place", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        Player player = resolveAttacker(event.getRemover());
        if (player == null) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null) return;

        if (!canUseFlag(player, claim, ClaimFlag.BREAK_BLOCKS)) {
            event.setCancelled(true);
            deny(player, "protected-break", claim);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreakNonPlayer(HangingBreakEvent event) {
        if (event instanceof HangingBreakByEntityEvent) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null) return;
        if (!claim.getFlag(ClaimFlag.EXPLOSIONS)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null) return;

        if (event.getEntity() instanceof Player victim) {
            Claim claim = plugin.getClaimManager().getClaimAt(victim.getLocation());
            if (claim == null) return;
            if (isBypass(attacker)) return;

            boolean attackerOutlawed = claim.isOutlawed(attacker.getUniqueId());
            boolean victimOutlawed = claim.isOutlawed(victim.getUniqueId());
            if (attackerOutlawed || victimOutlawed) return;

            if (!claim.getFlag(ClaimFlag.PVP)) {
                event.setCancelled(true);
                deny(attacker, "protected-pvp", claim);
            }
            return;
        }

        if (isDecorativeOrVehicleEntity(event.getEntity()) || isStorageEntity(event.getEntity())) {
            Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
            if (claim == null) return;
            if (!canUseFlag(attacker, claim, ClaimFlag.BREAK_BLOCKS)) {
                event.setCancelled(true);
                deny(attacker, "protected-break", claim);
            }
            return;
        }

        if (event.getEntity() instanceof Animals animal) {
            Claim claim = plugin.getClaimManager().getClaimAt(animal.getLocation());
            if (claim == null) return;
            if (isBypass(attacker) || claim.getOwner().equals(attacker.getUniqueId())) return;

            boolean trusted = claim.isTrusted(attacker.getUniqueId());

            if (animal instanceof Tameable tameable && tameable.isTamed()) {
                if (!claim.getFlag(ClaimFlag.HARM_PETS)
                        && !(trusted && claim.isTrustedFlagAllowed(attacker.getUniqueId(), ClaimFlag.HARM_PETS))) {
                    event.setCancelled(true);
                    deny(attacker, "protected-pets", claim);
                    return;
                }
            }

            if (!claim.getFlag(ClaimFlag.HARM_ANIMALS)
                    && !(trusted && claim.isTrustedFlagAllowed(attacker.getUniqueId(), ClaimFlag.HARM_ANIMALS))) {
                event.setCancelled(true);
                deny(attacker, "protected-animals", claim);
            }
        }
    }

    // =========================================================================
    // Explosions
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> {
            Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());
            return claim != null && !claim.getFlag(ClaimFlag.EXPLOSIONS);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(block -> {
            Claim claim = plugin.getClaimManager().getClaimAt(block.getLocation());
            return claim != null && !claim.getFlag(ClaimFlag.EXPLOSIONS);
        });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplosionDamage(EntityDamageEvent event) {
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                && cause != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) return;

        Claim claim = plugin.getClaimManager().getClaimAt(event.getEntity().getLocation());
        if (claim == null) return;
        if (!claim.getFlag(ClaimFlag.EXPLOSIONS)) event.setCancelled(true);
    }

    // =========================================================================
    // Fire spread
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockIgnite(BlockIgniteEvent event) {
        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        if (claim == null) return;

        Player player = event.getPlayer();
        if (player != null) {
            if (!canUseFlag(player, claim, ClaimFlag.PLACE_BLOCKS)) {
                event.setCancelled(true);
                deny(player, "protected-place", claim);
            }
            return;
        }

        if (!claim.getFlag(ClaimFlag.FIRE_SPREAD)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockSpread(BlockSpreadEvent event) {
        if (event.getNewState().getType() != Material.FIRE) return;
        Claim claim = plugin.getClaimManager().getClaimAt(event.getNewState().getLocation());
        if (claim == null) return;
        if (!claim.getFlag(ClaimFlag.FIRE_SPREAD)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent event) {
        Claim claim = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        if (claim == null) return;
        if (!claim.getFlag(ClaimFlag.FIRE_SPREAD)) event.setCancelled(true);
    }

    // =========================================================================
    // Mob spawning
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Enemy)) return;

        Claim claim = plugin.getClaimManager().getClaimAt(entity.getLocation());
        if (claim == null) return;
        if (claim.getFlag(ClaimFlag.SPAWN_MOBS)) return;
        if (!shouldBlockSpawnReason(event.getSpawnReason())) return;

        event.setCancelled(true);
    }

    // =========================================================================
    // Piston protection — blocks cannot be moved across claim boundaries
    // =========================================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        Claim piston = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        for (Block block : event.getBlocks()) {
            Claim src = plugin.getClaimManager().getClaimAt(block.getLocation());
            Claim dst = plugin.getClaimManager().getClaimAt(block.getRelative(event.getDirection()).getLocation());
            if (!sameClaim(piston, src, dst)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        Claim piston = plugin.getClaimManager().getClaimAt(event.getBlock().getLocation());
        for (Block block : event.getBlocks()) {
            Claim src = plugin.getClaimManager().getClaimAt(block.getLocation());
            Claim dst = plugin.getClaimManager().getClaimAt(block.getRelative(event.getDirection()).getLocation());
            if (!sameClaim(piston, src, dst)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    // =========================================================================
    // Utilities
    // =========================================================================

    private boolean crossesClaimBoundary(Claim a, Claim b) {
        return !Objects.equals(claimId(a), claimId(b)) && (a != null || b != null);
    }

    private boolean sameClaim(Claim a, Claim b, Claim c) {
        UUID first = claimId(a);
        return Objects.equals(first, claimId(b)) && Objects.equals(first, claimId(c));
    }

    private Claim getClaimAtInventory(Inventory inventory) {
        Location location = getInventoryLocation(inventory);
        return location == null ? null : plugin.getClaimManager().getClaimAt(location);
    }

    private Location getInventoryLocation(Inventory inventory) {
        if (inventory == null) return null;
        Location direct = inventory.getLocation();
        if (direct != null) return direct;
        InventoryHolder holder = inventory.getHolder();
        if (holder instanceof BlockState blockState) return blockState.getLocation();
        if (holder instanceof Entity entity) return entity.getLocation();
        return null;
    }

    private boolean isSpawnEgg(Material material) {
        return material != null && material.name().endsWith("_SPAWN_EGG");
    }

    private boolean isStorageEntity(Entity entity) {
        return entity instanceof org.bukkit.entity.minecart.StorageMinecart;
    }

    private boolean isDecorativeOrVehicleEntity(Entity entity) {
        return entity instanceof ArmorStand
                || entity instanceof ItemFrame
                || entity instanceof Painting
                || entity instanceof Hanging
                || entity instanceof Display
                || entity instanceof Boat
                || entity instanceof Minecart;
    }


    private boolean shouldBlockSpawnReason(CreatureSpawnEvent.SpawnReason reason) {
        if (reason == null) return true;
        String name = reason.name();
        if (name.equals("SPAWNER")) {
            return plugin.getConfig().getBoolean("spawn-mob-protection.block-spawners", true);
        }
        if (name.equals("SPAWNER_EGG") || name.equals("DISPENSE_EGG") || name.equals("EGG")) {
            return plugin.getConfig().getBoolean("spawn-mob-protection.block-spawn-eggs", true);
        }
        if (name.equals("COMMAND")) {
            return plugin.getConfig().getBoolean("spawn-mob-protection.block-commands", true);
        }
        if (name.equals("CUSTOM")) {
            return plugin.getConfig().getBoolean("spawn-mob-protection.block-custom", true);
        }
        if (name.equals("NATURAL") || name.equals("JOCKEY") || name.equals("CHUNK_GEN")
                || name.equals("MOUNT") || name.equals("PATROL") || name.equals("RAID")
                || name.equals("REINFORCEMENTS") || name.equals("DROWNED")
                || name.equals("NETHER_PORTAL") || name.equals("OCELOT_BABY")
                || name.equals("SILVERFISH_BLOCK") || name.equals("SLIME_SPLIT")
                || name.equals("VILLAGE_DEFENSE") || name.equals("VILLAGE_INVASION")) {
            return plugin.getConfig().getBoolean("spawn-mob-protection.block-natural", true);
        }
        return plugin.getConfig().getBoolean("spawn-mob-protection.block-custom", true);
    }

    private UUID claimId(Claim c) {
        return c == null ? null : c.getId();
    }

    private Player resolveAttacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (damager instanceof TNTPrimed tnt && tnt.getSource() instanceof Player p) return p;
        return null;
    }

    private boolean isContainer(Material mat) {
        return switch (mat) {
            case CHEST, TRAPPED_CHEST, BARREL, HOPPER, DROPPER, DISPENSER,
                 FURNACE, BLAST_FURNACE, SMOKER, CRAFTER, BEACON,
                 WHITE_SHULKER_BOX, ORANGE_SHULKER_BOX, MAGENTA_SHULKER_BOX,
                 LIGHT_BLUE_SHULKER_BOX, YELLOW_SHULKER_BOX, LIME_SHULKER_BOX,
                 PINK_SHULKER_BOX, GRAY_SHULKER_BOX, LIGHT_GRAY_SHULKER_BOX,
                 CYAN_SHULKER_BOX, PURPLE_SHULKER_BOX, BLUE_SHULKER_BOX,
                 BROWN_SHULKER_BOX, GREEN_SHULKER_BOX, RED_SHULKER_BOX,
                 BLACK_SHULKER_BOX, ENDER_CHEST, BREWING_STAND,
                 CHISELED_BOOKSHELF, LECTERN -> true;
            default -> false;
        };
    }
}
