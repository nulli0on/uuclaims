package dev.ultimateclaims.managers;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.PlayerData;
import dev.ultimateclaims.index.ClaimSpatialIndex;
import org.bukkit.Location;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central manager for all claims — creation, deletion, lookup, and validation.
 */
public class ClaimManager {

    private final UltimateClaims plugin;
    /** Claim ID → Claim */
    private final Map<UUID, Claim> claims = new java.util.concurrent.ConcurrentHashMap<>();
    private final ClaimSpatialIndex spatialIndex;

    public ClaimManager(UltimateClaims plugin) {
        this.plugin = plugin;
        this.spatialIndex = new ClaimSpatialIndex(
                plugin.getConfig().getInt("spatial-index.max-chunks-per-claim", 4096));
    }

    // =========================================================================
    // CRUD
    // =========================================================================

    /** Registers a claim loaded from disk during startup. */
    public void addClaimDirectly(Claim claim) {
        claims.put(claim.getId(), claim);
        spatialIndex.add(claim);
    }

    /**
     * Creates and persists a new claim.
     * Caller must have already validated blocks, overlaps, and limits.
     */
    public java.util.concurrent.CompletableFuture<Claim> createClaim(UUID owner, String ownerName, String name,
                              String world, int x1, int z1, int x2, int z2) {
        UUID id = UUID.randomUUID();
        Claim claim = new Claim(id, owner, ownerName, name, world, x1, z1, x2, z2);
        applyDefaultFlags(claim);

        PlayerData data = plugin.getPlayerDataManager().getPlayerData(owner);
        if (data == null || !data.deductClaimBlocks(claim.getArea())) {
            return java.util.concurrent.CompletableFuture.completedFuture(null);
        }

        // Reserve in memory immediately so two rapid selections cannot overlap while the DB commit is pending.
        claims.put(id, claim);
        spatialIndex.add(claim);

        return plugin.getDataManager().createClaimAndPlayer(claim, data)
                .handle((ignored, error) -> new PersistenceResult(error))
                .thenCompose(result -> onMain(() -> {
                    if (result.error() != null) {
                        claims.remove(id);
                        spatialIndex.remove(claim);
                        data.returnClaimBlocks(claim.getArea());
                        plugin.getLogger().log(java.util.logging.Level.SEVERE,
                                "Atomic claim creation failed for " + id + "; in-memory reservation was rolled back.",
                                result.error());
                        return null;
                    }
                    plugin.getWorldGuardIntegration().createRegion(claim);
                    if (plugin.getConfig().getBoolean("log-claims", true)) {
                        plugin.getLogger().info("[Claim Created] " + ownerName + " created '" + name
                                + "' in " + world + " (" + x1 + "," + z1 + " to " + x2 + "," + z2
                                + ") [" + claim.getArea() + " blocks]");
                    }
                    return claim;
                }));
    }

    public java.util.concurrent.CompletableFuture<Integer> deleteClaim(Claim claim) {
        return deleteClaims(List.of(claim));
    }

    /** Atomically deletes one or more claims and persists the matching player block refund. */
    public java.util.concurrent.CompletableFuture<Integer> deleteClaims(Collection<Claim> deleting) {
        List<Claim> snapshot = List.copyOf(deleting);
        if (snapshot.isEmpty()) return java.util.concurrent.CompletableFuture.completedFuture(0);
        UUID owner = snapshot.getFirst().getOwner();
        if (snapshot.stream().anyMatch(claim -> !claim.getOwner().equals(owner))) {
            return java.util.concurrent.CompletableFuture.failedFuture(
                    new IllegalArgumentException("Bulk claim deletion must have one owner"));
        }
        int totalArea = snapshot.stream().mapToInt(Claim::getArea).reduce(0,
                (left, right) -> (int) Math.min(Integer.MAX_VALUE, (long) left + right));
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(owner);
        if (data == null) return java.util.concurrent.CompletableFuture.failedFuture(
                new IllegalStateException("Missing player data for claim owner " + owner));

        for (Claim claim : snapshot) {
            claims.remove(claim.getId());
            spatialIndex.remove(claim);
        }
        data.returnClaimBlocks(totalArea);

        java.util.concurrent.CompletableFuture<Void> persistence = snapshot.size() == 1
                ? plugin.getDataManager().deleteClaimAndPlayer(snapshot.getFirst(), data)
                : plugin.getDataManager().deleteClaimsAndPlayer(snapshot, data);
        return persistence.handle((ignored, error) -> new PersistenceResult(error))
                .thenCompose(result -> onMain(() -> {
                    if (result.error() != null) {
                        data.deductClaimBlocks(totalArea);
                        for (Claim claim : snapshot) {
                            claims.put(claim.getId(), claim);
                            spatialIndex.add(claim);
                        }
                        plugin.getLogger().log(java.util.logging.Level.SEVERE,
                                "Atomic claim deletion failed; in-memory claims and block balance were restored.",
                                result.error());
                        throw new java.util.concurrent.CompletionException(result.error());
                    }
                    for (Claim claim : snapshot) {
                        plugin.getWorldGuardIntegration().deleteRegion(claim);
                        if (plugin.getConfig().getBoolean("log-claims", true)) {
                            plugin.getLogger().info("[Claim Deleted] " + claim.getOwnerName()
                                    + "'s claim '" + claim.getName() + "'");
                        }
                    }
                    return totalArea;
                }));
    }

    /** Captures the mutable claim on the server thread, then queues its immutable payload for SQLite. */
    public void saveClaim(Claim claim) {
        plugin.getDataManager().saveClaim(claim);
    }

    // =========================================================================
    // Lookup methods
    // =========================================================================

    public Claim getClaimById(UUID id) {
        return claims.get(id);
    }

    /**
     * Finds the first claim containing the given world + X,Z coordinate.
     * Returns null if no claim covers that point.
     */
    public Claim getClaimAt(Location location) {
        if (location == null || location.getWorld() == null) return null;
        String world = location.getWorld().getName();
        int    x     = location.getBlockX();
        int    z     = location.getBlockZ();
        for (UUID claimId : spatialIndex.candidates(world, x, z)) {
            Claim claim = claims.get(claimId);
            if (claim != null && claim.contains(world, x, z)) return claim;
        }
        return null;
    }

    public List<Claim> getClaimsByOwner(UUID ownerUuid) {
        return claims.values().stream()
                .filter(c -> c.getOwner().equals(ownerUuid))
                .collect(Collectors.toList());
    }

    public Claim getClaimByName(UUID ownerUuid, String name) {
        return claims.values().stream()
                .filter(c -> c.getOwner().equals(ownerUuid)
                        && c.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

    /** Finds any claim by owner name + claim name (for admin commands). */
    public Claim getClaimByOwnerAndName(String ownerName, String claimName) {
        return claims.values().stream()
                .filter(c -> c.getOwnerName().equalsIgnoreCase(ownerName)
                        && c.getName().equalsIgnoreCase(claimName))
                .findFirst().orElse(null);
    }

    public List<Claim> getClaimsInWorld(String world) {
        return claims.values().stream()
                .filter(c -> c.getWorld().equals(world))
                .collect(Collectors.toList());
    }

    public Collection<Claim> getAllClaims() {
        return List.copyOf(claims.values());
    }

    // =========================================================================
    // Validation helpers
    // =========================================================================

    public boolean overlapsExistingClaim(String world, int minX, int minZ,
                                          int maxX, int maxZ, UUID excludeId) {
        for (UUID claimId : spatialIndex.candidates(world, minX, minZ, maxX, maxZ)) {
            Claim c = claims.get(claimId);
            if (c == null || !c.getWorld().equals(world)) continue;
            if (excludeId != null && c.getId().equals(excludeId)) continue;
            boolean xOverlap = minX <= c.getMaxX() && maxX >= c.getMinX();
            boolean zOverlap = minZ <= c.getMaxZ() && maxZ >= c.getMinZ();
            if (xOverlap && zOverlap) return true;
        }
        return false;
    }

    public boolean overlapsExistingClaim(String world, int minX, int minZ, int maxX, int maxZ) {
        return overlapsExistingClaim(world, minX, minZ, maxX, maxZ, null);
    }

    /** Finds all claims within a given block radius of a location (nearest first). */
    public List<Claim> getNearbyClaims(Location center, int radiusBlocks) {
        if (center == null || center.getWorld() == null) return Collections.emptyList();
        String world = center.getWorld().getName();
        int cx = center.getBlockX();
        int cz = center.getBlockZ();
        int radius = Math.max(0, radiusBlocks);
        int minX = clampToInt((long) cx - radius);
        int minZ = clampToInt((long) cz - radius);
        int maxX = clampToInt((long) cx + radius);
        int maxZ = clampToInt((long) cz + radius);
        double radiusSquared = (double) radius * radius;

        return spatialIndex.candidates(world, minX, minZ, maxX, maxZ).stream()
                .map(claims::get)
                .filter(Objects::nonNull)
                .filter(c -> distanceSquared(c, cx, cz) <= radiusSquared)
                .sorted(Comparator.comparingDouble(c -> distanceSquared(c, cx, cz)))
                .collect(Collectors.toList());
    }

    private static double distanceSquared(Claim claim, int x, int z) {
        int nearX = Math.max(claim.getMinX(), Math.min(x, claim.getMaxX()));
        int nearZ = Math.max(claim.getMinZ(), Math.min(z, claim.getMaxZ()));
        double dx = (double) x - nearX;
        double dz = (double) z - nearZ;
        return dx * dx + dz * dz;
    }

    private static int clampToInt(long value) {
        if (value < Integer.MIN_VALUE) return Integer.MIN_VALUE;
        if (value > Integer.MAX_VALUE) return Integer.MAX_VALUE;
        return (int) value;
    }

    private <T> java.util.concurrent.CompletableFuture<T> onMain(java.util.concurrent.Callable<T> action) {
        java.util.concurrent.CompletableFuture<T> result = new java.util.concurrent.CompletableFuture<>();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            try { result.complete(action.call()); }
            catch (Throwable error) { result.completeExceptionally(error); }
        });
        return result;
    }

    private record PersistenceResult(Throwable error) {}

    // =========================================================================
    // Private helpers
    // =========================================================================

    public int syncAllClaimFlagsFromConfig() {
        int synced = 0;
        for (Claim claim : claims.values()) {
            applyDefaultFlags(claim);
            saveClaim(claim);
            synced++;
        }
        return synced;
    }

    public void applyDefaultFlags(Claim claim) {
        for (dev.ultimateclaims.data.ClaimFlag flag : dev.ultimateclaims.data.ClaimFlag.values()) {
            boolean def = plugin.getConfig()
                    .getBoolean("default-flags." + flag.getConfigKey(), flag.getDefaultValue());
            claim.setFlag(flag, def);
        }
    }
}
