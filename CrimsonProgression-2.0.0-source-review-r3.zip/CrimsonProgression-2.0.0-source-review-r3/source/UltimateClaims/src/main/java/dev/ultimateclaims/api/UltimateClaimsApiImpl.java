package dev.ultimateclaims.api;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.PlayerData;
import org.bukkit.Bukkit;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Thread-safe service implementation used by other plugins.
 *
 * <p>One claim-block mutation per player may be in flight. The future is only
 * completed successfully after the new balance is durably written to SQLite.
 * A failed write is rolled back on the Bukkit thread when it is still safe to
 * do so; otherwise the operation fails loudly without overwriting a later
 * administrator/player change.</p>
 */
public final class UltimateClaimsApiImpl implements UltimateClaimsApi {
    private final UltimateClaims plugin;
    private final Set<UUID> mutationsInFlight = ConcurrentHashMap.newKeySet();

    public UltimateClaimsApiImpl(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @Override
    public CompletableFuture<Boolean> addClaimBlocks(UUID playerId, int amount) {
        if (playerId == null || amount <= 0) return CompletableFuture.completedFuture(false);
        if (!mutationsInFlight.add(playerId)) return CompletableFuture.completedFuture(false);

        CompletableFuture<Boolean> result = new CompletableFuture<>();
        Runnable mutation = () -> {
            PlayerData data;
            int previous;
            int expected;
            try {
                data = plugin.getPlayerDataManager().getOrCreate(playerId, "Unknown");
                previous = data.getClaimBlocks();
                long candidate = (long) previous + amount;
                if (candidate > Integer.MAX_VALUE) {
                    mutationsInFlight.remove(playerId);
                    result.complete(false);
                    return;
                }
                expected = (int) candidate;
                data.setClaimBlocks(expected);
            } catch (RuntimeException exception) {
                mutationsInFlight.remove(playerId);
                result.completeExceptionally(exception);
                return;
            }

            plugin.getDataManager().savePlayerAsync(data).whenComplete((ignored, error) -> {
                if (error == null) {
                    mutationsInFlight.remove(playerId);
                    result.complete(true);
                    return;
                }

                Bukkit.getScheduler().runTask(plugin, () -> {
                    try {
                        // Never clobber a later administrator or gameplay mutation.
                        if (data.getClaimBlocks() == expected) {
                            data.setClaimBlocks(previous);
                        } else {
                            plugin.getLogger().severe("Could not safely roll back claim-block API mutation for "
                                    + playerId + ": balance changed again after failed persistence");
                        }
                    } finally {
                        mutationsInFlight.remove(playerId);
                        plugin.getLogger().log(Level.SEVERE,
                                "Could not persist claim-block API mutation for " + playerId, error);
                        result.completeExceptionally(error);
                    }
                });
            });
        };

        if (Bukkit.isPrimaryThread()) mutation.run();
        else Bukkit.getScheduler().runTask(plugin, mutation);
        return result;
    }

    @Override
    public CompletableFuture<Integer> getAvailableClaimBlocks(UUID playerId) {
        CompletableFuture<Integer> result = new CompletableFuture<>();
        Runnable read = () -> {
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(playerId);
            result.complete(data == null ? 0 : data.getAvailableBlocks());
        };
        if (Bukkit.isPrimaryThread()) read.run();
        else Bukkit.getScheduler().runTask(plugin, read);
        return result;
    }
}
