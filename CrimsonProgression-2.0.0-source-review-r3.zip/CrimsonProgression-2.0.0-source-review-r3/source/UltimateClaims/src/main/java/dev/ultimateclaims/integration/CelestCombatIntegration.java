package dev.ultimateclaims.integration;

import dev.ultimateclaims.UltimateClaims;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Level;

public final class CelestCombatIntegration {
    private final UltimateClaims plugin;
    private volatile YamlConfiguration config;
    private volatile Object apiInstance;
    private volatile Method combatMethod;
    private volatile boolean available;
    private volatile boolean invocationFailureLogged;

    public CelestCombatIntegration(UltimateClaims plugin, YamlConfiguration config) {
        this.plugin = plugin;
        this.config = config;
        hook();
    }

    public void reload(YamlConfiguration config) {
        this.config = config;
        hook();
    }

    public void hook() {
        available = false;
        apiInstance = null;
        combatMethod = null;
        invocationFailureLogged = false;

        if (!config.getBoolean("enabled", true)) {
            plugin.getLogger().info("CelestCombatPro integration is disabled in combat.yml.");
            return;
        }

        Plugin detected = null;
        for (String name : config.getStringList("celestcombatpro.plugin-names")) {
            Plugin candidate = Bukkit.getPluginManager().getPlugin(name);
            if (candidate != null && candidate.isEnabled()) {
                detected = candidate;
                break;
            }
        }
        if (detected == null) {
            plugin.getLogger().warning("CelestCombatPro integration is configured but no supported plugin name is enabled.");
            return;
        }

        List<String> providerClasses = config.getStringList("celestcombatpro.api-provider-classes");
        List<String> providerMethods = config.getStringList("celestcombatpro.provider-methods");
        List<String> apiClasses = config.getStringList("celestcombatpro.combat-api-classes");
        List<String> checkMethods = config.getStringList("celestcombatpro.combat-check-methods");

        Throwable lastFailure = null;
        for (String providerClassName : providerClasses) {
            for (String providerMethodName : providerMethods) {
                try {
                    Class<?> providerClass = Class.forName(providerClassName, true, detected.getClass().getClassLoader());
                    Method providerMethod = providerClass.getMethod(providerMethodName);
                    Object candidateApi = providerMethod.invoke(null);
                    if (candidateApi == null) continue;

                    Method candidateCheck = findCombatMethod(candidateApi, apiClasses, checkMethods, detected);
                    if (candidateCheck == null) continue;

                    apiInstance = candidateApi;
                    combatMethod = candidateCheck;
                    available = true;
                    plugin.getLogger().info("CelestCombatPro integration enabled using "
                            + providerClassName + "#" + providerMethodName + " and "
                            + candidateCheck.getDeclaringClass().getName() + "#" + candidateCheck.getName() + ".");
                    return;
                } catch (Throwable failure) {
                    lastFailure = failure;
                }
            }
        }

        String mode = config.getString("fail-mode", "DISABLE_WITH_SEVERE_LOG");
        Level level = mode.toUpperCase().contains("SEVERE") ? Level.SEVERE : Level.WARNING;
        plugin.getLogger().log(level,
                "CelestCombatPro was detected, but no configured API signature could be hooked. "
                        + "Combat claim-entry protection is disabled rather than silently pretending to work.",
                lastFailure);
    }

    private Method findCombatMethod(Object candidateApi, List<String> apiClasses,
                                    List<String> checkMethods, Plugin detected) {
        for (String methodName : checkMethods) {
            try {
                return candidateApi.getClass().getMethod(methodName, Player.class);
            } catch (NoSuchMethodException ignored) {
            }
        }
        for (String className : apiClasses) {
            try {
                Class<?> apiClass = Class.forName(className, true, detected.getClass().getClassLoader());
                for (String methodName : checkMethods) {
                    try {
                        return apiClass.getMethod(methodName, Player.class);
                    } catch (NoSuchMethodException ignored) {
                    }
                }
            } catch (ClassNotFoundException ignored) {
            }
        }
        return null;
    }

    public boolean available() {
        return available;
    }

    public boolean isInCombat(Player player) {
        if (!available || apiInstance == null || combatMethod == null || player == null) return false;
        try {
            Object result = combatMethod.invoke(apiInstance, player);
            return result instanceof Boolean value && value;
        } catch (Throwable failure) {
            if (!invocationFailureLogged) {
                invocationFailureLogged = true;
                plugin.getLogger().log(Level.SEVERE,
                        "CelestCombatPro API invocation failed. Claim-entry protection is being disabled.", failure);
            }
            available = false;
            return false;
        }
    }
}
