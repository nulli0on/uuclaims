package dev.ultimateclaims.integration;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/** Small, isolated reflection utility used only for optional plugin integrations. */
final class ReflectionAccess {
    private ReflectionAccess() {
    }

    static Class<?> type(String name, ClassLoader loader) {
        try {
            return Class.forName(name, true, loader);
        } catch (ClassNotFoundException exception) {
            throw new IllegalStateException("Missing integration class: " + name, exception);
        }
    }

    static Object construct(Class<?> type, Object... args) {
        Constructor<?> constructor = Arrays.stream(type.getConstructors())
                .filter(candidate -> candidate.getParameterCount() == args.length)
                .filter(candidate -> compatible(candidate.getParameterTypes(), args))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No compatible constructor for " + type.getName()));
        try {
            return constructor.newInstance(args);
        } catch (InstantiationException | IllegalAccessException exception) {
            throw new IllegalStateException("Cannot construct " + type.getName(), exception);
        } catch (InvocationTargetException exception) {
            throw propagate("Constructor failed for " + type.getName(), exception.getCause());
        }
    }

    static Object invoke(Object target, String name, Object... args) {
        if (target == null) throw new IllegalArgumentException("target");
        Class<?> type = target instanceof Class<?> staticType ? staticType : target.getClass();
        Method method = Arrays.stream(type.getMethods())
                .filter(candidate -> candidate.getName().equals(name))
                .filter(candidate -> candidate.getParameterCount() == args.length)
                .filter(candidate -> compatible(candidate.getParameterTypes(), args))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No compatible method " + type.getName() + "#" + name));
        try {
            return method.invoke(target instanceof Class<?> ? null : target, args);
        } catch (IllegalAccessException exception) {
            throw new IllegalStateException("Cannot invoke " + method, exception);
        } catch (InvocationTargetException exception) {
            throw propagate("Invocation failed: " + method, exception.getCause());
        }
    }

    static Object array(Class<?> componentType, Object... values) {
        Object array = Array.newInstance(componentType, values.length);
        for (int i = 0; i < values.length; i++) Array.set(array, i, values[i]);
        return array;
    }

    private static RuntimeException propagate(String message, Throwable cause) {
        if (cause instanceof RuntimeException runtime) return runtime;
        if (cause instanceof Error error) throw error;
        return new IllegalStateException(message, cause);
    }

    private static boolean compatible(Class<?>[] parameters, Object[] args) {
        for (int index = 0; index < parameters.length; index++) {
            Object argument = args[index];
            if (argument == null) continue;
            if (!wrap(parameters[index]).isInstance(argument)) return false;
        }
        return true;
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == char.class) return Character.class;
        return type;
    }
}
