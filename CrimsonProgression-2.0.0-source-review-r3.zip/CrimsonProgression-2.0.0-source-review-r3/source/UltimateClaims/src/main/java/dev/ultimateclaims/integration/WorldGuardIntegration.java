package dev.ultimateclaims.integration;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.restriction.WorldNameMatcher;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Optional WorldGuard 7.x adapter.
 *
 * <p>The adapter intentionally uses a narrow reflection boundary. This keeps UltimateClaims loadable when
 * WorldGuard is absent and avoids pinning the build to a particular 7.x patch while still calling the official
 * RegionManager/ProtectedRegion API at runtime. Every reflected class and method is validated during setup.</p>
 */
public final class WorldGuardIntegration {
    private static final String REGION_PREFIX = "uc_";
    private static final String DEFAULT_CLAIMING_FLAG_NAME = "ultimateclaims-claiming";

    private final UltimateClaims plugin;
    private volatile Api api;
    private volatile Object claimingFlag;
    private volatile String claimingFlagName = DEFAULT_CLAIMING_FLAG_NAME;
    private volatile boolean claimingFlagDefaultAllow = true;

    public WorldGuardIntegration(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    public void setup() {
        loadFlagConfiguration();
        Plugin worldGuardPlugin = Bukkit.getPluginManager().getPlugin("WorldGuard");
        if (worldGuardPlugin == null) {
            api = null;
            claimingFlag = null;
            plugin.getLogger().info("WorldGuard not found. Internal claim protection remains active.");
            return;
        }
        try {
            Api loaded = Api.load(worldGuardPlugin.getClass().getClassLoader());
            loaded.validate();
            api = loaded;
            registerClaimingFlag();
            plugin.getLogger().info("WorldGuard 7.x integration is available.");
        } catch (RuntimeException error) {
            api = null;
            claimingFlag = null;
            plugin.getLogger().log(Level.SEVERE,
                    "WorldGuard was found but its required 7.x API could not be initialized. " +
                            "WorldGuard claim restrictions are unavailable.", error);
        }
    }

    public boolean isAvailable() {
        return api != null;
    }

    private void loadFlagConfiguration() {
        YamlConfiguration restrictions = new YamlConfiguration();
        File file = new File(plugin.getDataFolder(), "restrictions.yml");
        if (file.isFile()) {
            restrictions = YamlConfiguration.loadConfiguration(file);
        } else {
            try (InputStream stream = plugin.getResource("restrictions.yml")) {
                if (stream != null) {
                    restrictions = YamlConfiguration.loadConfiguration(
                            new InputStreamReader(stream, StandardCharsets.UTF_8));
                }
            } catch (Exception error) {
                plugin.getLogger().log(Level.WARNING,
                        "Could not read bundled restrictions.yml during WorldGuard flag registration.", error);
            }
        }

        String configured = restrictions.getString(
                "worldguard.custom-flag.name", DEFAULT_CLAIMING_FLAG_NAME).trim().toLowerCase(java.util.Locale.ROOT);
        if (!configured.matches("[a-z0-9][a-z0-9-]{0,63}")) {
            plugin.getLogger().severe("Invalid WorldGuard custom flag name '" + configured
                    + "'. Using " + DEFAULT_CLAIMING_FLAG_NAME + ".");
            configured = DEFAULT_CLAIMING_FLAG_NAME;
        }
        claimingFlagName = configured;
        claimingFlagDefaultAllow = restrictions.getBoolean("worldguard.custom-flag.default-allow", true);
    }

    public String claimingFlagName() {
        return claimingFlagName;
    }

    private void registerClaimingFlag() {
        Api loaded = api;
        if (loaded == null) return;
        try {
            Object registry = loaded.flagRegistry();
            Object proposed = ReflectionAccess.construct(loaded.stateFlagType, claimingFlagName, claimingFlagDefaultAllow);
            try {
                ReflectionAccess.invoke(registry, "register", proposed);
                claimingFlag = proposed;
            } catch (RuntimeException registrationFailure) {
                Object existing = ReflectionAccess.invoke(registry, "get", claimingFlagName);
                if (existing != null && loaded.stateFlagType.isInstance(existing)) {
                    claimingFlag = existing;
                } else {
                    claimingFlag = null;
                    plugin.getLogger().log(Level.SEVERE,
                            "WorldGuard flag '" + claimingFlagName + "' could not be registered and no compatible " +
                                    "existing StateFlag was found.", registrationFailure);
                }
            }
        } catch (RuntimeException error) {
            claimingFlag = null;
            plugin.getLogger().log(Level.SEVERE, "Could not register WorldGuard claiming flag.", error);
        }
    }

    public RestrictionResult checkClaimCreation(String worldName, int minX, int minZ,
                                                int maxX, int maxZ, YamlConfiguration restrictions) {
        Api loaded = api;
        if (loaded == null) return RestrictionResult.denied("WORLDGUARD_UNAVAILABLE", worldName);
        World world = Bukkit.getWorld(worldName);
        if (world == null) return RestrictionResult.denied("WORLD_UNLOADED", worldName);
        Object manager = regionManager(world);
        if (manager == null) return RestrictionResult.denied("WORLDGUARD_MANAGER_UNAVAILABLE", worldName);

        Object candidate;
        Object applicable;
        try {
            candidate = cuboid(loaded, "__ultimateclaims_candidate__", world,
                    minX, minZ, maxX, maxZ);
            applicable = ReflectionAccess.invoke(manager, "getApplicableRegions", candidate);
        } catch (RuntimeException error) {
            plugin.getLogger().log(Level.WARNING, "WorldGuard overlap query failed for " + worldName, error);
            return restrictions.getBoolean("worldguard.fail-closed", true)
                    ? RestrictionResult.denied("WORLDGUARD_QUERY_FAILED", worldName)
                    : RestrictionResult.allow();
        }

        boolean includeGlobal = restrictions.getBoolean("worldguard.include-global-region", false);
        WorldNameMatcher ignored = matcher(restrictions, "worldguard.ignored-region-ids");
        WorldNameMatcher deniedGlobal = matcher(restrictions, "worldguard.denied-region-ids.global");
        WorldNameMatcher deniedWorld = matcher(restrictions,
                "worldguard.denied-region-ids.worlds." + worldName);

        Object regionValues = ReflectionAccess.invoke(applicable, "getRegions");
        if (regionValues instanceof Collection<?> regions) {
            for (Object region : regions) {
                String id = String.valueOf(ReflectionAccess.invoke(region, "getId"));
                if (!includeGlobal && "__global__".equals(id)) continue;
                if (ignored.matches(id)) continue;
                if (deniedGlobal.matches(id) || deniedWorld.matches(id)) {
                    return RestrictionResult.denied("WORLDGUARD_REGION", id);
                }
            }
        }

        Object flag = claimingFlag;
        if (flag != null && restrictions.getBoolean("worldguard.custom-flag.enabled", true)) {
            try {
                Object flagArray = ReflectionAccess.array(loaded.stateFlagType, flag);
                Object state = ReflectionAccess.invoke(applicable, "queryState", null, flagArray);
                if (state != null && "DENY".equals(String.valueOf(state))) {
                    return RestrictionResult.denied("WORLDGUARD_FLAG", claimingFlagName);
                }
            } catch (RuntimeException error) {
                plugin.getLogger().log(Level.WARNING, "WorldGuard custom-flag query failed.", error);
                if (restrictions.getBoolean("worldguard.fail-closed", true)) {
                    return RestrictionResult.denied("WORLDGUARD_FLAG_QUERY_FAILED", claimingFlagName);
                }
            }
        }
        return RestrictionResult.allow();
    }

    private WorldNameMatcher matcher(YamlConfiguration config, String path) {
        return new WorldNameMatcher(false,
                config.getStringList(path + ".exact"),
                config.getStringList(path + ".wildcard"),
                config.getStringList(path + ".regex"));
    }

    public void createRegion(Claim claim) {
        if (!shouldExportMarkers()) return;
        runSync(() -> createRegionNow(claim));
    }

    public void deleteRegion(Claim claim) {
        if (!isAvailable()) return;
        runSync(() -> deleteRegionNow(claim));
    }

    public void addMember(Claim claim, UUID uuid) {
        if (!shouldExportMarkers()) return;
        modify(claim, region -> {
            Object members = ReflectionAccess.invoke(region, "getMembers");
            ReflectionAccess.invoke(members, "addPlayer", uuid);
        });
    }

    public void removeMember(Claim claim, UUID uuid) {
        if (!shouldExportMarkers()) return;
        modify(claim, region -> {
            Object members = ReflectionAccess.invoke(region, "getMembers");
            ReflectionAccess.invoke(members, "removePlayer", uuid);
        });
    }

    public void updateRegion(Claim claim) {
        if (!shouldExportMarkers()) return;
        runSync(() -> {
            deleteRegionNow(claim);
            createRegionNow(claim);
        });
    }

    public void cleanupManagedRegionsIfDisabled() {
        if (!isAvailable() || shouldExportMarkers()) return;
        if (!plugin.getConfig().getBoolean("worldguard.cleanup-managed-regions-when-disabled", true)) return;
        runSync(() -> {
            int removed = 0;
            for (World world : Bukkit.getWorlds()) {
                Object manager = regionManager(world);
                if (manager == null) continue;
                Object raw = ReflectionAccess.invoke(manager, "getRegions");
                if (!(raw instanceof Map<?, ?> regions)) continue;
                List<String> ids = regions.keySet().stream().map(String::valueOf)
                        .filter(this::isManagedRegionId).toList();
                for (String id : ids) {
                    ReflectionAccess.invoke(manager, "removeRegion", id);
                    removed++;
                }
                if (!ids.isEmpty()) save(manager);
            }
            if (removed > 0) plugin.getLogger().warning("Removed " + removed + " obsolete WorldGuard marker regions.");
        });
    }

    private boolean shouldExportMarkers() {
        return isAvailable() && plugin.getConfig().getBoolean("worldguard.enabled", false);
    }

    private void createRegionNow(Claim claim) {
        Api loaded = api;
        if (loaded == null) return;
        World world = Bukkit.getWorld(claim.getWorld());
        if (world == null) return;
        Object manager = regionManager(world);
        if (manager == null) return;
        Object region = cuboid(loaded, claim.getWgRegionId(), world,
                claim.getMinX(), claim.getMinZ(), claim.getMaxX(), claim.getMaxZ());
        ReflectionAccess.invoke(region, "setPriority", plugin.getConfig().getInt("worldguard.marker-priority", 1));
        Object owners = ReflectionAccess.invoke(region, "getOwners");
        ReflectionAccess.invoke(owners, "addPlayer", claim.getOwner());
        Object members = ReflectionAccess.invoke(region, "getMembers");
        for (UUID trusted : claim.getTrustedPlayers().keySet()) {
            ReflectionAccess.invoke(members, "addPlayer", trusted);
        }
        ReflectionAccess.invoke(manager, "addRegion", region);
        save(manager);
    }

    private void deleteRegionNow(Claim claim) {
        World world = Bukkit.getWorld(claim.getWorld());
        if (world == null) return;
        Object manager = regionManager(world);
        if (manager == null) return;
        Object region = ReflectionAccess.invoke(manager, "getRegion", claim.getWgRegionId());
        if (region == null) return;
        ReflectionAccess.invoke(manager, "removeRegion", claim.getWgRegionId());
        save(manager);
    }

    private void modify(Claim claim, RegionModifier modifier) {
        runSync(() -> {
            World world = Bukkit.getWorld(claim.getWorld());
            if (world == null) return;
            Object manager = regionManager(world);
            if (manager == null) return;
            Object region = ReflectionAccess.invoke(manager, "getRegion", claim.getWgRegionId());
            if (region == null) return;
            modifier.modify(region);
            save(manager);
        });
    }

    private Object cuboid(Api loaded, String id, World world, int minX, int minZ, int maxX, int maxZ) {
        Object min = ReflectionAccess.invoke(loaded.blockVectorType, "at", minX, world.getMinHeight(), minZ);
        Object max = ReflectionAccess.invoke(loaded.blockVectorType, "at", maxX, world.getMaxHeight() - 1, maxZ);
        return ReflectionAccess.construct(loaded.cuboidRegionType, id, min, max);
    }

    private boolean isManagedRegionId(String id) {
        return id != null && id.matches(REGION_PREFIX + "[0-9a-f]{16}");
    }

    private Object regionManager(World world) {
        Api loaded = api;
        if (loaded == null) return null;
        try {
            Object adaptedWorld = ReflectionAccess.invoke(loaded.bukkitAdapterType, "adapt", world);
            Object worldGuard = ReflectionAccess.invoke(loaded.worldGuardType, "getInstance");
            Object platform = ReflectionAccess.invoke(worldGuard, "getPlatform");
            Object container = ReflectionAccess.invoke(platform, "getRegionContainer");
            return ReflectionAccess.invoke(container, "get", adaptedWorld);
        } catch (RuntimeException error) {
            plugin.getLogger().log(Level.WARNING, "Failed to get WorldGuard region manager for " + world.getName(), error);
            return null;
        }
    }

    private void save(Object manager) {
        try {
            ReflectionAccess.invoke(manager, "save");
        } catch (RuntimeException error) {
            plugin.getLogger().log(Level.WARNING, "Failed to save WorldGuard marker regions.", error);
        }
    }

    private void runSync(Runnable runnable) {
        if (Bukkit.isPrimaryThread()) runnable.run();
        else Bukkit.getScheduler().runTask(plugin, runnable);
    }

    @FunctionalInterface
    private interface RegionModifier {
        void modify(Object region);
    }

    private record Api(Class<?> worldGuardType, Class<?> bukkitAdapterType, Class<?> blockVectorType,
                       Class<?> cuboidRegionType, Class<?> stateFlagType) {
        static Api load(ClassLoader loader) {
            return new Api(
                    ReflectionAccess.type("com.sk89q.worldguard.WorldGuard", loader),
                    ReflectionAccess.type("com.sk89q.worldedit.bukkit.BukkitAdapter", loader),
                    ReflectionAccess.type("com.sk89q.worldedit.math.BlockVector3", loader),
                    ReflectionAccess.type("com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion", loader),
                    ReflectionAccess.type("com.sk89q.worldguard.protection.flags.StateFlag", loader)
            );
        }

        void validate() {
            Object instance = ReflectionAccess.invoke(worldGuardType, "getInstance");
            Object registry = ReflectionAccess.invoke(instance, "getFlagRegistry");
            if (registry == null) throw new IllegalStateException("WorldGuard returned no FlagRegistry");
        }

        Object flagRegistry() {
            Object instance = ReflectionAccess.invoke(worldGuardType, "getInstance");
            return ReflectionAccess.invoke(instance, "getFlagRegistry");
        }
    }

    public record RestrictionResult(boolean allowed, String reason, String detail) {
        public static RestrictionResult allow() {
            return new RestrictionResult(true, "", "");
        }

        public static RestrictionResult denied(String reason, String detail) {
            return new RestrictionResult(false, reason, detail == null ? "" : detail);
        }
    }
}
