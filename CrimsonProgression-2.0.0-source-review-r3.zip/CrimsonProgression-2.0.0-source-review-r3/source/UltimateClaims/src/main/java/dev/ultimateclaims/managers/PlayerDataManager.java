package dev.ultimateclaims.managers;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.ClaimSelection;
import dev.ultimateclaims.data.PlayerData;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Manages in-memory player data and claim selections.
 */
public class PlayerDataManager {

    private final UltimateClaims plugin;

    private final Map<UUID, PlayerData>     playerDataMap = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, ClaimSelection> selectionsMap = new java.util.concurrent.ConcurrentHashMap<>();

    /** Tracks which claim UUID each player is currently standing in (for action bar). */
    private final Map<UUID, UUID> playerInClaim = new java.util.concurrent.ConcurrentHashMap<>();

    /** Tracks which players are in "claiming mode" (holding the tool after /claim). */
    private final Set<UUID> claimingMode = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public PlayerDataManager(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    // ── Player data ───────────────────────────────────────────────────────────

    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.get(uuid);
    }

    /** Gets player data, creating a new entry with the default block count if absent. */
    public PlayerData getOrCreate(Player player) {
        return playerDataMap.computeIfAbsent(player.getUniqueId(), uuid -> {
            int defaultBlocks = plugin.getConfig().getInt("default-claim-blocks", 100);
            return new PlayerData(uuid, player.getName(), defaultBlocks);
        });
    }

    /** Gets player data by UUID for API integrations without performing a Mojang lookup. */
    public PlayerData getOrCreate(UUID uuid, String lastKnownName) {
        return playerDataMap.computeIfAbsent(uuid, ignored -> {
            int defaultBlocks = plugin.getConfig().getInt("default-claim-blocks", 100);
            return new PlayerData(uuid, lastKnownName, defaultBlocks);
        });
    }

    public void updatePlayerName(Player player) {
        PlayerData data = getPlayerData(player.getUniqueId());
        if (data != null && !data.getPlayerName().equals(player.getName())) {
            data.setPlayerName(player.getName());
        }
    }

    /** Called by DataManager during startup to inject loaded data. */
    public void addPlayerDataDirectly(PlayerData data) {
        playerDataMap.put(data.getUuid(), data);
    }

    public Collection<PlayerData> getAllPlayerData() {
        return List.copyOf(playerDataMap.values());
    }

    // ── Claim selections ──────────────────────────────────────────────────────

    public ClaimSelection getSelection(UUID uuid) {
        return selectionsMap.computeIfAbsent(uuid, k -> new ClaimSelection());
    }

    public void clearSelection(UUID uuid) {
        ClaimSelection sel = selectionsMap.get(uuid);
        if (sel != null) sel.clear();
    }

    public boolean hasCompleteSelection(UUID uuid) {
        ClaimSelection sel = selectionsMap.get(uuid);
        return sel != null && sel.isComplete();
    }

    // ── Claiming mode ─────────────────────────────────────────────────────────

    public void enterClaimingMode(UUID uuid)  { claimingMode.add(uuid); }
    public void leaveClaimingMode(UUID uuid)  { claimingMode.remove(uuid); }
    public boolean isInClaimingMode(UUID uuid){ return claimingMode.contains(uuid); }

    // ── Claim entry tracking ──────────────────────────────────────────────────

    public UUID getCurrentClaimId(UUID playerUuid) {
        return playerInClaim.get(playerUuid);
    }

    public void setCurrentClaim(UUID playerUuid, UUID claimId) {
        if (claimId == null) {
            playerInClaim.remove(playerUuid);
        } else {
            playerInClaim.put(playerUuid, claimId);
        }
    }
}
