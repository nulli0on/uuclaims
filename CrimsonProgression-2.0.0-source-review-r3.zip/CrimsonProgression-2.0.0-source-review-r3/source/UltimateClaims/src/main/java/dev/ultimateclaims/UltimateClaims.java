package dev.ultimateclaims;

import dev.ultimateclaims.api.*;
import dev.ultimateclaims.commands.ClaimAdminCommand;
import dev.ultimateclaims.commands.ClaimCommand;
import dev.ultimateclaims.gui.FlagsGUI;
import dev.ultimateclaims.integration.*;
import dev.ultimateclaims.listeners.*;
import dev.ultimateclaims.managers.*;
import dev.ultimateclaims.restriction.ClaimRestrictionService;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.*;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.logging.Level;

public final class UltimateClaims extends JavaPlugin {
    private ClaimManager claimManager;
    private PlayerDataManager playerDataManager;
    private DataManager dataManager;
    private WorldGuardIntegration worldGuardIntegration;
    private CelestCombatIntegration celestCombatIntegration;
    private ClaimRestrictionService restrictionService;
    private FlagsGUI flagsGUI;
    private ClaimToolListener claimToolListener;
    private NamespacedKey claimingToolKey;
    private BukkitTask autoSaveTask;

    private FileConfiguration guiConfig;
    private FileConfiguration messages;
    private YamlConfiguration restrictionsConfig;
    private YamlConfiguration combatConfig;
    private YamlConfiguration storageConfig;

    @Override
    public void onLoad() {
        worldGuardIntegration = new WorldGuardIntegration(this);
        worldGuardIntegration.setup();
    }

    @Override
    public void onEnable() {
        try {
            saveDefaultConfig();
            saveVersionedResource("gui.yml", 2);
            saveVersionedResource("messages.yml", 2);
            saveIfMissing("restrictions.yml");
            saveIfMissing("combat.yml");
            saveIfMissing("storage.yml");

            loadSupplementalConfigs();
            claimingToolKey = new NamespacedKey(this, "claiming_tool");

            claimManager = new ClaimManager(this);
            playerDataManager = new PlayerDataManager(this);
            dataManager = new DataManager(this);
            dataManager.loadAll();

            restrictionService = new ClaimRestrictionService(this);
            flagsGUI = new FlagsGUI(this);

            claimToolListener = new ClaimToolListener(this);
            getServer().getPluginManager().registerEvents(claimToolListener, this);
            getServer().getPluginManager().registerEvents(new ClaimProtectionListener(this), this);
            getServer().getPluginManager().registerEvents(new ClaimEnterLeaveListener(this), this);
            getServer().getPluginManager().registerEvents(new GUIListener(this), this);
            getServer().getPluginManager().registerEvents(new PlayerJoinQuitListener(this), this);

            ClaimCommand claimCommand = new ClaimCommand(this);
            requireCommand("claim").setExecutor(claimCommand);
            requireCommand("claim").setTabCompleter(claimCommand);
            ClaimAdminCommand adminCommand = new ClaimAdminCommand(this);
            requireCommand("claimadmin").setExecutor(adminCommand);
            requireCommand("claimadmin").setTabCompleter(adminCommand);

            if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
                new PlaceholderAPIIntegration(this).register();
                getLogger().info("PlaceholderAPI integration enabled.");
            }

            celestCombatIntegration = new CelestCombatIntegration(this, combatConfig);
            if (combatConfig.getBoolean("enabled", true)) {
                getServer().getPluginManager().registerEvents(
                        new CelestCombatListener(this, celestCombatIntegration), this);
            }

            UltimateClaimsApi api = new UltimateClaimsApiImpl(this);
            getServer().getServicesManager().register(UltimateClaimsApi.class, api, this, ServicePriority.Normal);

            if (getConfig().getBoolean("flag-config.apply-default-flags-to-existing-claims-on-startup", false)) {
                int synchronizedClaims = claimManager.syncAllClaimFlagsFromConfig();
                getLogger().warning("Explicitly replaced default flags on " + synchronizedClaims + " existing claims.");
            }

            worldGuardIntegration.cleanupManagedRegionsIfDisabled();
            startAutoSaveTask();
            getLogger().info("UltimateClaims " + getDescription().getVersion() + " enabled.");
        } catch (Exception exception) {
            getLogger().log(Level.SEVERE, "UltimateClaims failed to start safely.", exception);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        getServer().getServicesManager().unregisterAll(this);
        if (autoSaveTask != null) autoSaveTask.cancel();
        if (claimToolListener != null) claimToolListener.shutdown();
        if (dataManager != null) dataManager.close();
    }

    public int reloadAllConfigs() {
        reloadConfig();
        loadSupplementalConfigs();
        if (restrictionService != null) restrictionService.reload();
        if (celestCombatIntegration != null) celestCombatIntegration.reload(combatConfig);
        startAutoSaveTask();

        if (worldGuardIntegration != null) worldGuardIntegration.cleanupManagedRegionsIfDisabled();
        if (claimManager != null
                && getConfig().getBoolean("flag-config.apply-default-flags-to-existing-claims-on-reload", false)) {
            int synchronizedClaims = claimManager.syncAllClaimFlagsFromConfig();
            if (dataManager != null) dataManager.saveAll();
            return synchronizedClaims;
        }
        return 0;
    }

    private org.bukkit.command.PluginCommand requireCommand(String name) {
        var command = getCommand(name);
        if (command == null) throw new IllegalStateException("Missing command in plugin.yml: " + name);
        return command;
    }

    private void startAutoSaveTask() {
        if (autoSaveTask != null) autoSaveTask.cancel();
        autoSaveTask = null;
        if (!getConfig().getBoolean("auto-save.enabled", true) || dataManager == null) return;
        long minutes = Math.max(1L, getConfig().getLong("auto-save.interval-minutes", 10L));
        autoSaveTask = getServer().getScheduler().runTaskTimer(
                this, dataManager::saveAll, minutes * 1200L, minutes * 1200L);
    }

    private void saveIfMissing(String resource) {
        File target = new File(getDataFolder(), resource);
        if (!target.exists()) saveResource(resource, false);
    }

    private void loadSupplementalConfigs() {
        loadGuiConfig();
        loadMessages();
        restrictionsConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "restrictions.yml"));
        combatConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "combat.yml"));
        storageConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "storage.yml"));
    }

    private void saveVersionedResource(String resourceName, int bundledVersion) {
        File file = new File(getDataFolder(), resourceName);
        if (!file.exists()) {
            saveResource(resourceName, false);
            return;
        }
        YamlConfiguration existing = YamlConfiguration.loadConfiguration(file);
        int currentVersion = existing.getInt("config-version", 0);
        if (currentVersion >= bundledVersion) return;
        File backup = new File(getDataFolder(), resourceName + ".v" + currentVersion + ".bak");
        try (InputStream stream = getResource(resourceName)) {
            if (stream == null) throw new FileNotFoundException("Bundled resource missing: " + resourceName);
            YamlConfiguration bundled = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(stream, StandardCharsets.UTF_8));
            Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            for (String key : bundled.getKeys(true)) {
                if (bundled.isConfigurationSection(key) || existing.contains(key)) continue;
                existing.set(key, bundled.get(key));
            }
            existing.set("config-version", bundledVersion);
            existing.save(file);
            getLogger().warning("Merged new defaults into " + resourceName
                    + " and backed up the previous file as " + backup.getName());
        } catch (Exception exception) {
            getLogger().log(Level.WARNING, "Could not update " + resourceName, exception);
        }
    }

    private void loadGuiConfig() {
        File file = new File(getDataFolder(), "gui.yml");
        guiConfig = YamlConfiguration.loadConfiguration(file);
        try (InputStream defaults = getResource("gui.yml")) {
            if (defaults != null) {
                guiConfig.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defaults, StandardCharsets.UTF_8)));
            }
        } catch (IOException exception) {
            getLogger().log(Level.WARNING, "Could not load gui.yml defaults", exception);
        }
    }

    private void loadMessages() {
        File file = new File(getDataFolder(), "messages.yml");
        messages = YamlConfiguration.loadConfiguration(file);
        try (InputStream defaults = getResource("messages.yml")) {
            if (defaults != null) {
                messages.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defaults, StandardCharsets.UTF_8)));
            }
        } catch (IOException exception) {
            getLogger().log(Level.WARNING, "Could not load messages.yml defaults", exception);
        }
    }

    public ClaimManager getClaimManager() { return claimManager; }
    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public DataManager getDataManager() { return dataManager; }
    public WorldGuardIntegration getWorldGuardIntegration() { return worldGuardIntegration; }
    public ClaimRestrictionService getRestrictionService() { return restrictionService; }
    public FlagsGUI getFlagsGUI() { return flagsGUI; }
    public ClaimToolListener getClaimToolListener() { return claimToolListener; }
    public NamespacedKey getClaimingToolKey() { return claimingToolKey; }
    public FileConfiguration getGuiConfig() { return guiConfig; }
    public FileConfiguration getMessages() { return messages; }
    public YamlConfiguration getRestrictionsConfig() { return restrictionsConfig; }
    public YamlConfiguration getCombatConfig() { return combatConfig; }
    public YamlConfiguration getStorageConfig() { return storageConfig; }
}
