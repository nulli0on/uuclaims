package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimSelection;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles claiming-tool interactions and particle previews.
 */
public class ClaimToolListener implements Listener {

    private static final int PARTICLE_HARD_CAP = 2_000;
    private static final int CLICK_PARTICLE_HARD_CAP = 256;
    private static final int Y_RANGE_HARD_CAP = 32;

    private final UltimateClaims plugin;
    private final Map<UUID, BukkitTask> selectionParticleTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> claimBorderTasks = new HashMap<>();

    public ClaimToolListener(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    // ── Claiming tool click ───────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (!isClaimingTool(item)) return;
        if (!player.hasPermission("ultimateclaims.claim")) {
            MessageUtils.send(player, msg("no-permission"));
            return;
        }

        Action action = event.getAction();
        boolean isLeft = action == Action.LEFT_CLICK_BLOCK || action == Action.LEFT_CLICK_AIR;
        boolean isRight = action == Action.RIGHT_CLICK_BLOCK || action == Action.RIGHT_CLICK_AIR;
        if (!isLeft && !isRight) return;

        // A valid tool in hand is enough to reactivate selection mode. This fixes
        // the previous slot-switch bug where the mode was permanently lost.
        plugin.getPlayerDataManager().enterClaimingMode(player.getUniqueId());

        event.setCancelled(true);

        Block target = event.getClickedBlock();
        if (target == null) {
            target = player.getTargetBlockExact(10);
        }
        if (target == null) return;

        String worldName = player.getWorld().getName();
        if (plugin.getConfig().getStringList("disabled-worlds").contains(worldName)) {
            MessageUtils.send(player, msg("disabled-world"));
            return;
        }

        ClaimSelection selection = plugin.getPlayerDataManager().getSelection(player.getUniqueId());

        if (isLeft) {
            selection.setPos1(target.getLocation());
            showClickFeedback(player, target, true);
            MessageUtils.send(player, msg("pos1-set",
                    "x", String.valueOf(target.getX()),
                    "z", String.valueOf(target.getZ())));
            stopSelectionParticles(player.getUniqueId());
            return;
        }

        if (!selection.hasPos1()) {
            selection.setPos1(target.getLocation());
            showClickFeedback(player, target, true);
            MessageUtils.send(player, msg("pos1-set",
                    "x", String.valueOf(target.getX()),
                    "z", String.valueOf(target.getZ())));
            stopSelectionParticles(player.getUniqueId());
            return;
        }

        if (!target.getWorld().getName().equals(selection.getWorld())) {
            MessageUtils.send(player, msg("selection-different-world"));
            return;
        }

        selection.setPos2(target.getLocation());
        showClickFeedback(player, target, false);
        MessageUtils.send(player, msg("pos2-set",
                "x", String.valueOf(target.getX()),
                "z", String.valueOf(target.getZ())));

        if (selection.isComplete()) {
            MessageUtils.send(player, msg("selection-complete",
                    "width", String.valueOf(selection.getWidth()),
                    "length", String.valueOf(selection.getLength()),
                    "area", String.valueOf(selection.getArea())));
            showSelectionParticles(player, selection);
        }
    }

    // ── Tool switch / quit cleanup ────────────────────────────────────────────

    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());

        if (isClaimingTool(newItem)) {
            plugin.getPlayerDataManager().enterClaimingMode(uuid);
            ClaimSelection selection = plugin.getPlayerDataManager().getSelection(uuid);
            if (selection.isComplete()) {
                showSelectionParticles(player, selection);
            }
        } else {
            // Do not clear the selection. Only stop rendering while the player is
            // not holding the tool. Switching back re-enters mode automatically.
            plugin.getPlayerDataManager().leaveClaimingMode(uuid);
            stopSelectionParticles(uuid);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        plugin.getPlayerDataManager().leaveClaimingMode(uuid);
        plugin.getPlayerDataManager().clearSelection(uuid);
        stopSelectionParticles(uuid);
        stopClaimBorder(uuid);
    }

    public void shutdown() {
        selectionParticleTasks.values().forEach(BukkitTask::cancel);
        claimBorderTasks.values().forEach(BukkitTask::cancel);
        selectionParticleTasks.clear();
        claimBorderTasks.clear();
    }

    // ── Particle helpers ──────────────────────────────────────────────────────

    /** Starts a repeating particle preview for the player's current selection. */
    public void showSelectionParticles(Player player, ClaimSelection selection) {
        if (!canShowParticles(player) || !selection.isComplete()) return;

        UUID uuid = player.getUniqueId();
        stopSelectionParticles(uuid);

        long refreshTicks = Math.max(1L, plugin.getConfig().getLong("particles.refresh-ticks", 5L));
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || !isClaimingTool(player.getInventory().getItemInMainHand())) {
                stopSelectionParticles(uuid);
                return;
            }
            ClaimSelection current = plugin.getPlayerDataManager().getSelection(uuid);
            if (!current.isComplete()) {
                stopSelectionParticles(uuid);
                return;
            }
            renderSelectionParticles(player, current);
        }, 0L, refreshTicks);

        selectionParticleTasks.put(uuid, task);
    }

    /** Shows a claim border for a short, repeating duration. */
    public void showClaimBorder(Player player, Claim claim) {
        if (!canShowParticles(player) || claim == null) return;

        UUID uuid = player.getUniqueId();
        stopClaimBorder(uuid);

        long refreshTicks = Math.max(1L, plugin.getConfig().getLong("particles.refresh-ticks", 5L));
        long durationTicks = Math.max(refreshTicks,
                plugin.getConfig().getLong("particles.border-duration-ticks",
                        plugin.getConfig().getLong("action-bar.duration", 60L)));
        long maxRuns = Math.max(1L, durationTicks / refreshTicks);

        final long[] runs = {0L};
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || ++runs[0] > maxRuns) {
                stopClaimBorder(uuid);
                return;
            }
            renderClaimBorder(player, claim);
        }, 0L, refreshTicks);

        claimBorderTasks.put(uuid, task);
    }

    public void stopSelectionParticles(UUID uuid) {
        BukkitTask task = selectionParticleTasks.remove(uuid);
        if (task != null) task.cancel();
    }

    public void stopClaimBorder(UUID uuid) {
        BukkitTask task = claimBorderTasks.remove(uuid);
        if (task != null) task.cancel();
    }

    private boolean canShowParticles(Player player) {
        return player != null && player.isOnline() && plugin.getConfig().getBoolean("particles.enabled", true);
    }

    private void renderSelectionParticles(Player player, ClaimSelection selection) {
        World world = Bukkit.getWorld(selection.getWorld());
        if (world == null || !world.equals(player.getWorld())) return;

        int minX = Math.min(selection.getPos1X(), selection.getPos2X());
        int maxX = Math.max(selection.getPos1X(), selection.getPos2X());
        int minZ = Math.min(selection.getPos1Z(), selection.getPos2Z());
        int maxZ = Math.max(selection.getPos1Z(), selection.getPos2Z());
        int y = player.getLocation().getBlockY();

        spawnBorderParticles(player, minX, maxX, minZ, maxZ, y);
    }

    private void renderClaimBorder(Player player, Claim claim) {
        World world = Bukkit.getWorld(claim.getWorld());
        if (world == null || !world.equals(player.getWorld())) return;

        int y = player.getLocation().getBlockY();
        spawnBorderParticles(player, claim.getMinX(), claim.getMaxX(), claim.getMinZ(), claim.getMaxZ(), y);
    }

    private void spawnBorderParticles(Player player, int minX, int maxX, int minZ, int maxZ, int baseY) {
        ParticleSettings settings = ParticleSettings.fromConfig(plugin);
        int yRange = Math.max(0, Math.min(Y_RANGE_HARD_CAP,
                plugin.getConfig().getInt("particles.y-range", 3)));
        int heightStep = Math.max(1, plugin.getConfig().getInt("particles.height-step", 2));
        int maxParticles = Math.max(1, Math.min(PARTICLE_HARD_CAP,
                plugin.getConfig().getInt("particles.max-particles-per-render", PARTICLE_HARD_CAP)));
        double viewRadius = Math.max(8.0D, plugin.getConfig().getDouble("particles.view-radius-blocks", 64.0D));

        Location eye = player.getLocation();
        double playerX = eye.getX();
        double playerZ = eye.getZ();

        int spawned = 0;
        for (int yOff = -yRange; yOff <= yRange; yOff += heightStep) {
            double py = baseY + yOff + 0.5;
            spawned += spawnEdge(player, minX, maxX + 1, minZ, py, settings, true, maxParticles - spawned, playerX, playerZ, viewRadius);
            if (spawned >= maxParticles) return;
            spawned += spawnEdge(player, minX, maxX + 1, maxZ + 1, py, settings, true, maxParticles - spawned, playerX, playerZ, viewRadius);
            if (spawned >= maxParticles) return;
            spawned += spawnEdge(player, minZ, maxZ + 1, minX, py, settings, false, maxParticles - spawned, playerX, playerZ, viewRadius);
            if (spawned >= maxParticles) return;
            spawned += spawnEdge(player, minZ, maxZ + 1, maxX + 1, py, settings, false, maxParticles - spawned, playerX, playerZ, viewRadius);
            if (spawned >= maxParticles) return;
        }
    }

    private int spawnEdge(Player player, int start, int end, int fixed, double py,
                          ParticleSettings settings, boolean alongX, int remaining,
                          double playerX, double playerZ, double viewRadius) {
        if (remaining <= 0) return 0;

        double fixedDistance = Math.abs((alongX ? fixed : fixed) - (alongX ? playerZ : playerX));
        if (fixedDistance > viewRadius) return 0;

        double center = alongX ? playerX : playerZ;
        double minVisible = Math.max(start, center - viewRadius);
        double maxVisible = Math.min(end, center + viewRadius);
        if (minVisible > maxVisible) return 0;

        int spawned = 0;
        double first = Math.ceil(minVisible / settings.spacing()) * settings.spacing();
        for (double variable = first; variable <= maxVisible; variable += settings.spacing()) {
            if (spawned >= remaining) break;
            double x = alongX ? variable : fixed;
            double z = alongX ? fixed : variable;
            double dx = x - playerX;
            double dz = z - playerZ;
            if ((dx * dx + dz * dz) <= viewRadius * viewRadius) {
                settings.spawn(player, x, py, z);
                spawned++;
            }
        }
        return spawned;
    }

    private void showClickFeedback(Player player, Block block, boolean firstPosition) {
        if (!plugin.getConfig().getBoolean("particles.click-feedback", true)) return;
        if (!canShowParticles(player) || block == null) return;

        ParticleSettings settings = ParticleSettings.fromConfig(plugin);
        int count = Math.max(4, Math.min(CLICK_PARTICLE_HARD_CAP,
                plugin.getConfig().getInt("particles.click-feedback-particles", 28)));
        double cx = block.getX() + 0.5D;
        double cy = block.getY() + 1.05D;
        double cz = block.getZ() + 0.5D;

        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2D * i) / count;
            double radius = 0.55D;
            settings.spawn(player, cx + Math.cos(angle) * radius, cy, cz + Math.sin(angle) * radius);
        }
        settings.spawn(player, cx, cy + 0.35D, cz);
        player.playSound(player.getLocation(),
                firstPosition ? Sound.BLOCK_NOTE_BLOCK_PLING : Sound.BLOCK_NOTE_BLOCK_BELL,
                0.45F, firstPosition ? 1.45F : 1.8F);
    }

    private record ParticleSettings(Particle particle, Particle.DustOptions dust, double spacing) {
        static ParticleSettings fromConfig(UltimateClaims plugin) {
            String typeName = plugin.getConfig().getString("particles.type", "DUST");
            String normalizedType = typeName == null ? "DUST" : typeName.toUpperCase().trim();
            if (normalizedType.equals("REDSTONE")) normalizedType = "DUST";
            Particle particle;
            try {
                particle = Particle.valueOf(normalizedType);
            } catch (IllegalArgumentException ex) {
                particle = Particle.DUST;
            }

            Particle.DustOptions dust = null;
            if (particle == Particle.DUST) {
                int r = clampColor(plugin.getConfig().getInt("particles.color.r", 0));
                int g = clampColor(plugin.getConfig().getInt("particles.color.g", 100));
                int b = clampColor(plugin.getConfig().getInt("particles.color.b", 255));
                float size = Math.max(0.01F, (float) plugin.getConfig().getDouble("particles.size", 1.2));
                dust = new Particle.DustOptions(Color.fromRGB(r, g, b), size);
            }

            double density = Math.max(0.05D, plugin.getConfig().getDouble("particles.density", 0.5D));
            double spacing = Math.max(0.25D, 1.0D / density);
            return new ParticleSettings(particle, dust, spacing);
        }

        private static int clampColor(int value) {
            return Math.max(0, Math.min(255, value));
        }

        void spawn(Player player, double x, double y, double z) {
            if (particle == Particle.DUST) {
                player.spawnParticle(Particle.DUST, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D, dust);
            } else {
                player.spawnParticle(particle, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    // ── Tool detection ────────────────────────────────────────────────────────

    public boolean isClaimingTool(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;

        Material toolMat = getConfiguredToolMaterial();
        if (item.getType() != toolMat) return false;
        if (!item.hasItemMeta()) return false;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;

        Byte marker = meta.getPersistentDataContainer()
                .get(plugin.getClaimingToolKey(), PersistentDataType.BYTE);
        if (marker != null && marker == (byte) 1) return true;

        // Name-only matching is forgeable, so it is disabled unless an administrator
        // explicitly enables the temporary legacy migration switch.
        if (!plugin.getConfig().getBoolean("tool.allow-legacy-name-fallback", false)) return false;
        if (!meta.hasDisplayName()) return false;
        String cfgName = plugin.getConfig().getString("tool.name", "&6&lClaiming Tool");
        return MessageUtils.strip(meta.getDisplayName())
                .equals(MessageUtils.strip(MessageUtils.color(cfgName)));
    }

    public void markAsClaimingTool(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.getPersistentDataContainer().set(plugin.getClaimingToolKey(), PersistentDataType.BYTE, (byte) 1);
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
    }

    public Material getConfiguredToolMaterial() {
        String cfgMaterial = plugin.getConfig().getString("tool.material", "GOLDEN_SHOVEL");
        try {
            Material material = Material.valueOf(cfgMaterial == null ? "GOLDEN_SHOVEL" : cfgMaterial.toUpperCase());
            return material == Material.AIR ? Material.GOLDEN_SHOVEL : material;
        } catch (IllegalArgumentException e) {
            return Material.GOLDEN_SHOVEL;
        }
    }

    // ── Message helper ────────────────────────────────────────────────────────

    private String msg(String key, String... replacements) {
        String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");
        String raw = plugin.getMessages().getString(key, "");
        return MessageUtils.format(raw.replace("{prefix}", prefix), replacements);
    }
}
