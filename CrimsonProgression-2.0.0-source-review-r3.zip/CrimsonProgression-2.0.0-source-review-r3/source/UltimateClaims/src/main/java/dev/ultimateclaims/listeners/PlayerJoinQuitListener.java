package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.PlayerData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Handles player join and quit events for data initialisation and cleanup.
 */
public class PlayerJoinQuitListener implements Listener {

    private final UltimateClaims plugin;

    public PlayerJoinQuitListener(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Bukkit Player/Inventory access must remain on the server thread.
        PlayerData data = plugin.getPlayerDataManager().getOrCreate(event.getPlayer());
        plugin.getPlayerDataManager().updatePlayerName(event.getPlayer());
        plugin.getDataManager().savePlayer(data);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(event.getPlayer().getUniqueId());
        if (data != null) {
            plugin.getDataManager().savePlayer(data);
        }

        plugin.getPlayerDataManager().leaveClaimingMode(event.getPlayer().getUniqueId());
        plugin.getPlayerDataManager().clearSelection(event.getPlayer().getUniqueId());
        plugin.getPlayerDataManager().setCurrentClaim(event.getPlayer().getUniqueId(), null);
        plugin.getFlagsGUI().closeGUI(event.getPlayer().getUniqueId());
        if (plugin.getClaimToolListener() != null) {
            plugin.getClaimToolListener().stopSelectionParticles(event.getPlayer().getUniqueId());
            plugin.getClaimToolListener().stopClaimBorder(event.getPlayer().getUniqueId());
        }
    }
}
