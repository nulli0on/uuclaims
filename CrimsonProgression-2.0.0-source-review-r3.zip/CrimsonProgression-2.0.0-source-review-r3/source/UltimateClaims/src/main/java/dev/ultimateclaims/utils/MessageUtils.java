package dev.ultimateclaims.utils;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Legacy-text formatting kept dependency-free for Paper. */
public final class MessageUtils {
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private MessageUtils() {}

    public static String color(String text) {
        if (text == null) return "";
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuffer output = new StringBuffer();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder legacy = new StringBuilder("§x");
            for (char character : hex.toCharArray()) legacy.append('§').append(character);
            matcher.appendReplacement(output, Matcher.quoteReplacement(legacy.toString()));
        }
        matcher.appendTail(output);
        return ChatColor.translateAlternateColorCodes('&', output.toString());
    }

    public static List<String> colorList(List<String> lines) {
        return lines.stream().map(MessageUtils::color).collect(Collectors.toList());
    }

    public static String replace(String template, String... replacements) {
        if (template == null) return "";
        String result = template;
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            result = result.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        return result;
    }

    public static String format(String template, String... replacements) {
        return color(replace(template, replacements));
    }

    public static void send(CommandSender sender, String message) {
        if (sender == null || message == null || message.isEmpty()) return;
        sender.sendMessage(color(message));
    }

    public static void sendActionBar(Player player, String message) {
        if (player == null || !player.isOnline()) return;
        player.sendActionBar(color(message));
    }

    public static void sendTitle(Player player, String title, String subtitle,
                                 int fadeIn, int stay, int fadeOut) {
        if (player == null || !player.isOnline()) return;
        player.sendTitle(color(title), color(subtitle), fadeIn, stay, fadeOut);
    }

    public static String strip(String text) {
        return ChatColor.stripColor(color(text));
    }
}
