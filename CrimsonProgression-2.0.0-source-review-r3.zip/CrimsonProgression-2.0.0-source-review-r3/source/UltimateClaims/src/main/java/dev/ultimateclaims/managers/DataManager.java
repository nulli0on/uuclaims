package dev.ultimateclaims.managers;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.ClaimFlag;
import dev.ultimateclaims.data.PlayerData;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Level;

/**
 * Single-writer SQLite persistence. Legacy YAML is imported once, backed up,
 * and never deleted automatically.
 */
public final class DataManager implements AutoCloseable {
    private static final int SCHEMA_VERSION = 1;

    private final UltimateClaims plugin;
    private final Path databaseFile;
    private final Path claimsDir;
    private final Path playersDir;
    private final ExecutorService executor;
    private volatile Connection connection;
    private volatile boolean closing;

    public DataManager(UltimateClaims plugin) {
        this.plugin = plugin;
        String configured = plugin.getStorageConfig().getString("database.file", "data/claims.db");
        Path pluginRoot = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        this.databaseFile = resolveInside(pluginRoot, configured, "data/claims.db");
        this.claimsDir = pluginRoot.resolve("data/claims").normalize();
        this.playersDir = pluginRoot.resolve("data/players").normalize();
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "UltimateClaims-Storage");
            thread.setDaemon(true);
            thread.setUncaughtExceptionHandler((ignored, error) ->
                    plugin.getLogger().log(Level.SEVERE, "Uncaught storage worker error", error));
            return thread;
        });
    }

    /** Startup-only blocking load before listeners and commands are exposed. */
    public void loadAll() {
        try {
            submit(connection -> {
                initializeSchema(connection);
                migrateLegacyYaml(connection);
                loadClaims(connection);
                loadPlayers(connection);
                return null;
            }).join();
            reconcileUsedClaimBlocks();
        } catch (CompletionException error) {
            throw new IllegalStateException("UltimateClaims storage initialization failed", error.getCause());
        }
    }

    public CompletableFuture<Void> createClaimAndPlayer(Claim claim, PlayerData player) {
        ClaimSnapshot claimSnapshot = snapshot(claim);
        PlayerSnapshot playerSnapshot = snapshot(player);
        return transaction(connection -> {
            upsertClaim(connection, claimSnapshot);
            upsertPlayer(connection, playerSnapshot);
            return null;
        });
    }

    public CompletableFuture<Void> deleteClaimAndPlayer(Claim claim, PlayerData player) {
        PlayerSnapshot playerSnapshot = snapshot(player);
        return transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM claims WHERE id=?")) {
                statement.setString(1, claim.getId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Claim did not exist in SQLite: " + claim.getId());
                }
            }
            upsertPlayer(connection, playerSnapshot);
            return null;
        });
    }

    public CompletableFuture<Void> deleteClaimsAndPlayer(Collection<Claim> claims, PlayerData player) {
        List<UUID> ids = claims.stream().map(Claim::getId).toList();
        PlayerSnapshot playerSnapshot = snapshot(player);
        return transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM claims WHERE id=?")) {
                for (UUID id : ids) {
                    statement.setString(1, id.toString());
                    statement.addBatch();
                }
                statement.executeBatch();
            }
            upsertPlayer(connection, playerSnapshot);
            return null;
        });
    }

    public CompletableFuture<Void> saveClaimAsync(Claim claim) {
        ClaimSnapshot snapshot = snapshot(claim);
        return submit(connection -> { upsertClaim(connection, snapshot); return null; });
    }

    public CompletableFuture<Void> savePlayerAsync(PlayerData player) {
        PlayerSnapshot snapshot = snapshot(player);
        return submit(connection -> { upsertPlayer(connection, snapshot); return null; });
    }

    public void saveClaim(Claim claim) {
        saveClaimAsync(claim).exceptionally(error -> { log("claim " + claim.getId(), error); return null; });
    }

    public void savePlayer(PlayerData data) {
        savePlayerAsync(data).exceptionally(error -> { log("player " + data.getUuid(), error); return null; });
    }

    public CompletableFuture<Void> saveAllAsync() {
        List<ClaimSnapshot> claims = plugin.getClaimManager().getAllClaims().stream()
                .map(this::snapshot).toList();
        List<PlayerSnapshot> players = plugin.getPlayerDataManager().getAllPlayerData().stream()
                .map(DataManager::snapshot).toList();
        return transaction(connection -> {
            for (ClaimSnapshot snapshot : claims) upsertClaim(connection, snapshot);
            for (PlayerSnapshot snapshot : players) upsertPlayer(connection, snapshot);
            return null;
        });
    }

    public void saveAll() {
        saveAllAsync().exceptionally(error -> { log("full snapshot", error); return null; });
    }

    private void initializeSchema(Connection connection) throws Exception {
        Path parent = databaseFile.getParent();
        if (parent != null) Files.createDirectories(parent);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys=ON");
            statement.execute("PRAGMA journal_mode=WAL");
            String synchronous = plugin.getStorageConfig().getString("database.synchronous", "FULL")
                    .trim().toUpperCase(Locale.ROOT);
            if (!Set.of("OFF", "NORMAL", "FULL", "EXTRA").contains(synchronous)) {
                throw new IllegalArgumentException("Invalid storage.yml database.synchronous: " + synchronous);
            }
            statement.execute("PRAGMA synchronous=" + synchronous);
            statement.execute("PRAGMA busy_timeout=" + Math.max(1000,
                    plugin.getStorageConfig().getInt("database.busy-timeout-millis", 10000)));
            statement.execute("CREATE TABLE IF NOT EXISTS schema_version(version INTEGER PRIMARY KEY,applied_at INTEGER NOT NULL)");
            statement.execute("CREATE TABLE IF NOT EXISTS claims("
                    + "id TEXT PRIMARY KEY,owner_uuid TEXT NOT NULL,world TEXT NOT NULL,"
                    + "min_x INTEGER NOT NULL,max_x INTEGER NOT NULL,min_z INTEGER NOT NULL,max_z INTEGER NOT NULL,"
                    + "payload TEXT NOT NULL,updated_at INTEGER NOT NULL)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_claims_owner ON claims(owner_uuid)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_claims_world_bounds ON claims(world,min_x,max_x,min_z,max_z)");
            statement.execute("CREATE TABLE IF NOT EXISTS players("
                    + "uuid TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at INTEGER NOT NULL)");
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT OR IGNORE INTO schema_version(version,applied_at) VALUES(?,?)")) {
            statement.setInt(1, SCHEMA_VERSION);
            statement.setLong(2, System.currentTimeMillis());
            statement.executeUpdate();
        }
    }

    private void migrateLegacyYaml(Connection connection) throws Exception {
        long existing;
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT (SELECT COUNT(*) FROM claims)+(SELECT COUNT(*) FROM players)")) {
            existing = rows.next() ? rows.getLong(1) : 0;
        }
        List<Path> claimFiles = yamlFiles(claimsDir);
        List<Path> playerFiles = yamlFiles(playersDir);
        if (existing > 0 || (claimFiles.isEmpty() && playerFiles.isEmpty())) return;

        if (plugin.getStorageConfig().getBoolean("migration.backup-legacy-yaml", true)) {
            Path backup = plugin.getDataFolder().toPath().resolve("data/backups/legacy-yaml-" + Instant.now().toEpochMilli());
            copyDirectoryIfExists(claimsDir, backup.resolve("claims"));
            copyDirectoryIfExists(playersDir, backup.resolve("players"));
            plugin.getLogger().warning("Backed up legacy UltimateClaims YAML to " + backup);
        }

        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try {
            for (Path file : claimFiles) {
                Claim claim = parseClaim(YamlConfiguration.loadConfiguration(file.toFile()), file.getFileName().toString());
                if (claim == null) throw new IOException("Invalid legacy claim: " + file);
                upsertClaim(connection, snapshot(claim));
            }
            for (Path file : playerFiles) {
                PlayerData player = parsePlayer(YamlConfiguration.loadConfiguration(file.toFile()));
                if (player == null) throw new IOException("Invalid legacy player: " + file);
                upsertPlayer(connection, snapshot(player));
            }
            connection.commit();
            plugin.getLogger().warning("Imported " + claimFiles.size() + " legacy claims and "
                    + playerFiles.size() + " player records into SQLite. Legacy files were retained.");
        } catch (Exception error) {
            connection.rollback();
            throw error;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void loadClaims(Connection connection) throws Exception {
        int loaded = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT payload FROM claims ORDER BY updated_at");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                Claim claim = parseClaim(yaml(rows.getString(1)), "SQLite");
                if (claim == null) throw new SQLException("Invalid claim payload in SQLite");
                plugin.getClaimManager().addClaimDirectly(claim);
                loaded++;
            }
        }
        plugin.getLogger().info("Loaded " + loaded + " claim(s) from SQLite.");
    }

    private void loadPlayers(Connection connection) throws Exception {
        int loaded = 0;
        try (PreparedStatement statement = connection.prepareStatement("SELECT payload FROM players ORDER BY updated_at");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                PlayerData player = parsePlayer(yaml(rows.getString(1)));
                if (player == null) throw new SQLException("Invalid player payload in SQLite");
                plugin.getPlayerDataManager().addPlayerDataDirectly(player);
                loaded++;
            }
        }
        plugin.getLogger().info("Loaded " + loaded + " player record(s) from SQLite.");
    }

    private void reconcileUsedClaimBlocks() {
        Map<UUID, Integer> used = new HashMap<>();
        Map<UUID, String> names = new HashMap<>();
        for (Claim claim : plugin.getClaimManager().getAllClaims()) {
            used.merge(claim.getOwner(), claim.getArea(), DataManager::saturatedAdd);
            names.putIfAbsent(claim.getOwner(), claim.getOwnerName());
        }
        for (PlayerData player : plugin.getPlayerDataManager().getAllPlayerData()) {
            int calculated = used.getOrDefault(player.getUuid(), 0);
            if (player.getUsedClaimBlocks() != calculated) {
                plugin.getLogger().warning("Reconciled used claim blocks for " + player.getUuid()
                        + " from " + player.getUsedClaimBlocks() + " to " + calculated);
                player.setUsedClaimBlocks(calculated);
                savePlayer(player);
            }
        }
        for (Map.Entry<UUID, Integer> entry : used.entrySet()) {
            if (plugin.getPlayerDataManager().getPlayerData(entry.getKey()) != null) continue;
            int defaultBlocks = Math.max(plugin.getConfig().getInt("default-claim-blocks", 100), entry.getValue());
            PlayerData player = new PlayerData(entry.getKey(), names.getOrDefault(entry.getKey(), "Unknown"), defaultBlocks);
            player.setUsedClaimBlocks(entry.getValue());
            plugin.getPlayerDataManager().addPlayerDataDirectly(player);
            savePlayer(player);
        }
    }

    private static int saturatedAdd(int left, int right) {
        long result = (long) left + right;
        return result > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) result;
    }

    private static void upsertClaim(Connection connection, ClaimSnapshot claim) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO claims(id,owner_uuid,world,min_x,max_x,min_z,max_z,payload,updated_at) VALUES(?,?,?,?,?,?,?,?,?) "
                        + "ON CONFLICT(id) DO UPDATE SET owner_uuid=excluded.owner_uuid,world=excluded.world,"
                        + "min_x=excluded.min_x,max_x=excluded.max_x,min_z=excluded.min_z,max_z=excluded.max_z,"
                        + "payload=excluded.payload,updated_at=excluded.updated_at")) {
            statement.setString(1, claim.id().toString());
            statement.setString(2, claim.owner().toString());
            statement.setString(3, claim.world());
            statement.setInt(4, claim.minX());
            statement.setInt(5, claim.maxX());
            statement.setInt(6, claim.minZ());
            statement.setInt(7, claim.maxZ());
            statement.setString(8, claim.payload());
            statement.setLong(9, System.currentTimeMillis());
            statement.executeUpdate();
        }
    }

    private static void upsertPlayer(Connection connection, PlayerSnapshot player) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO players(uuid,payload,updated_at) VALUES(?,?,?) "
                        + "ON CONFLICT(uuid) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at")) {
            statement.setString(1, player.id().toString());
            statement.setString(2, player.payload());
            statement.setLong(3, System.currentTimeMillis());
            statement.executeUpdate();
        }
    }

    private ClaimSnapshot snapshot(Claim claim) {
        return new ClaimSnapshot(
                claim.getId(), claim.getOwner(), claim.getWorld(),
                claim.getMinX(), claim.getMaxX(), claim.getMinZ(), claim.getMaxZ(),
                serializeClaim(claim));
    }

    private static PlayerSnapshot snapshot(PlayerData player) {
        return new PlayerSnapshot(player.getUuid(), serializePlayer(player));
    }

    private String serializeClaim(Claim claim) {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("id", claim.getId().toString());
        cfg.set("owner", claim.getOwner().toString());
        cfg.set("ownerName", claim.getOwnerName());
        cfg.set("name", claim.getName());
        cfg.set("description", claim.getDescription());
        cfg.set("world", claim.getWorld());
        cfg.set("x1", claim.getX1()); cfg.set("z1", claim.getZ1());
        cfg.set("x2", claim.getX2()); cfg.set("z2", claim.getZ2());
        cfg.set("wgRegionId", claim.getWgRegionId());
        cfg.set("createdAt", claim.getCreatedAt());
        for (Map.Entry<ClaimFlag, Boolean> entry : claim.getAllFlags().entrySet()) {
            cfg.set("flags." + entry.getKey().getConfigKey(), entry.getValue());
        }
        for (Map.Entry<UUID, String> entry : claim.getTrustedPlayers().entrySet()) {
            cfg.set("trusted." + entry.getKey(), entry.getValue());
        }
        for (Map.Entry<UUID, Set<ClaimFlag>> entry : claim.getAllTrustedPlayerFlags().entrySet()) {
            cfg.set("trustedFlags." + entry.getKey(), entry.getValue().stream().map(ClaimFlag::getConfigKey).toList());
        }
        cfg.set("outlawed", claim.getOutlawedPlayers().stream().map(UUID::toString).toList());
        if (claim.hasSpawnPoint()) {
            cfg.set("spawn.world", claim.getSpawnWorld());
            cfg.set("spawn.x", claim.getSpawnX()); cfg.set("spawn.y", claim.getSpawnY()); cfg.set("spawn.z", claim.getSpawnZ());
            cfg.set("spawn.yaw", (double) claim.getSpawnYaw()); cfg.set("spawn.pitch", (double) claim.getSpawnPitch());
        }
        return cfg.saveToString();
    }

    private static String serializePlayer(PlayerData player) {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("uuid", player.getUuid().toString());
        cfg.set("playerName", player.getPlayerName());
        cfg.set("claimBlocks", player.getClaimBlocks());
        cfg.set("usedClaimBlocks", player.getUsedClaimBlocks());
        return cfg.saveToString();
    }

    private Claim parseClaim(YamlConfiguration cfg, String source) {
        String idRaw = cfg.getString("id");
        String ownerRaw = cfg.getString("owner");
        if (idRaw == null || ownerRaw == null) return null;
        Claim claim = new Claim(UUID.fromString(idRaw), UUID.fromString(ownerRaw),
                cfg.getString("ownerName", "Unknown"), cfg.getString("name", "Unknown"),
                cfg.getString("world", "world"), cfg.getInt("x1"), cfg.getInt("z1"),
                cfg.getInt("x2"), cfg.getInt("z2"), cfg.getLong("createdAt", System.currentTimeMillis()));
        claim.setDescription(cfg.getString("description"));
        claim.setWgRegionId(cfg.getString("wgRegionId"));
        if (cfg.isConfigurationSection("flags")) {
            for (String key : Objects.requireNonNull(cfg.getConfigurationSection("flags")).getKeys(false)) {
                ClaimFlag flag = ClaimFlag.fromName(key);
                if (flag != null) claim.setFlag(flag, cfg.getBoolean("flags." + key));
            }
        }
        if (cfg.isConfigurationSection("trusted")) {
            for (String key : Objects.requireNonNull(cfg.getConfigurationSection("trusted")).getKeys(false)) {
                try { claim.addTrustedPlayer(UUID.fromString(key), cfg.getString("trusted." + key, "Unknown")); }
                catch (IllegalArgumentException error) { plugin.getLogger().warning("Invalid trusted UUID in " + source + ": " + key); }
            }
        }
        if (cfg.isConfigurationSection("trustedFlags")) {
            for (String key : Objects.requireNonNull(cfg.getConfigurationSection("trustedFlags")).getKeys(false)) {
                try {
                    Set<ClaimFlag> flags = new HashSet<>();
                    for (String name : cfg.getStringList("trustedFlags." + key)) {
                        ClaimFlag flag = ClaimFlag.fromName(name);
                        if (flag != null) flags.add(flag);
                    }
                    claim.setTrustedPlayerFlags(UUID.fromString(key), flags);
                } catch (IllegalArgumentException error) {
                    plugin.getLogger().warning("Invalid trusted flag UUID in " + source + ": " + key);
                }
            }
        }
        for (String raw : cfg.getStringList("outlawed")) {
            try { claim.addOutlaw(UUID.fromString(raw)); } catch (IllegalArgumentException ignored) {}
        }
        if (cfg.isConfigurationSection("spawn")) {
            String spawnWorld = cfg.getString("spawn.world", claim.getWorld());
            double spawnX = cfg.getDouble("spawn.x");
            double spawnY = cfg.getDouble("spawn.y");
            double spawnZ = cfg.getDouble("spawn.z");
            float spawnYaw = (float) cfg.getDouble("spawn.yaw");
            float spawnPitch = (float) cfg.getDouble("spawn.pitch");
            boolean valid = spawnWorld != null
                    && spawnWorld.equals(claim.getWorld())
                    && Double.isFinite(spawnX) && Double.isFinite(spawnY) && Double.isFinite(spawnZ)
                    && Float.isFinite(spawnYaw) && Float.isFinite(spawnPitch)
                    && claim.contains(spawnWorld, (int) Math.floor(spawnX), (int) Math.floor(spawnZ));
            if (valid) {
                claim.setSpawnPoint(spawnWorld, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch);
            } else {
                plugin.getLogger().warning("Ignored invalid or out-of-claim spawn point in " + source);
            }
        }
        return claim;
    }

    private PlayerData parsePlayer(YamlConfiguration cfg) {
        String raw = cfg.getString("uuid");
        if (raw == null) return null;
        PlayerData player = new PlayerData(UUID.fromString(raw), cfg.getString("playerName", "Unknown"),
                cfg.getInt("claimBlocks", plugin.getConfig().getInt("default-claim-blocks", 100)));
        player.setUsedClaimBlocks(cfg.getInt("usedClaimBlocks", 0));
        return player;
    }

    private static YamlConfiguration yaml(String payload) throws InvalidConfigurationException {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.loadFromString(payload);
        return cfg;
    }

    private static List<Path> yamlFiles(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) return List.of();
        try (var stream = Files.list(directory)) {
            return stream.filter(path -> path.getFileName().toString().endsWith(".yml")).sorted().toList();
        }
    }

    private static void copyDirectoryIfExists(Path source, Path target) throws IOException {
        if (!Files.isDirectory(source)) return;
        try (var stream = Files.walk(source)) {
            for (Path path : stream.toList()) {
                Path destination = target.resolve(source.relativize(path));
                if (Files.isDirectory(path)) Files.createDirectories(destination);
                else Files.copy(path, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
            }
        }
    }

    private static volatile boolean sqliteDriverLoaded;

    private static void ensureSqliteDriverLoaded() throws SQLException {
        if (sqliteDriverLoaded) return;
        synchronized (DataManager.class) {
            if (sqliteDriverLoaded) return;
            try {
                Class.forName("org.sqlite.JDBC", true, DataManager.class.getClassLoader());
                sqliteDriverLoaded = true;
            } catch (ClassNotFoundException error) {
                throw new SQLException("Bundled SQLite JDBC driver is missing", error);
            }
        }
    }

    private Connection connection() throws SQLException, IOException {
        ensureSqliteDriverLoaded();
        Connection current = connection;
        if (current == null || current.isClosed()) {
            Path parent = databaseFile.getParent();
            if (parent != null) Files.createDirectories(parent);
            current = DriverManager.getConnection("jdbc:sqlite:" + databaseFile);
            connection = current;
        }
        return current;
    }

    private <T> CompletableFuture<T> submit(SqlWork<T> work) {
        if (closing) return CompletableFuture.failedFuture(new IllegalStateException("Storage is closing"));
        return CompletableFuture.supplyAsync(() -> {
            try { return work.run(connection()); }
            catch (Exception error) { throw new CompletionException(error); }
        }, executor);
    }

    private <T> CompletableFuture<T> transaction(SqlWork<T> work) {
        return submit(connection -> {
            boolean autoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                T result = work.run(connection);
                connection.commit();
                return result;
            } catch (Exception error) {
                try { connection.rollback(); } catch (SQLException rollback) { error.addSuppressed(rollback); }
                throw error;
            } finally {
                connection.setAutoCommit(autoCommit);
            }
        });
    }

    private void log(String operation, Throwable error) {
        plugin.getLogger().log(Level.SEVERE, "Failed to persist " + operation, error);
    }

    @Override
    public void close() {
        int timeoutSeconds = Math.max(1, Math.min(120,
                plugin.getStorageConfig().getInt("shutdown.flush-timeout-seconds", 15)));
        try {
            saveAllAsync().get(timeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException error) {
            plugin.getLogger().log(Level.SEVERE,
                    "Final storage flush exceeded " + timeoutSeconds + " seconds", error);
        } catch (Exception error) {
            plugin.getLogger().log(Level.SEVERE, "Final storage flush failed", error);
        }

        closing = true;
        executor.shutdown();
        try {
            if (!executor.awaitTermination(timeoutSeconds, TimeUnit.SECONDS)) {
                plugin.getLogger().severe("Storage worker did not stop cleanly; interrupting remaining work.");
                executor.shutdownNow();
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
        Connection current = connection;
        if (current != null) try { current.close(); } catch (SQLException error) { log("database close", error); }
    }

    private static Path resolveInside(Path root, String configured, String fallback) {
        String value = configured == null || configured.isBlank() ? fallback : configured.trim();
        Path relative = Path.of(value);
        if (relative.isAbsolute()) {
            throw new IllegalArgumentException("Storage path must be relative to the plugin folder: " + value);
        }
        Path resolved = root.resolve(relative).normalize();
        if (!resolved.startsWith(root)) {
            throw new IllegalArgumentException("Storage path escapes the plugin folder: " + value);
        }
        return resolved;
    }

    @FunctionalInterface
    private interface SqlWork<T> { T run(Connection connection) throws Exception; }
    private record ClaimSnapshot(UUID id, UUID owner, String world,
                                 int minX, int maxX, int minZ, int maxZ,
                                 String payload) {}
    private record PlayerSnapshot(UUID id, String payload) {}
}
