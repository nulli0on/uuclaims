package dev.ultimateclaims.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** Utility methods for building ItemStacks. */
public final class ItemUtils {

    private ItemUtils() {}

    public static ItemStack build(Material material, String displayName, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta  meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(MessageUtils.color(displayName));
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(MessageUtils.colorList(lore));
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack build(Material material, String displayName) {
        return build(material, displayName, null);
    }

    /** Returns true if the item stack has the given display name (after stripping colour). */
    public static boolean hasName(ItemStack item, String plainName) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return false;
        return MessageUtils.strip(meta.getDisplayName()).equalsIgnoreCase(plainName);
    }

    public static Material parseMaterial(String name, Material fallback) {
        if (name == null || name.isBlank()) return fallback;
        try {
            Material m = Material.valueOf(name.toUpperCase().trim());
            return (m == Material.AIR) ? fallback : m;
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
