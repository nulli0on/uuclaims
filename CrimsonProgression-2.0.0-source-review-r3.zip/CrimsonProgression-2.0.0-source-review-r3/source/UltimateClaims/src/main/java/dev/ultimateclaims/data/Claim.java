package dev.ultimateclaims.data;

import java.util.*;

/**
 * Represents a player-owned land claim.
 * Claims are 2D (X,Z plane) and cover all Y values in the world.
 */
public class Claim {

    private final UUID   id;
    private UUID         owner;
    private String       ownerName;
    private String       name;
    private String       description;
    private final String world;
    private final int    x1, z1, x2, z2;

    /** Flag state map — true = flag is ON (allowed), false = flag is OFF (denied). */
    private final Map<ClaimFlag, Boolean> flags = new EnumMap<>(ClaimFlag.class);

    /** UUID → player display name for trusted players. */
    private final Map<UUID, String> trustedPlayers = new LinkedHashMap<>();

    /**
     * Per-trusted-player flag overrides.
     * If a flag is present in a player's set, THAT flag is allowed for them
     * regardless of the claim-wide setting.
     */
    private final Map<UUID, Set<ClaimFlag>> trustedPlayerFlags = new HashMap<>();

    /** Players who are outlawed — PvP is always enabled against/for them. */
    private final Set<UUID> outlawedPlayers = new HashSet<>();

    /** The WorldGuard region ID used for boundary tracking. */
    private String wgRegionId;

    /** Custom spawn location (null fields = use claim centre). */
    private Double spawnX, spawnY, spawnZ;
    private Float  spawnYaw, spawnPitch;
    private String spawnWorld;

    private final long createdAt;

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    public Claim(UUID id, UUID owner, String ownerName, String name,
                 String world, int x1, int z1, int x2, int z2) {
        this(id, owner, ownerName, name, world, x1, z1, x2, z2, System.currentTimeMillis());
    }

    public Claim(UUID id, UUID owner, String ownerName, String name,
                 String world, int x1, int z1, int x2, int z2, long createdAt) {
        this.id        = Objects.requireNonNull(id, "id");
        this.owner     = Objects.requireNonNull(owner, "owner");
        this.ownerName = ownerName == null || ownerName.isBlank() ? "Unknown" : ownerName;
        this.name      = name == null || name.isBlank() ? "Unknown" : name;
        this.world     = world == null || world.isBlank() ? "world" : world;
        this.x1        = x1;
        this.z1        = z1;
        this.x2        = x2;
        this.z2        = z2;
        this.createdAt = Math.max(0L, createdAt);

        // Apply default flag values
        for (ClaimFlag flag : ClaimFlag.values()) {
            flags.put(flag, flag.getDefaultValue());
        }
        this.wgRegionId = "uc_" + id.toString().replace("-", "").substring(0, 16);
    }

    // -------------------------------------------------------------------------
    // Geometry helpers
    // -------------------------------------------------------------------------

    public int getMinX() { return Math.min(x1, x2); }
    public int getMaxX() { return Math.max(x1, x2); }
    public int getMinZ() { return Math.min(z1, z2); }
    public int getMaxZ() { return Math.max(z1, z2); }
    public int getWidth()  { return safeToInt(getWidthLong()); }
    public int getLength() { return safeToInt(getLengthLong()); }
    public int getArea()   { return safeToInt(getAreaLong()); }

    public long getWidthLong()  { return (long) getMaxX() - (long) getMinX() + 1L; }
    public long getLengthLong() { return (long) getMaxZ() - (long) getMinZ() + 1L; }
    public long getAreaLong() {
        long width = getWidthLong();
        long length = getLengthLong();
        if (width <= 0L || length <= 0L) return Long.MAX_VALUE;
        if (width > Long.MAX_VALUE / length) return Long.MAX_VALUE;
        return width * length;
    }

    private int safeToInt(long value) {
        return value > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) Math.max(0L, value);
    }

    public boolean contains(String worldName, int x, int z) {
        return world.equals(worldName)
                && x >= getMinX() && x <= getMaxX()
                && z >= getMinZ() && z <= getMaxZ();
    }

    // -------------------------------------------------------------------------
    // Flag management
    // -------------------------------------------------------------------------

    public boolean getFlag(ClaimFlag flag) {
        return flags.getOrDefault(flag, flag.getDefaultValue());
    }

    public void setFlag(ClaimFlag flag, boolean value) {
        flags.put(flag, value);
    }

    public Map<ClaimFlag, Boolean> getAllFlags() {
        return Collections.unmodifiableMap(flags);
    }

    // -------------------------------------------------------------------------
    // Trust management
    // -------------------------------------------------------------------------

    public boolean isTrusted(UUID uuid) {
        return uuid.equals(owner) || trustedPlayers.containsKey(uuid);
    }

    public void addTrustedPlayer(UUID uuid, String playerName) {
        trustedPlayers.put(uuid, playerName);
    }

    public void removeTrustedPlayer(UUID uuid) {
        trustedPlayers.remove(uuid);
        trustedPlayerFlags.remove(uuid);
    }

    public Map<UUID, String> getTrustedPlayers() {
        return Collections.unmodifiableMap(trustedPlayers);
    }

    // ── Per-trusted-player flag overrides ────────────────────────────────────

    /**
     * Returns true if {@code uuid} is trusted AND the specific flag has been
     * explicitly granted to them (overriding the claim-wide flag).
     */
    public boolean isTrustedFlagAllowed(UUID uuid, ClaimFlag flag) {
        if (uuid.equals(owner)) return true;
        Set<ClaimFlag> granted = trustedPlayerFlags.get(uuid);
        if (granted == null) return false;
        return granted.contains(flag);
    }

    public void setTrustedPlayerFlag(UUID uuid, ClaimFlag flag, boolean allowed) {
        trustedPlayerFlags.computeIfAbsent(uuid, k -> new HashSet<>());
        if (allowed) {
            trustedPlayerFlags.get(uuid).add(flag);
        } else {
            trustedPlayerFlags.get(uuid).remove(flag);
        }
    }

    public void setTrustedPlayerFlags(UUID uuid, Set<ClaimFlag> flags) {
        trustedPlayerFlags.put(uuid, new HashSet<>(flags));
    }

    public Map<UUID, Set<ClaimFlag>> getAllTrustedPlayerFlags() {
        return Collections.unmodifiableMap(trustedPlayerFlags);
    }

    // -------------------------------------------------------------------------
    // Outlaw management
    // -------------------------------------------------------------------------

    public boolean isOutlawed(UUID uuid) {
        return outlawedPlayers.contains(uuid);
    }

    public void addOutlaw(UUID uuid) {
        outlawedPlayers.add(uuid);
    }

    public void removeOutlaw(UUID uuid) {
        outlawedPlayers.remove(uuid);
    }

    public Set<UUID> getOutlawedPlayers() {
        return Collections.unmodifiableSet(outlawedPlayers);
    }

    // -------------------------------------------------------------------------
    // Spawn point
    // -------------------------------------------------------------------------

    public boolean hasSpawnPoint() { return spawnX != null; }

    public void setSpawnPoint(String world, double x, double y, double z,
                               float yaw, float pitch) {
        if (world == null || world.isBlank() || !Double.isFinite(x) || !Double.isFinite(y)
                || !Double.isFinite(z) || !Float.isFinite(yaw) || !Float.isFinite(pitch)) {
            clearSpawnPoint();
            return;
        }
        this.spawnWorld = world;
        this.spawnX     = x;
        this.spawnY     = y;
        this.spawnZ     = z;
        this.spawnYaw   = yaw;
        this.spawnPitch = pitch;
    }

    public void clearSpawnPoint() {
        spawnWorld = null;
        spawnX = spawnY = spawnZ = null;
        spawnYaw = spawnPitch = null;
    }

    public String getSpawnWorld() { return spawnWorld; }
    public double getSpawnX()     { return spawnX; }
    public double getSpawnY()     { return spawnY; }
    public double getSpawnZ()     { return spawnZ; }
    public float  getSpawnYaw()   { return spawnYaw; }
    public float  getSpawnPitch() { return spawnPitch; }

    // -------------------------------------------------------------------------
    // Getters / setters
    // -------------------------------------------------------------------------

    public UUID   getId()          { return id; }
    public UUID   getOwner()       { return owner; }
    public void   setOwner(UUID u) { this.owner = Objects.requireNonNull(u, "owner"); }
    public String getOwnerName()       { return ownerName; }
    public void   setOwnerName(String n){ this.ownerName = n == null || n.isBlank() ? "Unknown" : n; }
    public String getName()        { return name; }
    public void   setName(String n){ this.name = n == null || n.isBlank() ? "Unknown" : n; }
    public String getDescription() { return description; }
    public void   setDescription(String d) { this.description = d; }
    public String getWorld()       { return world; }
    public int    getX1()          { return x1; }
    public int    getZ1()          { return z1; }
    public int    getX2()          { return x2; }
    public int    getZ2()          { return z2; }
    public String getWgRegionId()  { return wgRegionId; }
    public void   setWgRegionId(String id) {
        this.wgRegionId = id == null || id.isBlank()
                ? "uc_" + this.id.toString().replace("-", "").substring(0, 16)
                : id;
    }
    public long   getCreatedAt()   { return createdAt; }
}
