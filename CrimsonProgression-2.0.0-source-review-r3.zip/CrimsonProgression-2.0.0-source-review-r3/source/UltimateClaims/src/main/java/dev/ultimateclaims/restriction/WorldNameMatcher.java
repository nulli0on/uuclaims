package dev.ultimateclaims.restriction;

import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public final class WorldNameMatcher {
    private final boolean caseSensitive;
    private final Set<String> exact;
    private final List<Pattern> wildcard;
    private final List<Pattern> regex;

    public WorldNameMatcher(boolean caseSensitive, Collection<String> exact,
                            Collection<String> wildcard, Collection<String> regex) {
        this.caseSensitive = caseSensitive;
        this.exact = new HashSet<>();
        for (String value : exact) this.exact.add(normalize(value));
        this.wildcard = compileWildcard(wildcard);
        this.regex = compileRegex(regex);
    }

    public boolean matches(String value) {
        if (value == null) return false;
        if (exact.contains(normalize(value))) return true;
        for (Pattern pattern : wildcard) if (pattern.matcher(value).matches()) return true;
        for (Pattern pattern : regex) if (pattern.matcher(value).matches()) return true;
        return false;
    }

    private String normalize(String value) {
        return caseSensitive ? value : value.toLowerCase(Locale.ROOT);
    }

    private List<Pattern> compileWildcard(Collection<String> values) {
        List<Pattern> result = new ArrayList<>();
        int flags = caseSensitive ? 0 : Pattern.CASE_INSENSITIVE;
        for (String value : values) {
            StringBuilder builder = new StringBuilder("^");
            for (char character : value.toCharArray()) {
                if (character == '*') builder.append(".*");
                else if (character == '?') builder.append('.');
                else builder.append(Pattern.quote(String.valueOf(character)));
            }
            builder.append('$');
            result.add(Pattern.compile(builder.toString(), flags));
        }
        return List.copyOf(result);
    }

    private List<Pattern> compileRegex(Collection<String> values) {
        List<Pattern> result = new ArrayList<>();
        int flags = caseSensitive ? 0 : Pattern.CASE_INSENSITIVE;
        for (String value : values) {
            try {
                result.add(Pattern.compile(value, flags));
            } catch (PatternSyntaxException exception) {
                throw new IllegalArgumentException("Invalid regular expression: " + value, exception);
            }
        }
        return List.copyOf(result);
    }
}
