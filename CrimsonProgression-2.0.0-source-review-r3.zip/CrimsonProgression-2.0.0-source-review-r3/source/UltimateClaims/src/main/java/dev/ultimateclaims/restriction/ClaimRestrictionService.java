package dev.ultimateclaims.restriction;

import dev.ultimateclaims.UltimateClaims;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.*;
import java.util.logging.Level;

public final class ClaimRestrictionService {
    private final UltimateClaims plugin;
    private volatile YamlConfiguration config;
    private volatile WorldNameMatcher deniedWorlds;
    private volatile List<ManualZone> manualZones = List.of();

    public ClaimRestrictionService(UltimateClaims plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "restrictions.yml");
        this.config = YamlConfiguration.loadConfiguration(file);
        try {
            boolean caseSensitive = config.getBoolean("worlds.case-sensitive", false);
            deniedWorlds = new WorldNameMatcher(caseSensitive,
                    config.getStringList("worlds.denied.exact"),
                    config.getStringList("worlds.denied.wildcard"),
                    config.getStringList("worlds.denied.regex"));
        } catch (IllegalArgumentException exception) {
            plugin.getLogger().log(Level.SEVERE,
                    "Invalid world restriction pattern. World-name restrictions are disabled until fixed.", exception);
            deniedWorlds = new WorldNameMatcher(false, List.of(), List.of(), List.of());
        }

        List<ManualZone> zones = new ArrayList<>();
        ConfigurationSection section = config.getConfigurationSection("manual-zones");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                String path = id + ".";
                String world = section.getString(path + "world");
                if (world == null || world.isBlank()) {
                    plugin.getLogger().warning("Manual restriction zone " + id + " has no world.");
                    continue;
                }
                int minX = Math.min(section.getInt(path + "min-x"), section.getInt(path + "max-x"));
                int maxX = Math.max(section.getInt(path + "min-x"), section.getInt(path + "max-x"));
                int minZ = Math.min(section.getInt(path + "min-z"), section.getInt(path + "max-z"));
                int maxZ = Math.max(section.getInt(path + "min-z"), section.getInt(path + "max-z"));
                zones.add(new ManualZone(id, world, minX, minZ, maxX, maxZ));
            }
        }
        manualZones = List.copyOf(zones);
    }

    public Decision canCreate(Player player, String world, int minX, int minZ, int maxX, int maxZ) {
        if (!config.getBoolean("enabled", true)) return Decision.allow();
        String bypass = config.getString("bypass-permission", "ultimateclaims.restrictions.bypass");
        if (player != null && player.hasPermission(bypass)) return Decision.allow();

        if (deniedWorlds.matches(world)) {
            return Decision.denied("WORLD", world);
        }

        for (ManualZone zone : manualZones) {
            if (zone.world.equalsIgnoreCase(world) && overlaps(minX, minZ, maxX, maxZ,
                    zone.minX, zone.minZ, zone.maxX, zone.maxZ)) {
                return Decision.denied("MANUAL_ZONE", zone.id);
            }
        }

        if (config.getBoolean("worldguard.enabled", true)) {
            var worldGuard = plugin.getWorldGuardIntegration();
            if (!worldGuard.isAvailable()) {
                if (config.getBoolean("worldguard.fail-closed", true)) {
                    return Decision.denied("WORLDGUARD_UNAVAILABLE", world);
                }
            } else {
                var result = worldGuard.checkClaimCreation(world, minX, minZ, maxX, maxZ, config);
                if (!result.allowed()) return Decision.denied(result.reason(), result.detail());
            }
        }

        return Decision.allow();
    }

    private static boolean overlaps(int aMinX, int aMinZ, int aMaxX, int aMaxZ,
                                    int bMinX, int bMinZ, int bMaxX, int bMaxZ) {
        return aMinX <= bMaxX && aMaxX >= bMinX && aMinZ <= bMaxZ && aMaxZ >= bMinZ;
    }

    private record ManualZone(String id, String world, int minX, int minZ, int maxX, int maxZ) {}

    public record Decision(boolean allowed, String reason, String detail) {
        public static Decision allow() { return new Decision(true, "", ""); }
        public static Decision denied(String reason, String detail) {
            return new Decision(false, reason, detail == null ? "" : detail);
        }
    }
}
