package dev.ultimateclaims.listeners;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.UUID;

/**
 * Detects when players enter or leave claims and fires action bar messages
 * and claim border particle effects.
 */
public class ClaimEnterLeaveListener implements Listener {

    private final UltimateClaims plugin;

    public ClaimEnterLeaveListener(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        // Only care if block changes
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()
                && event.getFrom().getWorld() == event.getTo().getWorld()) return;

        handleMovement(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        plugin.getServer().getScheduler().runTask(plugin,
                () -> handleMovement(event.getPlayer()));
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getPlayerDataManager().setCurrentClaim(event.getPlayer().getUniqueId(), null);
    }

    private void handleMovement(Player player) {
        UUID  playerUuid   = player.getUniqueId();
        Claim currentClaim = plugin.getClaimManager().getClaimAt(player.getLocation());
        UUID  currentId    = currentClaim != null ? currentClaim.getId() : null;
        UUID  previousId   = plugin.getPlayerDataManager().getCurrentClaimId(playerUuid);

        if (java.util.Objects.equals(currentId, previousId)) return;

        // Update stored claim
        plugin.getPlayerDataManager().setCurrentClaim(playerUuid, currentId);

        if (currentClaim != null) {
            onEnterClaim(player, currentClaim);
        } else if (previousId != null) {
            Claim previousClaim = plugin.getClaimManager().getClaimById(previousId);
            if (previousClaim != null) onLeaveClaim(player, previousClaim);
        }
    }

    private void onEnterClaim(Player player, Claim claim) {
        // Action bar
        if (plugin.getConfig().getBoolean("action-bar.enabled", true)) {
            String raw = plugin.getMessages().getString("action-bar-enter",
                    "&b⚑ &f{name} &8| &7Owner: &f{owner}{desc_part}");
            String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");

            String descPart = "";
            if (claim.getDescription() != null && !claim.getDescription().isBlank()) {
                String descTemplate = plugin.getMessages().getString("action-bar-desc-separator",
                        " &8| &7{desc}");
                descPart = MessageUtils.format(descTemplate, "desc", claim.getDescription());
            }

            String msg = MessageUtils.format(raw,
                    "name",      claim.getName(),
                    "owner",     claim.getOwnerName(),
                    "desc_part", descPart);
            MessageUtils.sendActionBar(player, msg);
        }

        // Border particles on enter
        if (plugin.getConfig().getBoolean("particles.show-on-enter", true)) {
            plugin.getClaimToolListener().showClaimBorder(player, claim);
        }
    }

    private void onLeaveClaim(Player player, Claim claim) {
        if (plugin.getConfig().getBoolean("action-bar.enabled", true)) {
            String raw = plugin.getMessages().getString("action-bar-leave",
                    "&7Leaving &b{name}&7…");
            String msg = MessageUtils.format(raw, "name", claim.getName());
            MessageUtils.sendActionBar(player, msg);
        }
    }
}
