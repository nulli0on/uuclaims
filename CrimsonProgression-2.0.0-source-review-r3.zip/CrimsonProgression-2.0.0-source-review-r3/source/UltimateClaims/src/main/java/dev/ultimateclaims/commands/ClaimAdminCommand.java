package dev.ultimateclaims.commands;

import dev.ultimateclaims.UltimateClaims;
import dev.ultimateclaims.data.Claim;
import dev.ultimateclaims.data.PlayerData;
import dev.ultimateclaims.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /claimadmin command — administrative utilities for claim management.
 *
 * Subcommands:
 *   delete <owner> <claimName>  — force-delete any claim
 *   info <owner> <claimName>    — view any claim's info
 *   list <player>               — list any player's claims
 *   here                        — info about claim at admin's feet
 *   give <player> <amount>      — give claim blocks
 *   take <player> <amount>      — take claim blocks
 *   set <player> <amount>       — set claim blocks
 *   reload                      — reload all configs
 *   teleport <owner> <name>     — teleport to any claim
 */
public class ClaimAdminCommand implements CommandExecutor, TabCompleter {

    private final UltimateClaims plugin;

    public ClaimAdminCommand(UltimateClaims plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ultimateclaims.admin")) {
            MessageUtils.send(sender, msg("no-permission")); return true;
        }

        if (args.length == 0) {
            sendUsage(sender); return true;
        }

        switch (args[0].toLowerCase()) {
            case "delete"    -> adminDelete(sender, args);
            case "here"      -> adminHere(sender);
            case "list"      -> adminList(sender, args);
            case "give"      -> adminGive(sender, args);
            case "take"      -> adminTake(sender, args);
            case "set"       -> adminSet(sender, args);
            case "reload"    -> adminReload(sender);
            case "teleport", "tp" -> adminTeleport(sender, args);
            default          -> sendUsage(sender);
        }
        return true;
    }

    private void adminDelete(CommandSender sender, String[] args) {
        if (args.length < 3) { MessageUtils.send(sender, "&cUsage: /claimadmin delete <ownerName> <claimName>"); return; }
        Claim claim = plugin.getClaimManager().getClaimByOwnerAndName(args[1], args[2]);
        if (claim == null) {
            MessageUtils.send(sender, "&cNo claim found for owner &e" + args[1] + " &cnamed &e" + args[2]); return;
        }
        plugin.getClaimManager().deleteClaim(claim).whenComplete((area, error) -> {
            if (error != null) {
                plugin.getLogger().log(java.util.logging.Level.WARNING,
                        "Administrative claim deletion failed for " + claim.getId(), error);
                MessageUtils.send(sender, msg("claim-delete-failed"));
                return;
            }
            MessageUtils.send(sender, MessageUtils.format(msg("admin-claim-deleted"),
                    "name", claim.getName(), "owner", claim.getOwnerName()));
        });
    }

    private void adminHere(CommandSender sender) {
        if (!(sender instanceof Player player)) { MessageUtils.send(sender, msg("player-only")); return; }
        Claim claim = plugin.getClaimManager().getClaimAt(player.getLocation());
        if (claim == null) { MessageUtils.send(sender, msg("admin-no-claim-at")); return; }

        MessageUtils.send(sender, MessageUtils.format(msg("claim-info-header"), "name", claim.getName()));
        MessageUtils.send(sender, MessageUtils.format(msg("claim-info-owner"), "owner", claim.getOwnerName()));
        MessageUtils.send(sender, MessageUtils.format(msg("claim-info-world"), "world", claim.getWorld()));
        MessageUtils.send(sender, MessageUtils.format(msg("claim-info-size"),
                "width", String.valueOf(claim.getWidth()),
                "length", String.valueOf(claim.getLength()),
                "area", String.valueOf(claim.getArea())));
        MessageUtils.send(sender, MessageUtils.format(msg("claim-info-corner"),
                "x1", String.valueOf(claim.getMinX()), "z1", String.valueOf(claim.getMinZ()),
                "x2", String.valueOf(claim.getMaxX()), "z2", String.valueOf(claim.getMaxZ())));
        MessageUtils.send(sender, "&7WG Region: &f" + claim.getWgRegionId());
        MessageUtils.send(sender, "&7Claim ID: &f" + claim.getId());
        MessageUtils.send(sender, msg("claim-info-footer"));
    }

    private void adminList(CommandSender sender, String[] args) {
        if (args.length < 2) { MessageUtils.send(sender, "&cUsage: /claimadmin list <player>"); return; }
        OfflinePlayer target = resolveOffline(args[1]);
        if (target == null) { MessageUtils.send(sender, "&cPlayer not found: " + args[1]); return; }

        List<Claim> claims = plugin.getClaimManager().getClaimsByOwner(target.getUniqueId());
        if (claims.isEmpty()) { MessageUtils.send(sender, "&7" + args[1] + " has no claims."); return; }
        MessageUtils.send(sender, "&b" + args[1] + "'s claims (" + claims.size() + "):");
        for (Claim c : claims) {
            MessageUtils.send(sender, " &7- &6" + c.getName() + " &8[" + c.getWidth() + "x" + c.getLength()
                    + "] &7in &f" + c.getWorld() + " &8(" + c.getMinX() + "," + c.getMinZ() + ")");
        }
    }

    private void adminGive(CommandSender sender, String[] args) {
        if (args.length < 3) { MessageUtils.send(sender, "&cUsage: /claimadmin give <player> <amount>"); return; }
        OfflinePlayer target = resolveOffline(args[1]);
        if (target == null) { MessageUtils.send(sender, "&cPlayer not found: " + args[1]); return; }
        int amount;
        try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException e) {
            MessageUtils.send(sender, "&cInvalid number."); return;
        }
        if (amount <= 0) { MessageUtils.send(sender, msg("must-be-positive")); return; }
        PlayerData data = getOrCreateData(target);
        data.addClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);
        MessageUtils.send(sender, MessageUtils.format(msg("blocks-given"),
                "amount", String.valueOf(amount),
                "player", target.getName() != null ? target.getName() : args[1],
                "total", String.valueOf(data.getClaimBlocks())));
    }

    private void adminTake(CommandSender sender, String[] args) {
        if (args.length < 3) { MessageUtils.send(sender, "&cUsage: /claimadmin take <player> <amount>"); return; }
        OfflinePlayer target = resolveOffline(args[1]);
        if (target == null) { MessageUtils.send(sender, "&cPlayer not found: " + args[1]); return; }
        int amount;
        try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException e) {
            MessageUtils.send(sender, "&cInvalid number."); return;
        }
        if (amount <= 0) { MessageUtils.send(sender, msg("must-be-positive")); return; }
        PlayerData data = getOrCreateData(target);
        int removed = data.takeClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);
        MessageUtils.send(sender, MessageUtils.format(msg("blocks-taken"),
                "amount", String.valueOf(removed),
                "player", target.getName() != null ? target.getName() : args[1],
                "total", String.valueOf(data.getClaimBlocks())));
    }

    private void adminSet(CommandSender sender, String[] args) {
        if (args.length < 3) { MessageUtils.send(sender, "&cUsage: /claimadmin set <player> <amount>"); return; }
        OfflinePlayer target = resolveOffline(args[1]);
        if (target == null) { MessageUtils.send(sender, "&cPlayer not found: " + args[1]); return; }
        int amount;
        try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException e) {
            MessageUtils.send(sender, "&cInvalid number."); return;
        }
        if (amount < 0) { MessageUtils.send(sender, msg("must-be-positive")); return; }
        PlayerData data = getOrCreateData(target);
        int applied = data.setClaimBlocks(amount);
        plugin.getDataManager().savePlayer(data);
        MessageUtils.send(sender, MessageUtils.format(msg("blocks-set"),
                "player", target.getName() != null ? target.getName() : args[1],
                "amount", String.valueOf(applied)));
    }

    private void adminReload(CommandSender sender) {
        int synced = plugin.reloadAllConfigs();
        MessageUtils.send(sender, MessageUtils.format(msg("reload-success"), "claims", String.valueOf(synced)));
    }

    private void adminTeleport(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) { MessageUtils.send(sender, msg("player-only")); return; }
        if (args.length < 3) { MessageUtils.send(sender, "&cUsage: /claimadmin tp <ownerName> <claimName>"); return; }

        Claim claim = plugin.getClaimManager().getClaimByOwnerAndName(args[1], args[2]);
        if (claim == null) { MessageUtils.send(sender, "&cClaim not found."); return; }

        org.bukkit.World w = Bukkit.getWorld(claim.getWorld());
        if (w == null) { MessageUtils.send(sender, "&cWorld is not loaded."); return; }

        double cx = (claim.getMinX() + claim.getMaxX()) / 2.0 + 0.5;
        double cz = (claim.getMinZ() + claim.getMaxZ()) / 2.0 + 0.5;
        int safeY = w.getHighestBlockYAt((int) cx, (int) cz) + 1;
        player.teleport(new org.bukkit.Location(w, cx, safeY, cz));
        MessageUtils.send(player, MessageUtils.format(msg("teleport-success"), "name", claim.getName()));
    }

    private void sendUsage(CommandSender sender) {
        MessageUtils.send(sender, "&b&lClaimAdmin commands:");
        MessageUtils.send(sender, " &7/claimadmin delete <owner> <name>");
        MessageUtils.send(sender, " &7/claimadmin here");
        MessageUtils.send(sender, " &7/claimadmin list <player>");
        MessageUtils.send(sender, " &7/claimadmin give <player> <amount>");
        MessageUtils.send(sender, " &7/claimadmin take <player> <amount>");
        MessageUtils.send(sender, " &7/claimadmin set <player> <amount>");
        MessageUtils.send(sender, " &7/claimadmin tp <owner> <name>");
        MessageUtils.send(sender, " &7/claimadmin reload");
    }

    @SuppressWarnings("deprecation")
    private OfflinePlayer resolveOffline(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(name);
        if (op != null && op.hasPlayedBefore()) return op;
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
            if (name.equalsIgnoreCase(p.getName())) return p;
        }
        return null;
    }

    private PlayerData getOrCreateData(OfflinePlayer op) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(op.getUniqueId());
        if (data == null) {
            int def = plugin.getConfig().getInt("default-claim-blocks", 100);
            data = new PlayerData(op.getUniqueId(), op.getName() != null ? op.getName() : "Unknown", def);
            plugin.getPlayerDataManager().addPlayerDataDirectly(data);
        }
        return data;
    }

    private String msg(String key) {
        String prefix = plugin.getMessages().getString("prefix", "&8[&b&lUC&8] &r");
        String raw    = plugin.getMessages().getString(key, "");
        return raw.replace("{prefix}", prefix);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ultimateclaims.admin")) return List.of();
        if (args.length == 1) {
            return filter(Arrays.asList("delete", "here", "list", "give", "take", "set", "tp", "reload"), args[0]);
        }
        if (args.length == 2 && List.of("list", "give", "take", "set").contains(args[0].toLowerCase())) {
            return filter(Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName).collect(Collectors.toList()), args[1]);
        }
        return List.of();
    }

    private List<String> filter(List<String> opts, String prefix) {
        return opts.stream().filter(s -> s.toLowerCase().startsWith(prefix.toLowerCase())).collect(Collectors.toList());
    }
}
