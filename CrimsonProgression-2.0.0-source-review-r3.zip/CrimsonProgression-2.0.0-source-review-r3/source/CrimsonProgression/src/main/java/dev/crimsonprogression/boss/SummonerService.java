package dev.crimsonprogression.boss;

import dev.crimsonprogression.Keys;
import dev.crimsonprogression.core.HmacSigner;
import dev.crimsonprogression.integration.MythicMobsHook;
import net.kyori.adventure.text.Component;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.security.MessageDigest;
import java.util.*;

/** Creates and validates signed boss summoners without repeatedly querying MythicMobs on interaction events. */
public final class SummonerService {
    private static final int SCHEMA = 1;

    private final Keys keys;
    private final HmacSigner signer;
    private final MythicMobsHook mythic;

    private volatile Map<String, BossDefinition> definitions = Map.of();
    private volatile Map<String, ItemStack> legacyPrototypes = Map.of();
    private volatile boolean legacyEnabled;
    private volatile boolean requireExactLegacyMatch = true;
    private volatile boolean allowNameLoreFallback;

    public SummonerService(Keys keys, HmacSigner signer, MythicMobsHook mythic,
                           Map<String, BossDefinition> definitions,
                           boolean legacyEnabled,
                           boolean requireExactLegacyMatch,
                           boolean allowNameLoreFallback) {
        this.keys = Objects.requireNonNull(keys, "keys");
        this.signer = Objects.requireNonNull(signer, "signer");
        this.mythic = Objects.requireNonNull(mythic, "mythic");
        reload(definitions, legacyEnabled, requireExactLegacyMatch, allowNameLoreFallback);
    }

    public synchronized void reload(Map<String, BossDefinition> definitions,
                                    boolean legacyEnabled,
                                    boolean requireExactLegacyMatch,
                                    boolean allowNameLoreFallback) {
        this.definitions = Map.copyOf(Objects.requireNonNull(definitions, "definitions"));
        this.legacyEnabled = legacyEnabled;
        this.requireExactLegacyMatch = requireExactLegacyMatch;
        this.allowNameLoreFallback = allowNameLoreFallback;

        if (!legacyEnabled) {
            legacyPrototypes = Map.of();
            return;
        }

        Map<String, ItemStack> prototypes = new LinkedHashMap<>();
        for (BossDefinition definition : this.definitions.values()) {
            mythic.item(definition.mythicItemId()).ifPresent(item -> {
                ItemStack copy = item.clone();
                copy.setAmount(1);
                prototypes.put(definition.summonerId(), copy);
            });
        }
        legacyPrototypes = Map.copyOf(prototypes);
    }

    public Optional<ItemStack> create(String id) {
        BossDefinition definition = definitions.get(id);
        if (definition == null) return Optional.empty();
        ItemStack item = mythic.item(definition.mythicItemId()).orElse(null);
        if (item == null) return Optional.empty();
        item.setAmount(1);
        UUID nonce = UUID.randomUUID();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return Optional.empty();
        meta.getPersistentDataContainer().set(keys.summonerId(), PersistentDataType.STRING, id);
        meta.getPersistentDataContainer().set(keys.summonerNonce(), PersistentDataType.STRING, nonce.toString());
        meta.getPersistentDataContainer().set(keys.summonerSignature(), PersistentDataType.STRING,
                signer.sign(canonical(id, nonce)));
        item.setItemMeta(meta);
        return Optional.of(item);
    }

    public Validation validate(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return Validation.invalid();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return Validation.invalid();

        String id = meta.getPersistentDataContainer().get(keys.summonerId(), PersistentDataType.STRING);
        String nonceRaw = meta.getPersistentDataContainer().get(keys.summonerNonce(), PersistentDataType.STRING);
        String signature = meta.getPersistentDataContainer().get(keys.summonerSignature(), PersistentDataType.STRING);
        if (id != null || nonceRaw != null || signature != null) {
            if (id == null || nonceRaw == null || signature == null) return Validation.invalid();
            try {
                UUID nonce = UUID.fromString(nonceRaw);
                BossDefinition definition = definitions.get(id);
                if (definition == null || !signer.verify(canonical(id, nonce), signature)) return Validation.invalid();
                return new Validation(true, false, definition,
                        "SIGNED:" + id + ":" + nonce + ":" + signature, nonce);
            } catch (IllegalArgumentException exception) {
                return Validation.invalid();
            }
        }

        if (!legacyEnabled) return Validation.invalid();
        for (Map.Entry<String, ItemStack> entry : legacyPrototypes.entrySet()) {
            BossDefinition definition = definitions.get(entry.getKey());
            if (definition == null) continue;
            ItemStack prototype = entry.getValue();
            boolean matches = requireExactLegacyMatch && sameLegacy(prototype, item);
            if (!matches && allowNameLoreFallback) matches = sameVisibleIdentity(prototype, item);
            if (matches) return new Validation(true, true, definition, "LEGACY:" + fingerprint(item), null);
        }
        return Validation.invalid();
    }

    public boolean sameIdentity(ItemStack item, Validation expected) {
        Validation actual = validate(item);
        return actual.valid() && Objects.equals(actual.identity(), expected.identity());
    }

    public String fingerprint(ItemStack item) {
        ItemStack copy = Objects.requireNonNull(item, "item").clone();
        copy.setAmount(1);
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(copy.serializeAsBytes()));
        } catch (Exception exception) {
            throw new IllegalStateException("SHA-256 unavailable", exception);
        }
    }

    private static boolean sameLegacy(ItemStack prototype, ItemStack item) {
        ItemStack expected = prototype.clone();
        ItemStack actual = item.clone();
        expected.setAmount(1);
        actual.setAmount(1);
        return expected.isSimilar(actual);
    }

    private static boolean sameVisibleIdentity(ItemStack prototype, ItemStack item) {
        if (prototype.getType() != item.getType()) return false;
        ItemMeta expected = prototype.getItemMeta();
        ItemMeta actual = item.getItemMeta();
        if (expected == null || actual == null) return false;
        Component expectedName = expected.displayName();
        Component actualName = actual.displayName();
        List<Component> expectedLore = expected.lore();
        List<Component> actualLore = actual.lore();
        return Objects.equals(expectedName, actualName) && Objects.equals(expectedLore, actualLore);
    }

    private static String canonical(String id, UUID nonce) {
        return id + "\n" + nonce + "\n" + SCHEMA;
    }

    public record Validation(boolean valid, boolean legacy, BossDefinition definition,
                             String identity, UUID nonce) {
        static Validation invalid() {
            return new Validation(false, false, null, null, null);
        }
    }
}
