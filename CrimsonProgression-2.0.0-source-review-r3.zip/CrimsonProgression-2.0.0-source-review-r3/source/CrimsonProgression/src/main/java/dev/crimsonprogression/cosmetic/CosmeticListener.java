package dev.crimsonprogression.cosmetic;

import dev.crimsonprogression.crimson.CrimsonArmorListener;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;

/** Bounded tracking for cosmetic projectile trails and PvP suppression. */
public final class CosmeticListener implements Listener {
    private final CosmeticService cosmetics;

    public CosmeticListener(CosmeticService cosmetics) {
        this.cosmetics = cosmetics;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent event) {
        Projectile projectile = event.getEntity();
        if (projectile.getShooter() instanceof Player player) cosmetics.trackProjectile(projectile, player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHit(ProjectileHitEvent event) {
        cosmetics.untrackProjectile(event.getEntity().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerCombat(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = CrimsonArmorListener.player(event.getDamager());
        if (attacker == null || attacker.getUniqueId().equals(victim.getUniqueId())) return;
        cosmetics.markCombat(victim);
        cosmetics.markCombat(attacker);
    }
}
