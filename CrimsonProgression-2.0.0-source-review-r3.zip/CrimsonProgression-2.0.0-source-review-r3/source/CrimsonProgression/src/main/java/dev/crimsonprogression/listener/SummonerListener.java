package dev.crimsonprogression.listener;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class SummonerListener implements Listener {
    private final CrimsonProgressionPlugin plugin;

    public SummonerListener(CrimsonProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onUse(PlayerInteractEvent event) {
        if (!plugin.ready() || plugin.bossManager() == null) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;
        ItemStack item = event.getItem();
        if (!plugin.bossManager().summoners().validate(item).valid()) return;
        event.setCancelled(true);
        int slot = event.getPlayer().getInventory().getHeldItemSlot();
        plugin.bossManager().summon(event.getPlayer(), slot, item);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!plugin.ready() || plugin.bossManager() == null) return;
        if (!plugin.bossManager().summoners().validate(event.getItemInHand()).valid()) return;
        event.setCancelled(true);
        plugin.messages().send(event.getPlayer(), "summoner-invalid");
    }
}
