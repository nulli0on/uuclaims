package dev.crimsonprogression.core;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.HexFormat;

public final class HmacSigner {
    private final byte[] secret;

    public HmacSigner(byte[] secret) {
        if (secret == null || secret.length < 32) {
            throw new IllegalArgumentException("HMAC secret must contain at least 32 bytes");
        }
        this.secret = secret.clone();
    }

    public String sign(String canonical) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(
                    mac.doFinal(canonical.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("HMAC-SHA-256 is unavailable", exception);
        }
    }

    public boolean verify(String canonical, String signature) {
        if (signature == null) return false;
        byte[] expected = HexFormat.of().parseHex(sign(canonical));
        byte[] actual;
        try {
            actual = HexFormat.of().parseHex(signature);
        } catch (IllegalArgumentException exception) {
            return false;
        }
        return MessageDigest.isEqual(expected, actual);
    }
}
