package dev.crimsonprogression.integration;

import org.bukkit.entity.Player;

/** Public ExcellentCrates API adapter loaded lazily so the soft dependency stays truly optional. */
public final class ExcellentCratesHook {
    private final Class<?> cratesApi;

    public ExcellentCratesHook() {
        try {
            cratesApi = Class.forName("su.nightexpress.excellentcrates.CratesAPI", true,
                    ExcellentCratesHook.class.getClassLoader());
        } catch (ClassNotFoundException exception) {
            throw new IllegalStateException("ExcellentCrates API class is unavailable", exception);
        }
    }

    public boolean giveKey(Player player, String keyId, int amount) {
        if (player == null || keyId == null || keyId.isBlank() || amount <= 0) return false;
        Object manager = ReflectionSupport.invoke(cratesApi, "getKeyManager");
        Object key = ReflectionSupport.invoke(manager, "getKeyById", keyId);
        if (key == null) return false;
        ReflectionSupport.invoke(manager, "giveKey", player, key, amount);
        return true;
    }

    public boolean hasKey(String keyId) {
        if (keyId == null || keyId.isBlank()) return false;
        Object manager = ReflectionSupport.invoke(cratesApi, "getKeyManager");
        try {
            return Boolean.TRUE.equals(ReflectionSupport.invoke(manager, "hasKey", keyId));
        } catch (RuntimeException ignored) {
            return ReflectionSupport.invoke(manager, "getKeyById", keyId) != null;
        }
    }
}
