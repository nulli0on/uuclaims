package dev.crimsonprogression.token;

import dev.crimsonprogression.database.DatabaseService;
import dev.crimsonprogression.integration.ExcellentEconomyHook;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Durable Token payout worker.
 *
 * <p>A SQLite row is claimed before calling ExcellentEconomy. Because SQLite
 * and another plugin cannot participate in one ACID transaction, a crash after
 * ExcellentEconomy accepts a deposit but before SQLite records PAID is
 * fundamentally ambiguous. Such rows are moved to REVIEW_REQUIRED instead of
 * being blindly paid twice. Pending and explicitly retried rows are otherwise
 * processed automatically.</p>
 */
public final class TokenPayoutService {
    private final DatabaseService database;
    private final ExcellentEconomyHook economy;
    private final Logger logger;
    private final int maxAutomaticAttempts;
    private final AtomicBoolean running = new AtomicBoolean();

    public TokenPayoutService(DatabaseService database, ExcellentEconomyHook economy, Logger logger,
                              int maxAutomaticAttempts) {
        this.database = database;
        this.economy = economy;
        this.logger = logger;
        this.maxAutomaticAttempts = Math.max(1, Math.min(100, maxAutomaticAttempts));
    }

    public CompletableFuture<Void> processPending() {
        if (economy == null || !economy.available() || !running.compareAndSet(false, true)) {
            return CompletableFuture.completedFuture(null);
        }
        return quarantineInterrupted()
                .thenCompose(ignored -> loadPending(100))
                .thenCompose(rows -> {
                    CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
                    for (Payout payout : rows) {
                        chain = chain.thenCompose(ignored -> processOne(payout));
                    }
                    return chain;
                })
                .whenComplete((ignored, error) -> running.set(false));
    }

    public CompletableFuture<List<PayoutStatus>> reviewRequired() {
        return database.submit(connection -> {
            List<PayoutStatus> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT payout_uuid,fight_uuid,player_uuid,amount,placement,state,attempts,last_error,created_at "
                            + "FROM token_payouts WHERE state='REVIEW_REQUIRED' ORDER BY created_at")) {
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        rows.add(readStatus(result));
                    }
                }
            }
            return List.copyOf(rows);
        });
    }

    /** Admin-confirmed retry. This may duplicate a payout if the external deposit actually succeeded. */
    public CompletableFuture<Boolean> retry(UUID payoutId) {
        return transition(payoutId, "REVIEW_REQUIRED", "RETRY", "Manually approved retry");
    }

    /** Admin-confirmed completion after checking ExcellentEconomy history/balance. */
    public CompletableFuture<Boolean> markPaid(UUID payoutId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='PAID',last_error='Manually confirmed paid',paid_at=?,updated_at=? "
                            + "WHERE payout_uuid=? AND state='REVIEW_REQUIRED'")) {
                long now = System.currentTimeMillis();
                statement.setLong(1, now);
                statement.setLong(2, now);
                statement.setString(3, payoutId.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    private CompletableFuture<Void> quarantineInterrupted() {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='REVIEW_REQUIRED',"
                            + "last_error=COALESCE(last_error,'Server stopped during external Token deposit; verify before retrying'),"
                            + "updated_at=? WHERE state='PROCESSING'")) {
                statement.setLong(1, System.currentTimeMillis());
                int changed = statement.executeUpdate();
                if (changed > 0) {
                    logger.severe(changed + " Token payout(s) require manual review because shutdown occurred during an external deposit.");
                }
            }
            return null;
        });
    }

    private CompletableFuture<List<Payout>> loadPending(int limit) {
        return database.submit(connection -> {
            List<Payout> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT payout_uuid,player_uuid,amount,attempts FROM token_payouts "
                            + "WHERE state IN ('PENDING','RETRY') ORDER BY created_at LIMIT ?")) {
                statement.setInt(1, Math.max(1, limit));
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        rows.add(new Payout(
                                UUID.fromString(result.getString("payout_uuid")),
                                UUID.fromString(result.getString("player_uuid")),
                                result.getInt("amount"),
                                result.getInt("attempts")));
                    }
                }
            }
            return List.copyOf(rows);
        });
    }

    private CompletableFuture<Void> processOne(Payout payout) {
        return claim(payout.id()).thenCompose(claimed -> {
            if (!claimed) return CompletableFuture.completedFuture(null);
            CompletableFuture<Boolean> deposit;
            try {
                deposit = economy.deposit(payout.playerId(), payout.amount());
            } catch (Throwable error) {
                deposit = CompletableFuture.failedFuture(error);
            }
            return deposit.handle((accepted, error) -> {
                if (error != null) {
                    Throwable cause = error instanceof CompletionException && error.getCause() != null
                            ? error.getCause() : error;
                    return markReview(payout.id(),
                            "Ambiguous ExcellentEconomy failure; verify deposit before retrying: " + safeMessage(cause));
                }
                if (!Boolean.TRUE.equals(accepted)) {
                    if (payout.attempts() + 1 >= maxAutomaticAttempts) {
                        return markReview(payout.id(), "ExcellentEconomy rejected the deposit "
                                + maxAutomaticAttempts + " times");
                    }
                    return markRetry(payout.id(), "ExcellentEconomy rejected the deposit");
                }
                return markPaidAutomatically(payout.id());
            }).thenCompose(future -> future);
        }).exceptionally(error -> {
            logger.log(Level.SEVERE, "Token payout worker failed for " + payout.id(), error);
            return null;
        });
    }

    private CompletableFuture<Boolean> claim(UUID payoutId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='PROCESSING',attempts=attempts+1,processing_started_at=?,updated_at=?,last_error=NULL "
                            + "WHERE payout_uuid=? AND state IN ('PENDING','RETRY')")) {
                long now = System.currentTimeMillis();
                statement.setLong(1, now);
                statement.setLong(2, now);
                statement.setString(3, payoutId.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    private CompletableFuture<Void> markPaidAutomatically(UUID payoutId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='PAID',paid_at=?,updated_at=?,last_error=NULL "
                            + "WHERE payout_uuid=? AND state='PROCESSING'")) {
                long now = System.currentTimeMillis();
                statement.setLong(1, now);
                statement.setLong(2, now);
                statement.setString(3, payoutId.toString());
                if (statement.executeUpdate() != 1) {
                    throw new IllegalStateException("Payout state changed before PAID could be recorded: " + payoutId);
                }
            }
            return null;
        });
    }

    private CompletableFuture<Void> markRetry(UUID payoutId, String error) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='RETRY',last_error=?,updated_at=? "
                            + "WHERE payout_uuid=? AND state='PROCESSING'")) {
                statement.setString(1, error);
                statement.setLong(2, System.currentTimeMillis());
                statement.setString(3, payoutId.toString());
                statement.executeUpdate();
            }
            return null;
        });
    }

    private CompletableFuture<Void> markReview(UUID payoutId, String error) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state='REVIEW_REQUIRED',last_error=?,updated_at=? "
                            + "WHERE payout_uuid=? AND state='PROCESSING'")) {
                statement.setString(1, error);
                statement.setLong(2, System.currentTimeMillis());
                statement.setString(3, payoutId.toString());
                if (statement.executeUpdate() != 1) {
                    throw new IllegalStateException("Payout state changed before manual review could be recorded: "
                            + payoutId);
                }
            }
            return null;
        });
    }

    private CompletableFuture<Boolean> transition(UUID id, String from, String to, String note) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE token_payouts SET state=?,last_error=?,updated_at=? WHERE payout_uuid=? AND state=?")) {
                statement.setString(1, to);
                statement.setString(2, note);
                statement.setLong(3, System.currentTimeMillis());
                statement.setString(4, id.toString());
                statement.setString(5, from);
                return statement.executeUpdate() == 1;
            }
        });
    }

    private static PayoutStatus readStatus(ResultSet result) throws Exception {
        return new PayoutStatus(
                UUID.fromString(result.getString("payout_uuid")),
                UUID.fromString(result.getString("fight_uuid")),
                UUID.fromString(result.getString("player_uuid")),
                result.getInt("amount"),
                result.getInt("placement"),
                result.getString("state"),
                result.getInt("attempts"),
                result.getString("last_error"),
                result.getLong("created_at"));
    }

    private static String safeMessage(Throwable error) {
        if (error == null) return "Unknown payout error";
        String message = error.getMessage();
        if (message == null || message.isBlank()) message = error.getClass().getSimpleName();
        return message.length() > 500 ? message.substring(0, 500) : message;
    }

    private record Payout(UUID id, UUID playerId, int amount, int attempts) {}

    public record PayoutStatus(UUID payoutId, UUID fightId, UUID playerId, int amount, int placement,
                               String state, int attempts, String lastError, long createdAt) {}
}
