package dev.crimsonprogression.core;
import java.util.*;
public final class StateMachine<S extends Enum<S>> {
    private final Map<S,Set<S>> transitions;
    public StateMachine(Map<S,Set<S>> transitions){this.transitions=transitions.entrySet().stream().collect(java.util.stream.Collectors.toUnmodifiableMap(Map.Entry::getKey,e->Set.copyOf(e.getValue())));}
    public void require(S from,S to){if(!transitions.getOrDefault(from,Set.of()).contains(to))throw new IllegalStateException("Illegal transition "+from+" -> "+to);}
}
