package dev.crimsonprogression.listener;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.concurrent.CompletableFuture;

public final class PlayerLifecycleListener implements Listener {
    private final CrimsonProgressionPlugin plugin;

    public PlayerLifecycleListener(CrimsonProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.ready()) return;
        var player = event.getPlayer();
        CompletableFuture.allOf(
                plugin.tagService().load(player.getUniqueId()),
                plugin.cosmeticService().load(player.getUniqueId()),
                plugin.tokenService().refresh(player.getUniqueId()).thenAccept(ignored -> {})
        ).whenComplete((ignored, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null) plugin.getLogger().warning("Could not fully load progression cache for " + player.getName());
            if (!player.isOnline()) return;
            if (plugin.bossManager() != null) plugin.bossManager().reconcileEscrows(player);
            plugin.voucherService().recoverPlayer(player).whenComplete((recovered, recoveryError) ->
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (recoveryError != null) {
                            plugin.getLogger().warning("Voucher recovery failed for " + player.getName());
                            return;
                        }
                        if (player.isOnline()) {
                            plugin.pendingDeliveries().deliverOnJoin(player);
                            plugin.shopDeliveryService().processPendingFor(player.getUniqueId());
                        }
                    }));
            plugin.cosmeticService().joinEffect(player);
            if (plugin.bossManager() != null) plugin.bossManager().addPlayer(player);
        }));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        if (!plugin.ready()) return;
        var id = event.getPlayer().getUniqueId();
        plugin.tagService().unload(id);
        plugin.cosmeticService().unload(id);
        plugin.tokenService().unload(id);
    }
}
