package dev.crimsonprogression.boss;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.crimson.CrimsonArmorListener;
import dev.crimsonprogression.crimson.CrimsonArmorService;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;

public final class BossCombatListener implements Listener {
    private final CrimsonProgressionPlugin plugin;
    private final BossManager bosses;
    private final CrimsonArmorService armor;

    public BossCombatListener(CrimsonProgressionPlugin plugin, BossManager bosses, CrimsonArmorService armor) {
        this.plugin = plugin;
        this.bosses = bosses;
        this.armor = armor;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!bosses.isBoss(event.getEntity()) || !(event.getEntity() instanceof LivingEntity boss)) return;
        Player player = CrimsonArmorListener.player(event.getDamager());
        if (player == null) return;

        double rawHealth = boss.getHealth();
        double rawDamage = event.getFinalDamage();
        if (!Double.isFinite(rawHealth) || !Double.isFinite(rawDamage) || rawDamage <= 0.0D) return;
        double remaining = Math.max(0.0D, rawHealth);
        double recorded = Math.min(rawDamage, remaining);
        bosses.recordDamage(player, recorded, remaining);

        double configuredLifesteal = plugin.crimsonConfig().getDouble("abilities.lifesteal-percent", 0.10D);
        double lifesteal = Double.isFinite(configuredLifesteal)
                ? Math.max(0.0D, Math.min(1.0D, configuredLifesteal)) : 0.0D;
        if (armor.hasFullSet(player) && lifesteal > 0.0D && recorded > 0.0D && !player.isDead()) {
            AttributeInstance maximum = player.getAttribute(Attribute.MAX_HEALTH);
            double maximumHealth = maximum == null ? 20.0D : maximum.getValue();
            if (Double.isFinite(maximumHealth) && maximumHealth > 0.0D) {
                player.setHealth(Math.min(maximumHealth, player.getHealth() + recorded * lifesteal));
            }
        }
        if (recorded >= remaining) bosses.markKiller(player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        if (bosses.isBoss(event.getEntity())) bosses.defeated(event.getEntity());
    }
}
