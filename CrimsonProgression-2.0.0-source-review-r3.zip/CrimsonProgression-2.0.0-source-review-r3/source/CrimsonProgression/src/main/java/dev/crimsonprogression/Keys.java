package dev.crimsonprogression;
import org.bukkit.NamespacedKey;
public record Keys(NamespacedKey fightId, NamespacedKey summonerId, NamespacedKey summonerNonce, NamespacedKey summonerSignature,
                   NamespacedKey voucherReward, NamespacedKey voucherNonce, NamespacedKey voucherSchema, NamespacedKey voucherCreated,
                   NamespacedKey voucherIssuer, NamespacedKey voucherSignature, NamespacedKey crimsonPiece,
                   NamespacedKey crimsonSchema, NamespacedKey cosmeticId, NamespacedKey cosmeticSignature) {
    public static Keys create(CrimsonProgressionPlugin p){return new Keys(
      new NamespacedKey(p,"fight_id"),new NamespacedKey(p,"summoner_id"),new NamespacedKey(p,"summoner_nonce"),new NamespacedKey(p,"summoner_signature"),
      new NamespacedKey(p,"voucher_reward"),new NamespacedKey(p,"voucher_nonce"),new NamespacedKey(p,"voucher_schema"),new NamespacedKey(p,"voucher_created"),
      new NamespacedKey(p,"voucher_issuer"),new NamespacedKey(p,"voucher_signature"),new NamespacedKey(p,"crimson_piece"),new NamespacedKey(p,"crimson_schema"),
      new NamespacedKey(p,"cosmetic_id"),new NamespacedKey(p,"cosmetic_signature"));}
}
