package dev.crimsonprogression.voucher;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.core.HmacSigner;
import dev.crimsonprogression.core.VoucherPayload;
import dev.crimsonprogression.database.DatabaseService;
import dev.crimsonprogression.delivery.PendingDeliveryService;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/** Signed, nonce-backed voucher issuance and exactly-once database state management. */
public final class VoucherService {
    private final CrimsonProgressionPlugin plugin;
    private final DatabaseService database;
    private final PendingDeliveryService pendingDeliveries;
    private final HmacSigner signer;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final Map<String, Reward> rewards = new LinkedHashMap<>();

    public VoucherService(CrimsonProgressionPlugin plugin, DatabaseService database,
                          PendingDeliveryService pendingDeliveries, HmacSigner signer) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.database = Objects.requireNonNull(database, "database");
        this.pendingDeliveries = Objects.requireNonNull(pendingDeliveries, "pendingDeliveries");
        this.signer = Objects.requireNonNull(signer, "signer");
        reload();
    }

    public void reload() {
        Map<String, Reward> loaded = new LinkedHashMap<>();
        ConfigurationSection root = plugin.voucherConfig().getConfigurationSection("rewards");
        if (root != null) {
            for (String id : root.getKeys(false)) {
                if (!id.matches("[a-z0-9_-]{1,64}")) {
                    plugin.getLogger().severe("Disabled voucher reward with invalid ID: " + id);
                    continue;
                }
                ConfigurationSection section = root.getConfigurationSection(id);
                if (section == null) continue;
                List<ItemStack> contents;
                try {
                    contents = parseContents(id, section);
                } catch (RuntimeException exception) {
                    plugin.getLogger().log(Level.SEVERE,
                            "Disabled malformed voucher reward '" + id + "' instead of failing plugin startup.",
                            exception);
                    continue;
                }
                if (contents.isEmpty()) {
                    plugin.getLogger().severe("Disabled empty voucher reward: " + id);
                    continue;
                }
                loaded.put(id, new Reward(id, section.getString("name", id), contents));
            }
        }
        synchronized (rewards) {
            rewards.clear();
            rewards.putAll(loaded);
        }
    }

    public Set<String> ids() {
        synchronized (rewards) {
            return Set.copyOf(rewards.keySet());
        }
    }

    public CompletableFuture<ItemStack> issue(String rewardId, UUID issuer) {
        Reward reward = reward(rewardId);
        if (reward == null) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Unknown voucher reward: " + rewardId));
        }
        VoucherPayload payload = new VoucherPayload(rewardId, UUID.randomUUID(),
                plugin.voucherConfig().getInt("schema-version", 1), System.currentTimeMillis(), issuer);
        String signature = signer.sign(payload.canonical());
        ItemStack item = createItem(reward, payload, signature);
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO voucher_instances(nonce,reward_id,state,schema_version,created_at,"
                            + "issuing_player_uuid,signature,updated_at) VALUES(?,?,'ISSUED',?,?,?,?,?)")) {
                statement.setString(1, payload.nonce().toString());
                statement.setString(2, rewardId);
                statement.setInt(3, payload.schemaVersion());
                statement.setLong(4, payload.createdAt());
                statement.setString(5, issuer == null ? null : issuer.toString());
                statement.setString(6, signature);
                statement.setLong(7, System.currentTimeMillis());
                statement.executeUpdate();
            }
            return item;
        });
    }

    public Validation validate(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return Validation.invalid();
        var container = item.getItemMeta().getPersistentDataContainer();
        String rewardId = container.get(plugin.keys().voucherReward(), PersistentDataType.STRING);
        String nonce = container.get(plugin.keys().voucherNonce(), PersistentDataType.STRING);
        String signature = container.get(plugin.keys().voucherSignature(), PersistentDataType.STRING);
        Integer schema = container.get(plugin.keys().voucherSchema(), PersistentDataType.INTEGER);
        Long created = container.get(plugin.keys().voucherCreated(), PersistentDataType.LONG);
        String issuer = container.get(plugin.keys().voucherIssuer(), PersistentDataType.STRING);
        if (rewardId == null || nonce == null || signature == null || schema == null || created == null) {
            return Validation.invalid();
        }
        try {
            VoucherPayload payload = new VoucherPayload(rewardId, UUID.fromString(nonce), schema, created,
                    issuer == null ? null : UUID.fromString(issuer));
            Reward reward = reward(rewardId);
            return reward != null && signer.verify(payload.canonical(), signature)
                    ? new Validation(true, payload, reward) : Validation.invalid();
        } catch (IllegalArgumentException exception) {
            return Validation.invalid();
        }
    }

    public boolean allowRightClick() {
        return plugin.voucherConfig().getBoolean("allow-right-click", false);
    }

    /** Called on the main thread after InventoryClickEvent has been cancelled. */
    public void claim(Player player, int slot, ItemStack clicked) {
        Validation validation = validate(clicked);
        if (!validation.valid()) {
            plugin.messages().send(player, "voucher-invalid");
            return;
        }
        long lifetimeSeconds = Math.max(0L, plugin.voucherConfig().getLong("expiry-seconds", 0L));
        if (lifetimeSeconds > 0L
                && System.currentTimeMillis() - validation.payload().createdAt() > lifetimeSeconds * 1000L) {
            cancelExpired(validation.payload().nonce());
            plugin.messages().send(player, "voucher-expired");
            return;
        }
        if (!plugin.voucherConfig().getBoolean("tradeable", true)
                && validation.payload().issuer() != null
                && !validation.payload().issuer().equals(player.getUniqueId())) {
            plugin.messages().send(player, "voucher-not-owner");
            return;
        }
        if (!pendingDeliveries.fits(player, validation.reward().contents())) {
            plugin.messages().send(player, "voucher-no-space");
            return;
        }

        UUID deliveryId = UUID.randomUUID();
        reserveClaim(validation.payload(), player.getUniqueId(), deliveryId, validation.reward().contents())
                .whenComplete((reserved, reserveError) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (reserveError != null) {
                        plugin.fail(player, "voucher-reserve", reserveError);
                        return;
                    }
                    if (!reserved) {
                        plugin.messages().send(player, "voucher-already-claimed");
                        return;
                    }

                    ItemStack current = player.getInventory().getItem(slot);
                    Validation currentValidation = validate(current);
                    boolean sameVoucher = currentValidation.valid()
                            && currentValidation.payload().nonce().equals(validation.payload().nonce());
                    if (!sameVoucher || !pendingDeliveries.fits(player, validation.reward().contents())) {
                        rollbackReservation(validation.payload().nonce(), deliveryId)
                                .exceptionally(error -> {
                                    plugin.getLogger().log(Level.SEVERE,
                                            "Could not roll back voucher reservation " + validation.payload().nonce(), error);
                                    return false;
                                });
                        plugin.messages().send(player, sameVoucher ? "voucher-no-space" : "voucher-invalid");
                        return;
                    }

                    beginExternalDelivery(deliveryId).whenComplete((begun, beginError) ->
                            Bukkit.getScheduler().runTask(plugin, () -> {
                                if (beginError != null || !Boolean.TRUE.equals(begun)) {
                                    rollbackReservation(validation.payload().nonce(), deliveryId);
                                    plugin.fail(player, "voucher-delivery-begin",
                                            beginError == null ? new IllegalStateException("Delivery state changed") : beginError);
                                    return;
                                }
                                boolean delivered;
                                try {
                                    removeExactlyOne(player, slot, current);
                                    delivered = pendingDeliveries.tryDeliverNow(player, validation.reward().contents());
                                } catch (RuntimeException deliveryFailure) {
                                    boolean voucherStillPresent = containsVoucherNonce(player, validation.payload().nonce());
                                    CompletableFuture<?> recovery = voucherStillPresent
                                            ? rollbackReservation(validation.payload().nonce(), deliveryId)
                                            : markReviewRequired(validation.payload().nonce(), deliveryId);
                                    recovery.whenComplete((ignored, recoveryError) -> {
                                        if (recoveryError != null) {
                                            deliveryFailure.addSuppressed(recoveryError);
                                        }
                                        plugin.getLogger().log(Level.SEVERE,
                                                "Voucher delivery failed at the Bukkit inventory boundary. "
                                                        + "Reconciliation ID: " + deliveryId,
                                                deliveryFailure);
                                    });
                                    plugin.messages().send(player, voucherStillPresent
                                            ? "voucher-delivery-failed" : "voucher-delivery-review");
                                    return;
                                }
                                if (!delivered) {
                                    // The capacity check ran immediately before this operation. If Bukkit still rejects
                                    // delivery, preserve the committed reward as a pending bundle rather than duplicating
                                    // or silently losing it.
                                    markPendingRecovery(validation.payload().nonce(), deliveryId)
                                            .whenComplete((ignored, error) -> {
                                                if (error != null) plugin.getLogger().log(Level.SEVERE,
                                                        "Voucher reward requires manual recovery: " + deliveryId, error);
                                            });
                                    plugin.messages().send(player, "voucher-delivery-pending");
                                    return;
                                }
                                finishClaim(validation.payload().nonce(), player.getUniqueId(), deliveryId)
                                        .whenComplete((finished, finishError) -> Bukkit.getScheduler().runTask(plugin, () -> {
                                            if (finishError != null || !Boolean.TRUE.equals(finished)) {
                                                plugin.getLogger().log(Level.SEVERE,
                                                        "Voucher contents were delivered but the journal could not close. "
                                                                + "Do not retry delivery ID " + deliveryId,
                                                        finishError);
                                                plugin.messages().send(player, "voucher-delivered-reconcile");
                                            } else {
                                                plugin.messages().send(player, "voucher-claimed");
                                            }
                                        }));
                            }));
                }));
    }

    /**
     * Resolves interrupted voucher claims before ordinary pending deliveries are processed.
     * A voucher still present means no external delivery happened and the reservation is rolled back.
     * A missing voucher in DELIVERING state is deliberately placed in REVIEW_REQUIRED to avoid a duplicate.
     */
    public CompletableFuture<Void> recoverPlayer(Player player) {
        UUID playerId = player.getUniqueId();
        return loadInterrupted(playerId).thenCompose(interrupted -> {
            CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
            for (InterruptedClaim claim : interrupted) {
                chain = chain.thenCompose(ignored -> {
                    boolean voucherPresent = containsVoucherNonce(player, claim.nonce());
                    if (voucherPresent) return rollbackReservation(claim.nonce(), claim.deliveryId()).thenApply(value -> null);
                    return markReviewRequired(claim.nonce(), claim.deliveryId()).thenApply(value -> null);
                });
            }
            return chain;
        });
    }

    private CompletableFuture<Boolean> reserveClaim(VoucherPayload payload, UUID holder, UUID deliveryId,
                                                     Collection<ItemStack> contents) {
        return database.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='CLAIMING',claimed_by_uuid=?,claim_delivery_uuid=?,updated_at=? "
                            + "WHERE nonce=? AND reward_id=? AND signature=? AND state='ISSUED'")) {
                statement.setString(1, holder.toString());
                statement.setString(2, deliveryId.toString());
                statement.setLong(3, System.currentTimeMillis());
                statement.setString(4, payload.nonce().toString());
                statement.setString(5, payload.rewardId());
                statement.setString(6, signer.sign(payload.canonical()));
                if (statement.executeUpdate() != 1) return false;
            }
            PendingDeliveryService.insert(connection, deliveryId, holder, "VOUCHER_CLAIM", contents, "RESERVED");
            return true;
        });
    }

    private CompletableFuture<Boolean> beginExternalDelivery(UUID deliveryId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='DELIVERING',updated_at=? "
                            + "WHERE delivery_uuid=? AND state='RESERVED'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, deliveryId.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    private CompletableFuture<Boolean> finishClaim(UUID nonce, UUID holder, UUID deliveryId) {
        return database.transaction(connection -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='CLAIMED',claimed_by_uuid=?,claimed_at=?,updated_at=? "
                            + "WHERE nonce=? AND claim_delivery_uuid=? AND state='CLAIMING'")) {
                statement.setString(1, holder.toString());
                statement.setLong(2, now);
                statement.setLong(3, now);
                statement.setString(4, nonce.toString());
                statement.setString(5, deliveryId.toString());
                if (statement.executeUpdate() != 1) return false;
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='DELIVERED',updated_at=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                statement.setLong(1, now);
                statement.setString(2, deliveryId.toString());
                if (statement.executeUpdate() != 1) throw new SQLException("Voucher delivery journal changed");
            }
            return true;
        });
    }

    private CompletableFuture<Boolean> rollbackReservation(UUID nonce, UUID deliveryId) {
        return database.transaction(connection -> {
            try (PreparedStatement voucher = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='ISSUED',claimed_by_uuid=NULL,claim_delivery_uuid=NULL,updated_at=? "
                            + "WHERE nonce=? AND claim_delivery_uuid=? AND state='CLAIMING'")) {
                voucher.setLong(1, System.currentTimeMillis());
                voucher.setString(2, nonce.toString());
                voucher.setString(3, deliveryId.toString());
                if (voucher.executeUpdate() != 1) return false;
            }
            try (PreparedStatement delivery = connection.prepareStatement(
                    "DELETE FROM pending_deliveries WHERE delivery_uuid=? AND state IN ('RESERVED','DELIVERING')")) {
                delivery.setString(1, deliveryId.toString());
                if (delivery.executeUpdate() != 1) {
                    throw new SQLException("Voucher delivery journal changed before reservation rollback");
                }
            }
            return true;
        });
    }

    private CompletableFuture<Void> markPendingRecovery(UUID nonce, UUID deliveryId) {
        return database.transaction(connection -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement voucher = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='CLAIMED',claimed_at=?,updated_at=? "
                            + "WHERE nonce=? AND claim_delivery_uuid=? AND state='CLAIMING'")) {
                voucher.setLong(1, now);
                voucher.setLong(2, now);
                voucher.setString(3, nonce.toString());
                voucher.setString(4, deliveryId.toString());
                if (voucher.executeUpdate() != 1) {
                    throw new SQLException("Voucher claim changed before pending recovery could be recorded");
                }
            }
            try (PreparedStatement delivery = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='PENDING',updated_at=?,last_error=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                delivery.setLong(1, now);
                delivery.setString(2, "Bukkit inventory delivery rejected after capacity validation");
                delivery.setString(3, deliveryId.toString());
                if (delivery.executeUpdate() != 1) {
                    throw new SQLException("Voucher delivery journal changed before pending recovery could be recorded");
                }
            }
            return null;
        });
    }

    private CompletableFuture<Boolean> markReviewRequired(UUID nonce, UUID deliveryId) {
        return database.transaction(connection -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement voucher = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='REVIEW_REQUIRED',updated_at=? "
                            + "WHERE nonce=? AND claim_delivery_uuid=? AND state='CLAIMING'")) {
                voucher.setLong(1, now);
                voucher.setString(2, nonce.toString());
                voucher.setString(3, deliveryId.toString());
                if (voucher.executeUpdate() != 1) return false;
            }
            try (PreparedStatement delivery = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='REVIEW_REQUIRED',updated_at=?,last_error=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                delivery.setLong(1, now);
                delivery.setString(2, "Server stopped during external inventory delivery; reconcile before retry");
                delivery.setString(3, deliveryId.toString());
                if (delivery.executeUpdate() != 1) {
                    throw new SQLException("Voucher delivery journal changed before review quarantine");
                }
            }
            plugin.getLogger().severe("Voucher claim interrupted during inventory delivery. Manual reconciliation ID: "
                    + deliveryId);
            return true;
        });
    }

    private CompletableFuture<List<InterruptedClaim>> loadInterrupted(UUID holder) {
        return database.submit(connection -> {
            List<InterruptedClaim> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT nonce,claim_delivery_uuid FROM voucher_instances "
                            + "WHERE claimed_by_uuid=? AND state='CLAIMING' AND claim_delivery_uuid IS NOT NULL")) {
                statement.setString(1, holder.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        rows.add(new InterruptedClaim(UUID.fromString(result.getString(1)),
                                UUID.fromString(result.getString(2))));
                    }
                }
            }
            return List.copyOf(rows);
        });
    }

    private boolean containsVoucherNonce(Player player, UUID nonce) {
        for (ItemStack item : player.getInventory().getContents()) {
            Validation validation = validate(item);
            if (validation.valid() && validation.payload().nonce().equals(nonce)) return true;
        }
        return false;
    }

    private void removeExactlyOne(Player player, int slot, ItemStack current) {
        int amount = current.getAmount();
        if (amount <= 1) player.getInventory().setItem(slot, null);
        else {
            ItemStack reduced = current.clone();
            reduced.setAmount(amount - 1);
            player.getInventory().setItem(slot, reduced);
        }
    }

    private ItemStack createItem(Reward reward, VoucherPayload payload, String signature) {
        Material material = Material.matchMaterial(plugin.voucherConfig().getString("book.material", "WRITTEN_BOOK"));
        if (material == null || material.isAir()) material = Material.WRITTEN_BOOK;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(safeDeserialize(plugin.voucherConfig()
                .getString("book.name", "<gold><reward_name> Voucher</gold>")
                .replace("<reward_name>", escapeMiniMessage(reward.name())), reward.name() + " Voucher"));
        meta.lore(plugin.voucherConfig().getStringList("book.lore").stream()
                .map(line -> safeDeserialize(line.replace("<reward_name>", escapeMiniMessage(reward.name())), line))
                .toList());
        var pdc = meta.getPersistentDataContainer();
        pdc.set(plugin.keys().voucherReward(), PersistentDataType.STRING, payload.rewardId());
        pdc.set(plugin.keys().voucherNonce(), PersistentDataType.STRING, payload.nonce().toString());
        pdc.set(plugin.keys().voucherSchema(), PersistentDataType.INTEGER, payload.schemaVersion());
        pdc.set(plugin.keys().voucherCreated(), PersistentDataType.LONG, payload.createdAt());
        if (payload.issuer() != null) {
            pdc.set(plugin.keys().voucherIssuer(), PersistentDataType.STRING, payload.issuer().toString());
        }
        pdc.set(plugin.keys().voucherSignature(), PersistentDataType.STRING, signature);
        item.setItemMeta(meta);
        return item;
    }

    private List<ItemStack> parseContents(String rewardId, ConfigurationSection section) {
        List<ItemStack> contents = new ArrayList<>();
        int entryIndex = 0;
        for (Map<?, ?> entry : section.getMapList("contents")) {
            entryIndex++;
            Material material = Material.matchMaterial(String.valueOf(entry.get("material")));
            int amount = entry.get("amount") instanceof Number number ? number.intValue() : 1;
            if (material == null || material.isAir() || amount <= 0) {
                plugin.getLogger().warning("Invalid voucher item in " + rewardId + " at contents[" + entryIndex + "]: " + entry);
                continue;
            }
            ItemStack template = new ItemStack(material);
            ItemMeta meta = template.getItemMeta();
            applyConfiguredMeta(rewardId, entryIndex, entry, meta);
            template.setItemMeta(meta);
            while (amount > 0) {
                int part = Math.min(amount, Math.max(1, material.getMaxStackSize()));
                ItemStack stack = template.clone();
                stack.setAmount(part);
                contents.add(stack);
                amount -= part;
            }
        }
        return List.copyOf(contents);
    }

    private void applyConfiguredMeta(String rewardId, int entryIndex, Map<?, ?> entry, ItemMeta meta) {
        Object configuredName = entry.get("name");
        if (configuredName != null) {
            String value = String.valueOf(configuredName);
            meta.displayName(safeDeserialize(value, value));
        }
        Object configuredLore = entry.get("lore");
        if (configuredLore instanceof Collection<?> lines) {
            meta.lore(lines.stream().map(String::valueOf).map(line -> safeDeserialize(line, line)).toList());
        }
        Object unbreakable = entry.get("unbreakable");
        if (unbreakable instanceof Boolean value) invokeMeta(meta, "setUnbreakable", value);
        Object customModel = entry.get("custom-model-data");
        if (customModel instanceof Number number) invokeMeta(meta, "setCustomModelData", number.intValue());

        applyEnchantMap(rewardId, entryIndex, entry.get("enchantments"), meta, false);
        applyEnchantMap(rewardId, entryIndex, entry.get("stored-enchantments"), meta, true);

        Object potion = entry.get("potion-type");
        if (potion != null && !applyPotionType(meta, String.valueOf(potion))) {
            plugin.getLogger().warning("Invalid or unsupported potion-type in voucher " + rewardId
                    + " contents[" + entryIndex + "]: " + potion);
        }
    }

    private void applyEnchantMap(String rewardId, int entryIndex, Object raw, ItemMeta meta, boolean stored) {
        if (!(raw instanceof Map<?, ?> enchantments)) return;
        if (stored && !isMetaType(meta, "org.bukkit.inventory.meta.EnchantmentStorageMeta")) {
            plugin.getLogger().warning("stored-enchantments used on non-enchanted-book item in voucher "
                    + rewardId + " contents[" + entryIndex + "]");
            return;
        }
        for (Map.Entry<?, ?> entry : enchantments.entrySet()) {
            NamespacedKey key = NamespacedKey.fromString(String.valueOf(entry.getKey()).toLowerCase(Locale.ROOT));
            int level = entry.getValue() instanceof Number number ? Math.max(1, number.intValue()) : 1;
            Enchantment enchantment = key == null ? null : Registry.ENCHANTMENT.get(key);
            if (enchantment == null) {
                plugin.getLogger().warning("Unknown enchantment in voucher " + rewardId + " contents["
                        + entryIndex + "]: " + entry.getKey());
                continue;
            }
            if (stored) invokeMeta(meta, "addStoredEnchant", enchantment, level, true);
            else meta.addEnchant(enchantment, level, true);
        }
    }

    private boolean applyPotionType(ItemMeta meta, String configured) {
        try {
            Class<?> potionMeta = Class.forName("org.bukkit.inventory.meta.PotionMeta", false,
                    VoucherService.class.getClassLoader());
            if (!potionMeta.isInstance(meta)) return false;
            Class<?> potionType = Class.forName("org.bukkit.potion.PotionType", false,
                    VoucherService.class.getClassLoader());
            @SuppressWarnings({"rawtypes", "unchecked"})
            Object value = Enum.valueOf((Class<? extends Enum>) potionType.asSubclass(Enum.class),
                    configured.toUpperCase(Locale.ROOT));
            invokeMeta(meta, "setBasePotionType", value);
            return true;
        } catch (ClassNotFoundException | IllegalArgumentException exception) {
            return false;
        }
    }

    private static boolean isMetaType(ItemMeta meta, String typeName) {
        try {
            return Class.forName(typeName, false, VoucherService.class.getClassLoader()).isInstance(meta);
        } catch (ClassNotFoundException exception) {
            return false;
        }
    }

    private static Object invokeMeta(ItemMeta meta, String methodName, Object... arguments) {
        Method method = Arrays.stream(meta.getClass().getMethods())
                .filter(candidate -> candidate.getName().equals(methodName))
                .filter(candidate -> candidate.getParameterCount() == arguments.length)
                .filter(candidate -> parametersMatch(candidate.getParameterTypes(), arguments))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Unsupported ItemMeta method: " + methodName));
        try {
            return method.invoke(meta, arguments);
        } catch (IllegalAccessException exception) {
            throw new IllegalStateException("Cannot access ItemMeta method: " + methodName, exception);
        } catch (InvocationTargetException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            throw new IllegalStateException("ItemMeta method failed: " + methodName, cause);
        }
    }

    private static boolean parametersMatch(Class<?>[] parameterTypes, Object[] arguments) {
        for (int index = 0; index < parameterTypes.length; index++) {
            if (arguments[index] == null) continue;
            Class<?> type = parameterTypes[index];
            if (type.isPrimitive()) {
                type = type == boolean.class ? Boolean.class
                        : type == int.class ? Integer.class
                        : type == long.class ? Long.class
                        : type == double.class ? Double.class
                        : type == float.class ? Float.class
                        : type == byte.class ? Byte.class
                        : type == short.class ? Short.class
                        : type == char.class ? Character.class : type;
            }
            if (!type.isInstance(arguments[index])) return false;
        }
        return true;
    }

    private CompletableFuture<Void> cancelExpired(UUID nonce) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE voucher_instances SET state='CANCELLED',updated_at=? WHERE nonce=? AND state='ISSUED'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, nonce.toString());
                statement.executeUpdate();
            }
            return null;
        });
    }

    private static String escapeMiniMessage(String value) {
        return value == null ? "" : value.replace("<", "\\<").replace(">", "\\>");
    }

    private net.kyori.adventure.text.Component safeDeserialize(String input, String fallback) {
        try {
            return miniMessage.deserialize(input == null ? "" : input);
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.WARNING,
                    "Invalid MiniMessage text in vouchers.yml; using plain fallback text.", exception);
            return net.kyori.adventure.text.Component.text(fallback == null ? "" : fallback);
        }
    }

    private Reward reward(String id) {
        synchronized (rewards) {
            return rewards.get(id);
        }
    }

    public record Reward(String id, String name, List<ItemStack> contents) {
        public Reward {
            contents = List.copyOf(contents);
        }
    }

    public record Validation(boolean valid, VoucherPayload payload, Reward reward) {
        static Validation invalid() {
            return new Validation(false, null, null);
        }
    }

    private record InterruptedClaim(UUID nonce, UUID deliveryId) {}
}
