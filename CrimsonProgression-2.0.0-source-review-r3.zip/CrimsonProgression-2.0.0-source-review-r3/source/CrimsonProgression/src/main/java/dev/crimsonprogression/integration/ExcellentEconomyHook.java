package dev.crimsonprogression.integration;

import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Uses the public ExcellentEconomy service while avoiding a hard class-link at plugin load time. */
public final class ExcellentEconomyHook {
    private static final String API_CLASS = "su.nightexpress.excellenteconomy.api.ExcellentEconomyAPI";

    private final Object api;
    private final String currencyId;

    private ExcellentEconomyHook(Object api, String currencyId) {
        this.api = Objects.requireNonNull(api, "api");
        this.currencyId = Objects.requireNonNull(currencyId, "currencyId");
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static ExcellentEconomyHook hook(String currencyId) {
        try {
            Class apiClass = Class.forName(API_CLASS, true, ExcellentEconomyHook.class.getClassLoader());
            RegisteredServiceProvider registration = Bukkit.getServicesManager().getRegistration(apiClass);
            if (registration == null || registration.getProvider() == null) return null;
            ExcellentEconomyHook hook = new ExcellentEconomyHook(registration.getProvider(), currencyId);
            return hook.hasCurrency() ? hook : null;
        } catch (ClassNotFoundException exception) {
            return null;
        }
    }

    public CompletableFuture<Double> balance(UUID player) {
        return castFuture(ReflectionSupport.invoke(api, "getBalanceAsync", player, currencyId))
                .thenApply(value -> ((Number) value).doubleValue());
    }

    public CompletableFuture<Boolean> deposit(UUID player, double amount) {
        return operation("depositAsync", player, amount);
    }

    public CompletableFuture<Boolean> withdraw(UUID player, double amount) {
        return operation("withdrawAsync", player, amount);
    }

    public CompletableFuture<Boolean> set(UUID player, double amount) {
        return operation("setBalanceAsync", player, amount);
    }

    public boolean available() {
        return canPerformOperations() && hasCurrency();
    }

    private CompletableFuture<Boolean> operation(String method, UUID player, double amount) {
        if (!Double.isFinite(amount) || amount < 0D || !available()) {
            return CompletableFuture.completedFuture(false);
        }
        return castFuture(ReflectionSupport.invoke(api, method, player, currencyId, amount))
                .thenApply(ExcellentEconomyHook::operationSucceeded);
    }

    private boolean hasCurrency() {
        Object value = ReflectionSupport.invoke(api, "hasCurrency", currencyId);
        return Boolean.TRUE.equals(value);
    }

    private boolean canPerformOperations() {
        Object value = ReflectionSupport.invoke(api, "canPerformOperations");
        return Boolean.TRUE.equals(value);
    }

    private static boolean operationSucceeded(Object result) {
        if (result instanceof Boolean value) return value;
        if (result == null) return false;
        try {
            return Boolean.TRUE.equals(ReflectionSupport.invoke(result, "success"));
        } catch (RuntimeException ignored) {
            return Boolean.TRUE.equals(ReflectionSupport.invoke(result, "isSuccess"));
        }
    }

    @SuppressWarnings("unchecked")
    private static CompletableFuture<Object> castFuture(Object value) {
        if (!(value instanceof CompletableFuture<?> future)) {
            throw new IllegalStateException("ExcellentEconomy API returned no CompletableFuture");
        }
        return (CompletableFuture<Object>) future;
    }
}
