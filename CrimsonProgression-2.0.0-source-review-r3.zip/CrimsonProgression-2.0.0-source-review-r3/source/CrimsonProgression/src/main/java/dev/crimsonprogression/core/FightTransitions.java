package dev.crimsonprogression.core;
import java.util.*;
public final class FightTransitions {
    public static StateMachine<FightState> create(){return new StateMachine<>(Map.ofEntries(
      Map.entry(FightState.ESCROW_PENDING,Set.of(FightState.ESCROWED,FightState.REFUND_PENDING)),
      Map.entry(FightState.ESCROWED,Set.of(FightState.WORLD_LOADING,FightState.REFUND_PENDING)),
      Map.entry(FightState.WORLD_LOADING,Set.of(FightState.CHUNKS_LOADING,FightState.REFUND_PENDING)),
      Map.entry(FightState.CHUNKS_LOADING,Set.of(FightState.SPAWNING,FightState.REFUND_PENDING)),
      Map.entry(FightState.SPAWNING,Set.of(FightState.SPAWN_CONFIRMED,FightState.REFUND_PENDING)),
      Map.entry(FightState.SPAWN_CONFIRMED,Set.of(FightState.ACTIVE,FightState.REFUND_PENDING)),
      Map.entry(FightState.ACTIVE,Set.of(FightState.ENDING,FightState.CANCELLED,FightState.RECOVERY_FAILED)),
      Map.entry(FightState.ENDING,Set.of(FightState.COMPLETED,FightState.RECOVERY_FAILED)),
      Map.entry(FightState.CANCELLED,Set.of(FightState.REFUND_PENDING,FightState.COMPLETED)),
      Map.entry(FightState.RECOVERY_FAILED,Set.of(FightState.REFUND_PENDING,FightState.COMPLETED)),
      Map.entry(FightState.REFUND_PENDING,Set.of(FightState.COMPLETED))));}
    private FightTransitions(){}
}
