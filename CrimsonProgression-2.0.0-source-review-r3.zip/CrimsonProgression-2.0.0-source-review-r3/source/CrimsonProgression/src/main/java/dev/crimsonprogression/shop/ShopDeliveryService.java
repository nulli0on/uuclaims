package dev.crimsonprogression.shop;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.database.DatabaseService;
import dev.crimsonprogression.integration.ExcellentCratesHook;
import dev.crimsonprogression.integration.LuckPermsHook;
import dev.crimsonprogression.integration.UltimateClaimsHook;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

/**
 * Durable delivery endpoint used by ExcellentShop command products.
 *
 * <p>ExcellentShop remains responsible for price validation and currency
 * deduction. Once this service commits a QUEUED row, the purchased reward is no
 * longer dependent on the player staying online. External deliveries are
 * retried. A shutdown during a non-transactional external API call is quarantined
 * as REVIEW_REQUIRED rather than blindly duplicating keys or claim blocks.</p>
 */
public final class ShopDeliveryService {
    private final CrimsonProgressionPlugin plugin;
    private final DatabaseService database;
    private final ExcellentCratesHook crates;
    private final LuckPermsHook luckPerms;
    private final UltimateClaimsHook claims;
    private final Map<String, Product> products = new ConcurrentHashMap<>();
    private final Set<UUID> inFlightTransactions = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean workerRunning = new AtomicBoolean();
    private volatile int maxAutomaticAttempts = 5;

    public ShopDeliveryService(CrimsonProgressionPlugin plugin, DatabaseService database,
                               ExcellentCratesHook crates, LuckPermsHook luckPerms,
                               UltimateClaimsHook claims) {
        this.plugin = plugin;
        this.database = database;
        this.crates = crates;
        this.luckPerms = luckPerms;
        this.claims = claims;
        reload();
    }

    public void reload() {
        maxAutomaticAttempts = Math.max(1, Math.min(100,
                plugin.shopProductConfig().getInt("delivery.max-automatic-attempts", 5)));
        Map<String, Product> loaded = new LinkedHashMap<>();
        ConfigurationSection root = plugin.shopProductConfig().getConfigurationSection("products");
        if (root != null) {
            for (String id : root.getKeys(false)) {
                ConfigurationSection section = root.getConfigurationSection(id);
                if (section == null) continue;
                String typeRaw = section.getString("type", "");
                try {
                    ProductType type = ProductType.valueOf(typeRaw.toUpperCase(Locale.ROOT));
                    Product product = new Product(
                            id,
                            type,
                            section.getString("key-id"),
                            section.getString("tag-id"),
                            section.getString("cosmetic-id"),
                            section.getString("group"),
                            Math.max(1, section.getInt("amount", 1))
                    );
                    String validationError = validate(product);
                    if (validationError == null) loaded.put(id, product);
                    else plugin.getLogger().severe("Disabled ExcellentShop product '" + id + "': " + validationError);
                } catch (IllegalArgumentException exception) {
                    plugin.getLogger().warning("Unknown shop product type for " + id + ": " + typeRaw);
                }
            }
        }
        products.clear();
        products.putAll(loaded);
    }

    public Set<String> productIds() {
        return Set.copyOf(products.keySet());
    }

    /** Commits a purchase delivery and starts best-effort immediate processing. */
    public CompletableFuture<DeliveryResult> deliver(UUID playerId, String productId) {
        if (playerId == null) return CompletableFuture.completedFuture(DeliveryResult.failure("missing player UUID"));
        Product product = products.get(productId);
        if (product == null) return CompletableFuture.completedFuture(DeliveryResult.failure("unknown or disabled product"));
        UUID transactionId = UUID.randomUUID();
        return insert(transactionId, playerId, productId)
                .thenApply(inserted -> {
                    if (!inserted) return DeliveryResult.failure("could not create delivery journal");
                    processTransaction(transactionId);
                    return new DeliveryResult(true, "queued safely", transactionId);
                });
    }

    public CompletableFuture<Void> processPending() {
        if (!workerRunning.compareAndSet(false, true)) return CompletableFuture.completedFuture(null);
        return quarantineInterrupted()
                .thenCompose(ignored -> loadPending(null, 100))
                .thenCompose(this::processSequentially)
                .whenComplete((ignored, error) -> workerRunning.set(false));
    }

    public CompletableFuture<Void> processPendingFor(UUID playerId) {
        return loadPending(playerId, 100).thenCompose(this::processSequentially);
    }

    public CompletableFuture<List<ReviewEntry>> reviewRequired() {
        return database.submit(connection -> {
            List<ReviewEntry> result = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT transaction_uuid,player_uuid,product_id,attempts,last_error,created_at "
                            + "FROM shop_deliveries WHERE state='REVIEW_REQUIRED' ORDER BY created_at")) {
                try (ResultSet rows = statement.executeQuery()) {
                    while (rows.next()) {
                        result.add(new ReviewEntry(
                                UUID.fromString(rows.getString("transaction_uuid")),
                                UUID.fromString(rows.getString("player_uuid")),
                                rows.getString("product_id"),
                                rows.getInt("attempts"),
                                rows.getString("last_error"),
                                rows.getLong("created_at")));
                    }
                }
            }
            return List.copyOf(result);
        });
    }

    public CompletableFuture<Boolean> retry(UUID transactionId) {
        return transition(transactionId, "REVIEW_REQUIRED", "RETRY", "Manually approved retry")
                .thenApply(changed -> {
                    if (changed) processTransaction(transactionId);
                    return changed;
                });
    }

    public CompletableFuture<Boolean> markCompleted(UUID transactionId) {
        return transition(transactionId, "REVIEW_REQUIRED", "COMPLETED", "Manually confirmed delivered");
    }

    private CompletableFuture<Void> processSequentially(List<DeliveryRow> rows) {
        CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
        for (DeliveryRow row : rows) chain = chain.thenCompose(ignored -> process(row));
        return chain;
    }

    private void processTransaction(UUID transactionId) {
        load(transactionId).thenCompose(row -> row == null
                        ? CompletableFuture.completedFuture(null)
                        : process(row))
                .exceptionally(error -> {
                    plugin.getLogger().log(Level.WARNING, "ExcellentShop delivery processing failed for " + transactionId, error);
                    return null;
                });
    }

    private CompletableFuture<Void> process(DeliveryRow row) {
        Product product = products.get(row.productId());
        if (product == null) {
            return mark(row.transactionId(), "REVIEW_REQUIRED", "Product is missing or disabled in current configuration");
        }
        if (!inFlightTransactions.add(row.transactionId())) return CompletableFuture.completedFuture(null);
        return claim(row.transactionId()).thenCompose(claimed -> {
            if (!claimed) return CompletableFuture.completedFuture(null);
            return execute(row.playerId(), product).handle((outcome, error) -> {
                if (error != null) {
                    Throwable cause = error instanceof CompletionException && error.getCause() != null
                            ? error.getCause() : error;
                    String reason = safeMessage(cause);
                    if (!product.type().automaticRetrySafe()) {
                        return mark(row.transactionId(), "REVIEW_REQUIRED",
                                "Ambiguous non-idempotent delivery failure; verify before retrying: " + reason);
                    }
                    return retryOrReview(row, reason);
                }
                return switch (outcome) {
                    case DELIVERED -> mark(row.transactionId(), "COMPLETED", null);
                    case WAITING_FOR_PLAYER -> mark(row.transactionId(), "WAITING_PLAYER", "Purchasing player is offline");
                    case REJECTED -> retryOrReview(row, "Integration rejected delivery");
                };
            }).thenCompose(future -> future);
        }).whenComplete((ignored, error) -> inFlightTransactions.remove(row.transactionId()));
    }

    private CompletableFuture<Outcome> execute(UUID playerId, Product product) {
        return switch (product.type()) {
            case EXCELLENTCRATES_KEY -> mainThread(() -> {
                Player player = Bukkit.getPlayer(playerId);
                if (player == null || !player.isOnline()) return Outcome.WAITING_FOR_PLAYER;
                return crates != null && crates.giveKey(player, product.keyId(), product.amount())
                        ? Outcome.DELIVERED : Outcome.REJECTED;
            });
            case LUCKPERMS_GROUP -> luckPerms == null
                    ? CompletableFuture.completedFuture(Outcome.REJECTED)
                    : luckPerms.addGroup(playerId, product.group())
                    .thenApply(success -> success ? Outcome.DELIVERED : Outcome.REJECTED);
            case TAG -> plugin.tagService().grant(playerId, product.tagId(), "EXCELLENTSHOP")
                    .thenApply(success -> success ? Outcome.DELIVERED : Outcome.REJECTED);
            case COSMETIC -> plugin.cosmeticService().grant(playerId, product.cosmeticId(), "EXCELLENTSHOP")
                    .thenApply(success -> success ? Outcome.DELIVERED : Outcome.REJECTED);
            case ULTIMATECLAIMS_BLOCKS -> claims == null
                    ? CompletableFuture.completedFuture(Outcome.REJECTED)
                    : claims.addClaimBlocks(playerId, product.amount())
                    .thenApply(success -> success ? Outcome.DELIVERED : Outcome.REJECTED);
        };
    }

    private <T> CompletableFuture<T> mainThread(java.util.concurrent.Callable<T> action) {
        if (Bukkit.isPrimaryThread()) {
            try {
                return CompletableFuture.completedFuture(action.call());
            } catch (Exception exception) {
                return CompletableFuture.failedFuture(exception);
            }
        }
        CompletableFuture<T> future = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                future.complete(action.call());
            } catch (Exception exception) {
                future.completeExceptionally(exception);
            }
        });
        return future;
    }

    private CompletableFuture<Boolean> insert(UUID transactionId, UUID playerId, String productId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT OR IGNORE INTO shop_deliveries(transaction_uuid,idempotency_key,player_uuid,product_id,state,payload_json,created_at,updated_at) "
                            + "VALUES(?,?,?,?, 'QUEUED',?,?,?)")) {
                long now = System.currentTimeMillis();
                statement.setString(1, transactionId.toString());
                statement.setString(2, transactionId.toString());
                statement.setString(3, playerId.toString());
                statement.setString(4, productId);
                statement.setString(5, "{\"product\":\"" + jsonEscape(productId) + "\"}");
                statement.setLong(6, now);
                statement.setLong(7, now);
                return statement.executeUpdate() == 1;
            }
        });
    }

    private CompletableFuture<DeliveryRow> load(UUID transactionId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT transaction_uuid,player_uuid,product_id,state,attempts FROM shop_deliveries WHERE transaction_uuid=?")) {
                statement.setString(1, transactionId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    return result.next() ? readRow(result) : null;
                }
            }
        });
    }

    private CompletableFuture<List<DeliveryRow>> loadPending(UUID playerId, int limit) {
        return database.submit(connection -> {
            List<DeliveryRow> result = new ArrayList<>();
            String states = playerId == null
                    ? "('QUEUED','RETRY')"
                    : "('QUEUED','RETRY','WAITING_PLAYER')";
            String sql = "SELECT transaction_uuid,player_uuid,product_id,state,attempts FROM shop_deliveries "
                    + "WHERE state IN " + states
                    + (playerId == null ? "" : " AND player_uuid=?")
                    + " ORDER BY created_at LIMIT ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                int index = 1;
                if (playerId != null) statement.setString(index++, playerId.toString());
                statement.setInt(index, Math.max(1, limit));
                try (ResultSet rows = statement.executeQuery()) {
                    while (rows.next()) result.add(readRow(rows));
                }
            }
            return List.copyOf(result);
        });
    }

    private CompletableFuture<Boolean> claim(UUID transactionId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE shop_deliveries SET state='PROCESSING',attempts=attempts+1,last_error=NULL,updated_at=? "
                            + "WHERE transaction_uuid=? AND state IN ('QUEUED','RETRY','WAITING_PLAYER')")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, transactionId.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    private CompletableFuture<Void> mark(UUID transactionId, String state, String error) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE shop_deliveries SET state=?,last_error=?,updated_at=? WHERE transaction_uuid=?")) {
                statement.setString(1, state);
                statement.setString(2, error);
                statement.setLong(3, System.currentTimeMillis());
                statement.setString(4, transactionId.toString());
                statement.executeUpdate();
            }
            return null;
        });
    }


    private CompletableFuture<Void> retryOrReview(DeliveryRow row, String reason) {
        int attemptsAfterClaim = row.attempts() + 1;
        if (attemptsAfterClaim >= maxAutomaticAttempts) {
            return mark(row.transactionId(), "REVIEW_REQUIRED",
                    "Automatic delivery attempts exhausted (" + attemptsAfterClaim + "): " + reason);
        }
        return mark(row.transactionId(), "RETRY", reason);
    }

    private CompletableFuture<Void> quarantineInterrupted() {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE shop_deliveries SET state='REVIEW_REQUIRED',"
                            + "last_error=COALESCE(last_error,'Server stopped during external delivery; verify before retrying'),updated_at=? "
                            + "WHERE state='PROCESSING'")) {
                statement.setLong(1, System.currentTimeMillis());
                int changed = statement.executeUpdate();
                if (changed > 0) {
                    plugin.getLogger().severe(changed + " ExcellentShop delivery/deliveries require manual review after an interrupted external call.");
                }
            }
            return null;
        });
    }

    private CompletableFuture<Boolean> transition(UUID id, String from, String to, String message) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE shop_deliveries SET state=?,last_error=?,updated_at=? WHERE transaction_uuid=? AND state=?")) {
                statement.setString(1, to);
                statement.setString(2, message);
                statement.setLong(3, System.currentTimeMillis());
                statement.setString(4, id.toString());
                statement.setString(5, from);
                return statement.executeUpdate() == 1;
            }
        });
    }

    private String validate(Product product) {
        return switch (product.type()) {
            case EXCELLENTCRATES_KEY -> product.keyId() == null || product.keyId().isBlank()
                    ? "key-id is missing" : crates == null ? "ExcellentCrates integration is unavailable"
                    : !crates.hasKey(product.keyId()) ? "ExcellentCrates key does not exist: " + product.keyId() : null;
            case LUCKPERMS_GROUP -> product.group() == null || product.group().isBlank()
                    ? "group is missing" : luckPerms == null ? "LuckPerms integration is unavailable"
                    : !luckPerms.groupExists(product.group()) ? "LuckPerms group does not exist: " + product.group() : null;
            case TAG -> product.tagId() == null || product.tagId().isBlank()
                    ? "tag-id is missing" : !plugin.tagService().definitionIds().contains(product.tagId())
                    ? "tag definition does not exist: " + product.tagId() : null;
            case COSMETIC -> product.cosmeticId() == null || product.cosmeticId().isBlank()
                    ? "cosmetic-id is missing" : !plugin.cosmeticService().ids().contains(product.cosmeticId())
                    ? "cosmetic definition does not exist: " + product.cosmeticId() : null;
            case ULTIMATECLAIMS_BLOCKS -> claims == null ? "UltimateClaims API integration is unavailable" : null;
        };
    }

    private static DeliveryRow readRow(ResultSet result) throws Exception {
        return new DeliveryRow(
                UUID.fromString(result.getString("transaction_uuid")),
                UUID.fromString(result.getString("player_uuid")),
                result.getString("product_id"),
                result.getString("state"),
                result.getInt("attempts"));
    }

    private static String safeMessage(Throwable error) {
        if (error == null) return "Unknown delivery error";
        String message = error.getMessage();
        if (message == null || message.isBlank()) message = error.getClass().getSimpleName();
        return message.length() > 500 ? message.substring(0, 500) : message;
    }

    private static String jsonEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private enum ProductType {
        EXCELLENTCRATES_KEY(false),
        LUCKPERMS_GROUP(true),
        TAG(true),
        COSMETIC(true),
        ULTIMATECLAIMS_BLOCKS(false);

        private final boolean automaticRetrySafe;

        ProductType(boolean automaticRetrySafe) {
            this.automaticRetrySafe = automaticRetrySafe;
        }

        boolean automaticRetrySafe() {
            return automaticRetrySafe;
        }
    }

    private enum Outcome { DELIVERED, WAITING_FOR_PLAYER, REJECTED }

    private record Product(String id, ProductType type, String keyId, String tagId,
                           String cosmeticId, String group, int amount) {}

    private record DeliveryRow(UUID transactionId, UUID playerId, String productId, String state, int attempts) {}

    public record DeliveryResult(boolean success, String message, UUID transactionId) {
        private static DeliveryResult failure(String message) {
            return new DeliveryResult(false, message, null);
        }
    }

    public record ReviewEntry(UUID transactionId, UUID playerId, String productId,
                              int attempts, String lastError, long createdAt) {}
}
