package dev.crimsonprogression.boss;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.core.FightState;
import dev.crimsonprogression.core.RewardCalculator;
import dev.crimsonprogression.delivery.PendingDeliveryService;
import dev.crimsonprogression.integration.MythicMobsHook;
import dev.crimsonprogression.token.TokenPayoutService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

public final class BossManager {
    private static final int MAX_CHUNK_RADIUS = 4;
    private static final long MAX_COOLDOWN_SECONDS = 31_536_000L;

    private final CrimsonProgressionPlugin plugin;
    private final FightRepository repository;
    private final EscrowRepository escrow;
    private final PendingDeliveryService pending;
    private final MythicMobsHook mythic;
    private final SummonerService summoners;
    private final TokenPayoutService payouts;
    private volatile Map<Integer, Integer> rewardTable;
    private final AtomicBoolean transition = new AtomicBoolean();
    private final AtomicBoolean renderFailureLogged = new AtomicBoolean();
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    private volatile ActiveFight active;
    private volatile boolean recoveryBlocked;
    private volatile long cooldownUntil;
    private volatile net.kyori.adventure.bossbar.BossBar bar;
    private BukkitTask barTask;
    private BukkitTask flushTask;
    private BukkitTask finalizationRetryTask;
    private int missingBossUpdates;
    private ActiveFight.ChunkCoordinate lastPersistedBossChunk;

    public BossManager(CrimsonProgressionPlugin plugin, FightRepository repository, EscrowRepository escrow,
                       PendingDeliveryService pending, MythicMobsHook mythic, SummonerService summoners,
                       TokenPayoutService payouts, Map<Integer, Integer> rewardTable) {
        this.plugin = plugin;
        this.repository = repository;
        this.escrow = escrow;
        this.pending = pending;
        this.mythic = mythic;
        this.summoners = summoners;
        this.payouts = payouts;
        this.rewardTable = Map.copyOf(rewardTable);
    }

    public Optional<ActiveFight> active() { return Optional.ofNullable(active); }
    public boolean recoveryBlocked() { return recoveryBlocked; }
    public SummonerService summoners() { return summoners; }

    public boolean isBoss(Entity entity) {
        ActiveFight fight = active;
        if (fight == null || fight.entityId() == null || !fight.entityId().equals(entity.getUniqueId())) return false;
        String id = entity.getPersistentDataContainer().get(plugin.keys().fightId(), PersistentDataType.STRING);
        return fight.fightId().toString().equals(id);
    }

    public boolean recover() {
        if (active != null) {
            plugin.getLogger().warning("Boss recovery was requested while a fight is already active.");
            return false;
        }
        if (!transition.compareAndSet(false, true)) {
            plugin.getLogger().warning("Boss recovery was requested while another boss transition was active.");
            return false;
        }
        repository.loadIncomplete(plugin.bossDefinitions()).whenComplete((incomplete, incompleteError) -> {
            if (incompleteError != null) {
                blockRecovery("Could not inspect incomplete pre-spawn fight rows", incompleteError);
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> incomplete.ifPresentOrElse(
                    this::recoverIncompleteMain,
                    this::continueActiveRecovery));
        });
        return true;
    }

    private void continueActiveRecovery() {
        repository.loadCooldown().whenComplete((cooldown, cooldownError) -> {
            if (cooldownError != null) {
                blockRecovery("Boss cooldown recovery failed", cooldownError);
                return;
            }
            cooldownUntil = cooldown;
            repository.loadActive(plugin.bossDefinitions()).whenComplete((result, error) -> {
                if (error != null) {
                    blockRecovery("Active fight recovery query failed", error);
                    return;
                }
                Bukkit.getScheduler().runTask(plugin, () -> result.ifPresentOrElse(
                        recovered -> recoverMain(recovered.fight()),
                        this::finishRecovery));
            });
        });
    }

    /**
     * Resolves the unavoidable crash window between spawning a Mythic entity and
     * committing its ACTIVE state. SPAWNING rows have their exact chunk window
     * persisted before the external spawn call, so a marked orphan can be found
     * and removed before the summoner is refunded.
     */
    private void recoverIncompleteMain(ActiveFight fight) {
        if (fight.chunks().isEmpty()) {
            resolveIncompleteEscrow(fight, false);
            return;
        }
        int maximumPersistedChunks = (MAX_CHUNK_RADIUS * 2 + 1) * (MAX_CHUNK_RADIUS * 2 + 1);
        if (fight.chunks().size() > maximumPersistedChunks) {
            blockRecovery("Incomplete fight has an unsafe persisted chunk set: " + fight.fightId(),
                    new IllegalStateException("Persisted chunk count=" + fight.chunks().size()));
            return;
        }
        World world = resolveArenaWorld(fight.world());
        if (world == null) {
            blockRecovery("Cannot inspect an incomplete fight because its arena world is unavailable: "
                    + fight.fightId(), new IllegalStateException(fight.world()));
            return;
        }
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (ActiveFight.ChunkCoordinate chunk : fight.chunks()) {
            loads.add(world.getChunkAtAsync(chunk.x(), chunk.z(), true));
        }
        CompletableFuture.allOf(loads.toArray(CompletableFuture[]::new)).whenComplete((ignored, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        blockRecovery("Could not load chunks for incomplete fight " + fight.fightId(), error);
                        return;
                    }
                    for (ActiveFight.ChunkCoordinate chunk : fight.chunks()) {
                        world.addPluginChunkTicket(chunk.x(), chunk.z(), plugin);
                    }
                    Entity orphan = findFightEntity(world, fight);
                    if (orphan != null) {
                        plugin.getLogger().warning("Removed partially spawned boss entity for incomplete fight "
                                + fight.fightId());
                        orphan.remove();
                    }
                    releaseTickets(fight);
                    resolveIncompleteEscrow(fight, orphan != null);
                }));
    }

    private void resolveIncompleteEscrow(ActiveFight fight, boolean orphanRemoved) {
        escrow.findForFight(fight.fightId()).whenComplete((optional, lookupError) -> {
            if (lookupError != null) {
                blockRecovery("Could not inspect summoner escrow for incomplete fight " + fight.fightId(),
                        lookupError);
                return;
            }
            if (optional.isEmpty()) {
                blockRecovery("Incomplete fight has no summoner escrow: " + fight.fightId(),
                        new IllegalStateException("Missing summoner escrow"));
                return;
            }
            EscrowRepository.Escrow entry = optional.get();
            CompletableFuture<Void> cleanup;
            if ("PENDING_REMOVAL".equals(entry.state())) {
                // The inventory mutation may not have happened. Delete only the
                // singleton fight row; join reconciliation checks the real item
                // before deciding between cancellation and refund.
                cleanup = repository.deleteActive(fight.fightId());
            } else if (Set.of("REMOVED", "CONSUMED", "REFUND_PENDING").contains(entry.state())) {
                cleanup = prepareAndQueueRefund(fight,
                        orphanRemoved ? "partial boss spawn recovered" : "incomplete boss spawn recovered");
            } else if (Set.of("CANCELLED", "REFUNDED", "FORFEITED").contains(entry.state())) {
                cleanup = repository.deleteActive(fight.fightId());
            } else {
                cleanup = CompletableFuture.failedFuture(new IllegalStateException(
                        "Incomplete fight escrow requires manual review: " + entry.id()
                                + " state=" + entry.state()));
            }
            cleanup.whenComplete((ignored, cleanupError) -> {
                if (cleanupError != null) {
                    blockRecovery("Could not resolve incomplete fight " + fight.fightId(), cleanupError);
                    return;
                }
                plugin.getLogger().warning("Resolved incomplete boss fight " + fight.fightId()
                        + " from state " + fight.state() + ".");
                continueActiveRecovery();
            });
        });
    }

    private void finishRecovery() {
        recoveryBlocked = false;
        transition.set(false);
        for (Player player : Bukkit.getOnlinePlayers()) reconcileEscrows(player);
    }

    private void blockRecovery(String message, Throwable error) {
        recoveryBlocked = true;
        transition.set(false);
        plugin.getLogger().log(Level.SEVERE,
                message + "; summons remain disabled until /cp boss recover succeeds", error);
    }

    private void recoverMain(ActiveFight fight) {
        active = fight;
        if (fight.state() == FightState.ENDING) {
            List<RewardCalculator.Reward> rewards = RewardCalculator.calculate(
                    fight.damage().leaderboard(), rewardTable);
            finalizeFight(fight, rewards, 0);
            return;
        }

        World world = resolveArenaWorld(fight.world());
        if (world == null) {
            recoveryFailed(fight, "world is unavailable");
            return;
        }
        int maximumPersistedChunks = (MAX_CHUNK_RADIUS * 2 + 1) * (MAX_CHUNK_RADIUS * 2 + 1);
        if (fight.chunks().size() > maximumPersistedChunks) {
            recoveryFailed(fight, "persisted chunk ticket set exceeds the safety limit");
            return;
        }
        if (fight.chunks().isEmpty()) {
            int radius = configuredChunkRadius();
            int centerX = ((int) Math.floor(fight.x())) >> 4;
            int centerZ = ((int) Math.floor(fight.z())) >> 4;
            for (int x = centerX - radius; x <= centerX + radius; x++) {
                for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                    fight.chunks().add(new ActiveFight.ChunkCoordinate(x, z));
                }
            }
        }
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (var chunk : fight.chunks()) loads.add(world.getChunkAtAsync(chunk.x(), chunk.z(), true));
        World finalWorld = world;
        CompletableFuture.allOf(loads.toArray(CompletableFuture[]::new)).whenComplete((ignored, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        recoveryFailed(fight, "chunk loading failed: " + error.getMessage());
                        return;
                    }
                    for (var chunk : fight.chunks()) finalWorld.addPluginChunkTicket(chunk.x(), chunk.z(), plugin);
                    Entity found = findFightEntity(finalWorld, fight);
                    if (!(found instanceof LivingEntity living)) {
                        recoveryFailed(fight, "stored boss entity not found");
                        return;
                    }
                    fight.entityId(living.getUniqueId());
                    if (fight.maxHealth() <= 0) fight.maxHealth(maxHealth(living));
                    active = fight;
                    startRuntime();
                    finishRecovery();
                }));
    }

    private Entity findFightEntity(World world, ActiveFight fight) {
        UUID storedId = fight.entityId();
        if (storedId != null) {
            Entity byId = Bukkit.getEntity(storedId);
            if (matchesRecoveredEntity(world, fight, byId)) return byId;
        }
        for (var coordinate : fight.chunks()) {
            Chunk chunk = world.getChunkAt(coordinate.x(), coordinate.z());
            for (Entity entity : chunk.getEntities()) {
                if (matchesRecoveredEntity(world, fight, entity)) return entity;
            }
        }
        return null;
    }

    private boolean matchesRecoveredEntity(World world, ActiveFight fight, Entity entity) {
        if (entity == null || entity.isDead() || entity.getWorld() != world) return false;
        String id = entity.getPersistentDataContainer().get(
                plugin.keys().fightId(), PersistentDataType.STRING);
        return fight.fightId().toString().equals(id);
    }

    public void summon(Player player, int slot, ItemStack held) {
        SummonerService.Validation validation = summoners.validate(held);
        if (!validation.valid()) {
            plugin.messages().send(player, "summoner-invalid");
            return;
        }
        if (recoveryBlocked) {
            plugin.messages().send(player, "boss-recovery-blocked");
            return;
        }
        if (active != null || !transition.compareAndSet(false, true)) {
            plugin.messages().send(player, "fight-already-active");
            return;
        }
        long now = System.currentTimeMillis();
        if (cooldownUntil > now) {
            plugin.messages().send(player, "cooldown",
                    Map.of("seconds", String.valueOf((cooldownUntil - now + 999) / 1000)));
            transition.set(false);
            return;
        }

        BossDefinition definition = validation.definition();
        String worldName = plugin.bossConfig().getString("arena.world", "bossarena");
        double spawnX = plugin.bossConfig().getDouble("arena.spawn.x");
        double spawnY = plugin.bossConfig().getDouble("arena.spawn.y");
        double spawnZ = plugin.bossConfig().getDouble("arena.spawn.z");
        float spawnYaw = (float) plugin.bossConfig().getDouble("arena.spawn.yaw");
        float spawnPitch = (float) plugin.bossConfig().getDouble("arena.spawn.pitch");
        String arenaError = validateArenaConfiguration(worldName, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch);
        if (arenaError != null) {
            transition.set(false);
            plugin.getLogger().warning("Boss summon rejected because arena configuration is unsafe: " + arenaError);
            plugin.messages().send(player, "boss-arena-invalid");
            return;
        }
        ActiveFight fight = new ActiveFight(UUID.randomUUID(), definition, player.getUniqueId(),
                worldName, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch,
                now, FightState.ESCROW_PENDING);

        ItemStack escrowItem = held.clone();
        escrowItem.setAmount(1);
        escrow.createWithFight(fight, player.getUniqueId(), definition.summonerId(),
                        validation.nonce(), slot, escrowItem)
                .whenComplete((optional, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        transition.set(false);
                        plugin.fail(player, "escrow-create", error);
                        return;
                    }
                    if (optional.isEmpty()) {
                        transition.set(false);
                        plugin.messages().send(player, "summoner-already-used");
                        return;
                    }
                    UUID escrowId = optional.get();
                    ItemStack current = player.getInventory().getItem(slot);
                    if (!summoners.sameIdentity(current, validation)) {
                        escrow.cancelIntact(fight.fightId(), escrowId).whenComplete((ignored, cancelError) ->
                                Bukkit.getScheduler().runTask(plugin, () -> {
                                    transition.set(false);
                                    if (cancelError != null) plugin.getLogger().log(Level.SEVERE,
                                            "Could not atomically cancel intact summoner escrow " + escrowId,
                                            cancelError);
                                    plugin.messages().send(player, "summoner-invalid");
                                }));
                        return;
                    }
                    ItemStack reduced = current.clone();
                    reduced.setAmount(current.getAmount() - 1);
                    player.getInventory().setItem(slot, reduced.getAmount() <= 0 ? null : reduced);
                    escrow.markRemoved(escrowId).whenComplete((ignored, markError) ->
                            Bukkit.getScheduler().runTask(plugin, () -> {
                                if (markError != null) {
                                    prepareAndQueueRefund(fight, "escrow state could not be persisted")
                                            .whenComplete((refundIgnored, refundError) ->
                                                    Bukkit.getScheduler().runTask(plugin, () -> {
                                                        recoveryBlocked = refundError != null;
                                                        transition.set(false);
                                                        if (refundError != null) plugin.getLogger().log(Level.SEVERE,
                                                                "Could not recover escrow after removal-state failure "
                                                                        + escrowId, refundError);
                                                        plugin.fail(player, "escrow-remove-state", markError);
                                                    }));
                                    return;
                                }
                                loadAndSpawn(player, fight, escrowId);
                            }));
                }));
    }

    private void loadAndSpawn(Player player, ActiveFight fight, UUID escrowId) {
        World world = resolveArenaWorld(fight.world());
        if (world == null) {
            failSpawn(player, fight, "arena world is unavailable", null);
            return;
        }

        int radius = configuredChunkRadius();
        int centerX = ((int) Math.floor(fight.x())) >> 4;
        int centerZ = ((int) Math.floor(fight.z())) >> 4;
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (int x = centerX - radius; x <= centerX + radius; x++) {
            for (int z = centerZ - radius; z <= centerZ + radius; z++) {
                fight.chunks().add(new ActiveFight.ChunkCoordinate(x, z));
                loads.add(world.getChunkAtAsync(x, z, true));
            }
        }

        World finalWorld = world;
        CompletableFuture.allOf(loads.toArray(CompletableFuture[]::new)).whenComplete((ignored, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) {
                        failSpawn(player, fight, "chunk load failed", error);
                        return;
                    }
                    for (var chunk : fight.chunks()) finalWorld.addPluginChunkTicket(chunk.x(), chunk.z(), plugin);
                    Location location = new Location(finalWorld, fight.x(), fight.y(), fight.z(), fight.yaw(), fight.pitch());
                    String spawnError = validateLoadedSpawn(location);
                    if (spawnError != null) {
                        failSpawn(player, fight,
                                "unsafe arena spawn: " + spawnError, null);
                        return;
                    }
                    fight.state(FightState.SPAWNING);
                    repository.markSpawning(fight).whenComplete((unused, prepareError) ->
                            Bukkit.getScheduler().runTask(plugin, () -> {
                                if (prepareError != null) {
                                    failSpawn(player, fight,
                                            "could not persist pre-spawn recovery state", prepareError);
                                    return;
                                }
                                spawnPreparedBoss(player, fight, escrowId, location);
                            }));
                }));
    }

    private void spawnPreparedBoss(Player player, ActiveFight fight, UUID escrowId, Location location) {
        Optional<Entity> spawned;
        try {
            spawned = mythic.spawn(fight.definition().mythicMobId(), location);
        } catch (RuntimeException | LinkageError error) {
            failSpawn(player, fight, "MythicMobs spawn call failed", error);
            return;
        }
        if (spawned.isEmpty() || !(spawned.get() instanceof LivingEntity living)) {
            failSpawn(player, fight, "MythicMobs API returned no living entity", null);
            return;
        }
        Entity entity = spawned.get();
        entity.getPersistentDataContainer().set(plugin.keys().fightId(), PersistentDataType.STRING,
                fight.fightId().toString());
        fight.entityId(entity.getUniqueId());
        fight.maxHealth(maxHealth(living));
        fight.state(FightState.ACTIVE);

        // Expose the just-spawned entity to combat listeners while the durable
        // ACTIVE commit is queued. transition remains locked, so no second fight
        // can start. A failed commit removes the entity and clears this reference.
        active = fight;
        long cooldownSeconds = Math.max(0L, Math.min(MAX_COOLDOWN_SECONDS,
                plugin.bossConfig().getLong("arena.global-cooldown-seconds", 900L)));
        long cooldown = System.currentTimeMillis() + cooldownSeconds * 1000L;
        repository.markSpawned(fight, cooldown, escrowId).whenComplete((unused, dbError) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (dbError != null) {
                        entity.remove();
                        active = null;
                        failSpawn(player, fight, "could not persist spawned boss", dbError);
                        return;
                    }
                    cooldownUntil = cooldown;
                    transition.set(false);
                    startRuntime();
                    plugin.discord().bossStarted(fight.definition().displayName(), player.getName());
                    announceStart(fight, player);
                }));
    }

    private void failSpawn(Player player, ActiveFight fight, String reason, Throwable error) {
        releaseTickets(fight);
        prepareAndQueueRefund(fight, reason).whenComplete((ignored, refundError) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    recoveryBlocked = refundError != null;
                    transition.set(false);
                    if (refundError != null) {
                        plugin.getLogger().log(Level.SEVERE,
                                "Boss spawn failed and its summoner refund requires intervention ["
                                        + fight.fightId() + "] " + reason, refundError);
                    } else if (player.isOnline()) {
                        plugin.messages().send(player, "summoner-refunded");
                    }
                }));
        if (error == null) plugin.getLogger().severe("Boss spawn failed [" + fight.fightId() + "] " + reason);
        else plugin.getLogger().log(Level.SEVERE,
                "Boss spawn failed [" + fight.fightId() + "] " + reason, error);
    }

    public void recordDamage(Player player, double finalDamage, double healthBefore) {
        ActiveFight fight = active;
        if (fight == null || !Double.isFinite(finalDamage) || !Double.isFinite(healthBefore)) return;
        fight.damage().record(player.getUniqueId(), player.getName(), Math.max(0.0D, finalDamage),
                Math.max(0.0D, healthBefore), System.currentTimeMillis());
    }

    public void markKiller(Player player) {
        ActiveFight fight = active;
        if (fight == null) return;
        fight.killingBlow(player.getUniqueId());
        fight.damage().markKillingBlow(player.getUniqueId());
    }

    public void defeated(LivingEntity boss) {
        ActiveFight fight = active;
        if (fight == null || !isBoss(boss) || !transition.compareAndSet(false, true)) return;
        fight.state(FightState.ENDING);
        List<RewardCalculator.Reward> rewards = RewardCalculator.calculate(fight.damage().leaderboard(), rewardTable);
        finalizeFight(fight, rewards, 0);
    }

    private void finalizeFight(ActiveFight fight, List<RewardCalculator.Reward> rewards, int attempt) {
        repository.completeWithPayouts(fight, rewards, "COMPLETED").whenComplete((ignored, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (active != fight) return;
                    if (error != null) {
                        int nextAttempt = attempt + 1;
                        long delay = Math.max(20L, plugin.bossConfig().getLong("finalization.retry-delay-ticks", 100L));
                        plugin.getLogger().log(Level.SEVERE,
                                "Fight finalization failed for " + fight.fightId() + " (attempt " + nextAttempt
                                        + "). The fight remains locked and will retry; no payout is discarded.", error);
                        if (finalizationRetryTask != null) finalizationRetryTask.cancel();
                        finalizationRetryTask = Bukkit.getScheduler().runTaskLater(plugin,
                                () -> finalizeFight(fight, rewards, nextAttempt), delay);
                        return;
                    }
                    if (finalizationRetryTask != null) finalizationRetryTask.cancel();
                    finalizationRetryTask = null;
                    announceDefeat(fight, rewards);
                    for (RewardCalculator.Reward reward : rewards) {
                        Player online = Bukkit.getPlayer(reward.playerId());
                        if (online != null && online.isOnline()) plugin.cosmeticService().bossVictory(online);
                    }
                    stopRuntime(fight);
                    active = null;
                    transition.set(false);
                    repository.deleteActive(fight.fightId()).exceptionally(deleteError -> {
                        plugin.getLogger().log(Level.WARNING,
                                "Completed fight row could not be removed immediately; startup cleanup will remove it.",
                                deleteError);
                        return null;
                    });
                    payouts.processPending();
                }));
    }

    public void reset(boolean refund) {
        ActiveFight fight = active;
        if (fight == null || !transition.compareAndSet(false, true)) return;
        if (fight.entityId() != null) {
            Entity entity = Bukkit.getEntity(fight.entityId());
            if (entity != null) entity.remove();
        }
        stopRuntime(fight);
        active = null;
        CompletableFuture<Void> cleanup = refund
                ? prepareAndQueueRefund(fight, "administrative reset")
                : escrow.forfeitForFight(fight.fightId());
        cleanup.whenComplete((ignored, cleanupError) -> Bukkit.getScheduler().runTask(plugin, () -> {
            recoveryBlocked = cleanupError != null;
            transition.set(false);
            if (cleanupError != null) plugin.getLogger().log(Level.SEVERE,
                    "Boss reset persistence cleanup failed for " + fight.fightId(), cleanupError);
        }));
    }

    private void announceStart(ActiveFight fight, Player summoner) {
        List<String> lines = plugin.bossConfig().getStringList("start-announcement");
        if (lines.isEmpty()) {
            lines = List.of(
                    "<dark_red><bold>Boss Fight Started</bold></dark_red>",
                    "<red><boss></red> <gray>was summoned by</gray> <white><player></white><gray>.</gray>",
                    "<gray>Use <white>/warp bossfight</white> to participate.</gray>");
        }
        Map<String, String> values = Map.of(
                "boss", fight.definition().displayName(),
                "player", summoner.getName(),
                "warp", plugin.bossConfig().getString("arena.warp-command-display", "/warp bossfight"));
        for (String line : lines) Bukkit.broadcast(render(line, values));
    }

    private void announceDefeat(ActiveFight fight, List<RewardCalculator.Reward> rewards) {
        String killer = "Unknown";
        if (fight.killingBlow() != null) {
            for (var entry : fight.damage().leaderboard()) {
                if (entry.playerId().equals(fight.killingBlow())) {
                    killer = entry.lastKnownName();
                    break;
                }
            }
        }
        List<String> header = plugin.bossConfig().getStringList("death-announcement.header");
        if (header.isEmpty()) header = List.of(
                "<dark_red><bold><boss> Defeated</bold></dark_red>",
                "<gray>Killing blow:</gray> <white><killer></white>");
        Map<String, String> base = Map.of("boss", fight.definition().displayName(), "killer", killer);
        for (String line : header) Bukkit.broadcast(render(line, base));

        String placementFormat = plugin.bossConfig().getString("death-announcement.placement-format",
                "<gray>#<placement></gray> <white><player></white> <dark_gray>—</dark_gray> "
                        + "<yellow><damage> damage</yellow> <dark_gray>—</dark_gray> <gold><tokens> Tokens</gold>");
        int maximum = Math.max(1, plugin.bossConfig().getInt("death-announcement.maximum-placements", 5));
        for (RewardCalculator.Reward reward : rewards.stream().limit(maximum).toList()) {
            Bukkit.broadcast(render(placementFormat, Map.of(
                    "placement", Integer.toString(reward.placement()),
                    "player", reward.name(),
                    "damage", String.format(Locale.US, "%.2f", reward.damage()),
                    "tokens", Integer.toString(reward.tokens()))));
        }
    }

    private void startRuntime() {
        ActiveFight fight = active;
        if (fight == null) return;
        if (barTask != null) barTask.cancel();
        if (flushTask != null) flushTask.cancel();
        missingBossUpdates = 0;
        lastPersistedBossChunk = null;
        bar = net.kyori.adventure.bossbar.BossBar.bossBar(
                bossBarTitle(fight, fight.maxHealth()), 1.0F, bossBarColor(), bossBarOverlay());
        for (Player player : Bukkit.getOnlinePlayers()) player.showBossBar(bar);
        restartBarTask();
        flushTask = Bukkit.getScheduler().runTaskTimer(plugin,
                () -> repository.saveDamage(fight).exceptionally(error -> {
                    plugin.getLogger().log(Level.WARNING, "Periodic fight damage flush failed", error);
                    return null;
                }), 100, 100);
    }

    private void updateBar() {
        ActiveFight fight = active;
        if (fight == null || bar == null) return;
        Entity entity = fight.entityId() == null ? null : Bukkit.getEntity(fight.entityId());
        if (entity instanceof LivingEntity living) {
            missingBossUpdates = 0;
            if (living.isDead()) {
                defeated(living);
                return;
            }
            if (!living.getWorld().getName().equals(fight.world())) {
                living.remove();
                if (transition.compareAndSet(false, true)) {
                    recoveryFailed(fight, "active boss left the configured arena world");
                }
                return;
            }
            refreshChunkTickets(fight, living);
            double rawHealth = living.getHealth();
            double health = Double.isFinite(rawHealth) ? Math.max(0, rawHealth) : 0.0D;
            bar.progress((float) Math.max(0, Math.min(1, health / Math.max(1, fight.maxHealth()))));
            bar.name(bossBarTitle(fight, health));
            return;
        }

        int threshold = Math.max(2, Math.min(120,
                plugin.bossConfig().getInt("recovery.missing-entity-update-threshold", 6)));
        if (++missingBossUpdates >= threshold && transition.compareAndSet(false, true)) {
            recoveryFailed(fight, "active boss entity disappeared");
        }
    }

    public void addPlayer(Player player) {
        ActiveFight fight = active;
        if (fight == null) return;
        if (bar != null) player.showBossBar(bar);
        plugin.messages().sendLines(player, plugin.bossConfig().getStringList("join-message"),
                Map.of("boss", fight.definition().displayName(), "health", currentHealth(),
                        "max_health", String.format(Locale.US, "%.0f", fight.maxHealth())));
    }

    public String currentHealth() {
        ActiveFight fight = active;
        if (fight == null) return "0";
        Entity entity = fight.entityId() == null ? null : Bukkit.getEntity(fight.entityId());
        if (!(entity instanceof LivingEntity living)) return "0";
        double health = living.getHealth();
        return Double.isFinite(health) ? String.format(Locale.US, "%.0f", Math.max(0.0D, health)) : "0";
    }

    private void stopRuntime(ActiveFight fight) {
        if (barTask != null) barTask.cancel();
        if (flushTask != null) flushTask.cancel();
        barTask = null;
        flushTask = null;
        if (bar != null) {
            for (Player player : Bukkit.getOnlinePlayers()) player.hideBossBar(bar);
        }
        bar = null;
        lastPersistedBossChunk = null;
        releaseTickets(fight);
    }

    /** Keeps a bounded ticket window centred on the boss and persists it for restart recovery. */
    private void refreshChunkTickets(ActiveFight fight, LivingEntity living) {
        Chunk current = living.getLocation().getChunk();
        ActiveFight.ChunkCoordinate currentCoordinate =
                new ActiveFight.ChunkCoordinate(current.getX(), current.getZ());
        if (currentCoordinate.equals(lastPersistedBossChunk)) return;

        int radius = configuredChunkRadius();
        Set<ActiveFight.ChunkCoordinate> desired = new LinkedHashSet<>();
        for (int x = current.getX() - radius; x <= current.getX() + radius; x++) {
            for (int z = current.getZ() - radius; z <= current.getZ() + radius; z++) {
                desired.add(new ActiveFight.ChunkCoordinate(x, z));
            }
        }

        World world = living.getWorld();
        for (ActiveFight.ChunkCoordinate coordinate : desired) {
            if (!fight.chunks().contains(coordinate)) {
                world.addPluginChunkTicket(coordinate.x(), coordinate.z(), plugin);
            }
        }
        for (ActiveFight.ChunkCoordinate coordinate : List.copyOf(fight.chunks())) {
            if (!desired.contains(coordinate)) {
                world.removePluginChunkTicket(coordinate.x(), coordinate.z(), plugin);
            }
        }
        fight.chunks().clear();
        fight.chunks().addAll(desired);
        lastPersistedBossChunk = currentCoordinate;

        Location location = living.getLocation();
        repository.saveRuntimePositionAndChunks(
                        fight,
                        location.getX(), location.getY(), location.getZ(),
                        location.getYaw(), location.getPitch(), desired)
                .exceptionally(error -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Could not persist the boss's current recovery chunks for " + fight.fightId(), error);
                    return null;
                });
    }

    private void releaseTickets(ActiveFight fight) {
        World world = Bukkit.getWorld(fight.world());
        if (world != null) {
            for (var chunk : fight.chunks()) world.removePluginChunkTicket(chunk.x(), chunk.z(), plugin);
        }
    }

    private int configuredChunkRadius() {
        return Math.max(0, Math.min(MAX_CHUNK_RADIUS,
                plugin.bossConfig().getInt("arena.chunk-radius", 1)));
    }

    private void recoveryFailed(ActiveFight fight, String reason) {
        plugin.getLogger().severe("Fight recovery failed [" + fight.fightId() + "] " + reason);
        stopRuntime(fight);
        active = null;
        prepareAndQueueRefund(fight, reason).whenComplete((ignored, refundError) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    recoveryBlocked = refundError != null;
                    transition.set(false);
                    if (refundError != null) plugin.getLogger().log(Level.SEVERE,
                            "Recovered fight could not queue its summoner refund " + fight.fightId(), refundError);
                }));
    }

    public void reconcileEscrows(Player player) {
        escrow.unresolvedForPlayer(player.getUniqueId()).whenComplete((entries, error) -> {
            if (error != null) {
                plugin.getLogger().log(Level.SEVERE,
                        "Could not load unresolved summoner escrows for " + player.getUniqueId(), error);
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                for (EscrowRepository.Escrow entry : entries) {
                    if ("PENDING_REMOVAL".equals(entry.state()) && containsEscrowItem(player, entry)) {
                        escrow.cancelIntact(entry.fightId(), entry.id()).exceptionally(cancelError -> {
                            plugin.getLogger().log(Level.SEVERE,
                                    "Could not atomically cancel intact escrow " + entry.id(), cancelError);
                            return null;
                        });
                        continue;
                    }
                    escrow.prepareRefundForFight(entry.fightId())
                            .thenCompose(prepared -> prepared.map(value -> queueEscrowRefund(value, "join recovery"))
                                    .orElseGet(() -> CompletableFuture.failedFuture(
                                            new IllegalStateException("Escrow disappeared during recovery: " + entry.id()))))
                            .exceptionally(refundError -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Could not recover summoner escrow " + entry.id(), refundError);
                                return null;
                            });
                }
                if (!entries.isEmpty()) pending.deliverOnJoin(player);
            });
        });
    }

    private boolean containsEscrowItem(Player player, EscrowRepository.Escrow entry) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null || item.getType().isAir()) continue;
            try {
                if (entry.fingerprint().equals(summoners.fingerprint(item))) return true;
            } catch (RuntimeException ignored) {
                // Invalid inventory data is ignored; the escrow remains recoverable and is never consumed here.
            }
        }
        return false;
    }

    public void shutdown() {
        if (finalizationRetryTask != null) finalizationRetryTask.cancel();
        finalizationRetryTask = null;
        ActiveFight fight = active;
        if (fight != null) {
            repository.saveDamage(fight).exceptionally(error -> {
                plugin.getLogger().log(Level.SEVERE, "Final fight damage flush failed", error);
                return null;
            });
            stopRuntime(fight);
        }
    }

    private CompletableFuture<Void> prepareAndQueueRefund(ActiveFight fight, String reason) {
        return escrow.prepareRefundForFight(fight.fightId()).thenCompose(optional -> optional
                .map(entry -> queueEscrowRefund(entry, reason))
                .orElseGet(() -> CompletableFuture.failedFuture(
                        new IllegalStateException("No summoner escrow exists for fight " + fight.fightId()))));
    }

    private CompletableFuture<Void> queueEscrowRefund(EscrowRepository.Escrow entry, String reason) {
        return pending.queueItem(entry.id(), entry.player(), entry.item(), "SUMMONER_REFUND")
                .thenCompose(ignored -> escrow.completeRefund(entry.id()))
                .whenComplete((ignored, refundError) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (refundError != null) {
                        plugin.getLogger().log(Level.SEVERE,
                                "Could not persist summoner refund " + entry.id() + " after " + reason,
                                refundError);
                        return;
                    }
                    Player online = Bukkit.getPlayer(entry.player());
                    if (online != null && online.isOnline()) pending.deliverOnJoin(online);
                }));
    }

    public void reload(Map<Integer, Integer> rewards,
                       Map<String, BossDefinition> definitions,
                       boolean legacyEnabled,
                       boolean requireExactLegacyMatch,
                       boolean allowNameLoreFallback) {
        rewardTable = Map.copyOf(rewards);
        renderFailureLogged.set(false);
        summoners.reload(definitions, legacyEnabled, requireExactLegacyMatch, allowNameLoreFallback);
        ActiveFight fight = active;
        if (fight != null && bar != null) {
            bar.name(bossBarTitle(fight, currentHealthValue()));
            bar.color(bossBarColor());
            bar.overlay(bossBarOverlay());
            restartBarTask();
        }
    }

    private void restartBarTask() {
        if (barTask != null) barTask.cancel();
        barTask = null;
        if (active == null || bar == null) return;
        barTask = Bukkit.getScheduler().runTaskTimer(plugin, this::updateBar, 1L,
                Math.max(1L, plugin.bossConfig().getLong("bossbar.update-ticks", 10L)));
    }

    private World resolveArenaWorld(String worldName) {
        World world = Bukkit.getWorld(worldName);
        if (world != null) return world;
        if (!plugin.bossConfig().getBoolean("arena.create-world-if-missing", false)) return null;
        return Bukkit.createWorld(new WorldCreator(worldName));
    }

    private String validateArenaConfiguration(String worldName, double x, double y, double z,
                                              float yaw, float pitch) {
        if (worldName == null || worldName.isBlank()) return "arena.world is blank";
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)
                || !Float.isFinite(yaw) || !Float.isFinite(pitch)) {
            return "spawn coordinates contain a non-finite value";
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return plugin.bossConfig().getBoolean("arena.create-world-if-missing", false)
                    ? null : "arena world is not loaded and automatic creation is disabled";
        }
        if (y < world.getMinHeight() + 1.0D || y >= world.getMaxHeight() - 1.0D) {
            return "spawn Y is outside the usable world height";
        }
        return null;
    }

    private String validateLoadedSpawn(Location location) {
        World world = location.getWorld();
        if (world == null) return "world is unavailable";
        if (location.getY() < world.getMinHeight() + 1.0D
                || location.getY() >= world.getMaxHeight() - 1.0D) {
            return "Y is outside the usable world height";
        }
        if (plugin.bossConfig().getBoolean("arena.spawn-safety.require-passable-body", true)) {
            if (!location.getBlock().isPassable()
                    || !location.clone().add(0.0D, 1.0D, 0.0D).getBlock().isPassable()) {
                return "feet or head block is not passable";
            }
        }
        if (plugin.bossConfig().getBoolean("arena.spawn-safety.require-solid-floor", true)
                && !location.clone().subtract(0.0D, 1.0D, 0.0D).getBlock().getType().isSolid()) {
            return "block below the spawn is not solid";
        }
        return null;
    }

    private double currentHealthValue() {
        ActiveFight fight = active;
        if (fight == null || fight.entityId() == null) return 0.0D;
        Entity entity = Bukkit.getEntity(fight.entityId());
        if (!(entity instanceof LivingEntity living)) return 0.0D;
        double health = living.getHealth();
        return Double.isFinite(health) ? Math.max(0.0D, health) : 0.0D;
    }

    private Component bossBarTitle(ActiveFight fight, double health) {
        String template = plugin.bossConfig().getString("bossbar.title",
                "<red><bold><boss></bold></red> <gray>—</gray> <white><health>/<max_health></white>");
        return render(template, Map.of(
                "boss", fight.definition().displayName(),
                "health", String.format(Locale.US, "%.0f", Math.max(0, health)),
                "max_health", String.format(Locale.US, "%.0f", fight.maxHealth())));
    }

    private net.kyori.adventure.bossbar.BossBar.Color bossBarColor() {
        String configured = plugin.bossConfig().getString("bossbar.color", "RED");
        try {
            return net.kyori.adventure.bossbar.BossBar.Color.valueOf(configured.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            plugin.getLogger().warning("Invalid bossbar.color '" + configured + "'; using RED.");
            return net.kyori.adventure.bossbar.BossBar.Color.RED;
        }
    }

    private net.kyori.adventure.bossbar.BossBar.Overlay bossBarOverlay() {
        String configured = plugin.bossConfig().getString("bossbar.style", "NOTCHED_10")
                .toUpperCase(Locale.ROOT).replace("SEGMENTED_", "NOTCHED_");
        try {
            return net.kyori.adventure.bossbar.BossBar.Overlay.valueOf(configured);
        } catch (IllegalArgumentException exception) {
            plugin.getLogger().warning("Invalid bossbar.style '" + configured + "'; using NOTCHED_10.");
            return net.kyori.adventure.bossbar.BossBar.Overlay.NOTCHED_10;
        }
    }

    private Component render(String template, Map<String, String> values) {
        String rendered = template == null ? "" : template;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            rendered = rendered.replace("<" + entry.getKey() + ">", escape(entry.getValue()));
        }
        try {
            return miniMessage.deserialize(rendered);
        } catch (RuntimeException exception) {
            if (renderFailureLogged.compareAndSet(false, true)) {
                plugin.getLogger().log(Level.WARNING,
                        "Invalid MiniMessage text in bosses.yml; plain text fallback is active until reload.",
                        exception);
            }
            return Component.text(rendered.replaceAll("<[^>]*>", ""));
        }
    }

    private static double maxHealth(LivingEntity entity) {
        AttributeInstance attribute = entity.getAttribute(Attribute.MAX_HEALTH);
        double value = attribute == null ? entity.getHealth() : attribute.getValue();
        return Double.isFinite(value) ? Math.max(1.0D, value) : 1.0D;
    }

    private static String escape(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("<", "\\<");
    }
}
