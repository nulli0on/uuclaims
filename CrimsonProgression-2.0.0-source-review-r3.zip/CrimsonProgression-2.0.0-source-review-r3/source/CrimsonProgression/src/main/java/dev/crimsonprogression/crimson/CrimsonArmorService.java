package dev.crimsonprogression.crimson;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Creates and validates the four signed Crimson armor pieces.
 *
 * <p>The enchantment component is hidden because Bukkit/Minecraft cannot hide
 * individual enchantment tooltip lines. Normal enchantments are therefore
 * rendered manually from configuration while the two curses remain mechanically
 * attached but absent from the visible lore.</p>
 */
public final class CrimsonArmorService {
    private static final List<String> PIECE_IDS = List.of("helmet", "chestplate", "leggings", "boots");

    private final CrimsonProgressionPlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final Set<String> missingEnchantWarnings = ConcurrentHashMap.newKeySet();

    private volatile Map<String, PieceDefinition> pieces = Map.of();
    private volatile int schemaVersion = 1;
    private volatile TrimMaterial trimMaterial = TrimMaterial.REDSTONE;
    private volatile TrimPattern trimPattern = TrimPattern.SILENCE;
    private volatile List<String> commonLore = List.of();
    private volatile List<String> enchantLoreFormat = List.of("<gray><enchantment> <level></gray>");
    private volatile List<EnchantDefinition> hiddenEnchantments = List.of();
    private volatile boolean manualEnchantmentLore = true;

    public CrimsonArmorService(CrimsonProgressionPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        YamlConfiguration config = plugin.crimsonConfig();
        this.schemaVersion = Math.max(1, config.getInt("identity.schema-version", 1));
        this.manualEnchantmentLore = config.getBoolean("manual-enchantment-lore", true);
        this.trimMaterial = resolveTrimMaterial(config.getString("trim.material", "REDSTONE"));
        this.trimPattern = resolveTrimPattern(config.getString("trim.pattern", "SILENCE"));

        List<String> configuredLore = config.getStringList("presentation.lore");
        if (configuredLore.isEmpty()) {
            configuredLore = List.of(
                    "<gold><bold>✦ LEGENDARY ITEM ✦</bold></gold>",
                    "",
                    "<color:#AA55FF><bold>CRIMSON ARMOR</bold></color>",
                    "<gray>◆ Full set: <white>+20% damage to the active boss</white></gray>",
                    "<gray>◆ Full set: <white>10% lifesteal from the active boss</white></gray>",
                    "<gray>◆ Full set: <white>Speed and Fire Resistance</white></gray>",
                    "<gray>◆ Full set: <white>Immune to Wither</white></gray>",
                    ""
            );
        }
        this.commonLore = List.copyOf(configuredLore);

        List<String> configuredEnchantFormat = config.getStringList("presentation.enchantment-lore-format");
        this.enchantLoreFormat = configuredEnchantFormat.isEmpty()
                ? List.of("<gray><enchantment> <level></gray>")
                : List.copyOf(configuredEnchantFormat);

        List<EnchantDefinition> hidden = new ArrayList<>();
        for (String raw : config.getStringList("hidden-enchantments")) {
            EnchantDefinition parsed = parseEnchant(raw, 1);
            if (parsed != null) hidden.add(parsed);
        }
        this.hiddenEnchantments = List.copyOf(hidden);

        Map<String, PieceDefinition> loaded = new LinkedHashMap<>();
        for (String id : PIECE_IDS) {
            String path = "pieces." + id;
            Material material = Material.matchMaterial(config.getString(path + ".material", defaultMaterial(id).name()));
            if (material == null) {
                plugin.getLogger().severe("Invalid Crimson armor material at " + path + ".material; using " + defaultMaterial(id));
                material = defaultMaterial(id);
            }
            String name = config.getString(path + ".name", defaultName(id));
            List<EnchantDefinition> enchants = readEnchantments(config, path + ".enchantments", defaultEnchantments(id));
            List<String> pieceLore = config.getStringList(path + ".additional-lore");
            loaded.put(id, new PieceDefinition(id, material, name, enchants, List.copyOf(pieceLore)));
        }
        this.pieces = Map.copyOf(loaded);
    }

    public Optional<ItemStack> create(String id) {
        PieceDefinition piece = pieces.get(normalize(id));
        if (piece == null) return Optional.empty();

        ItemStack item = new ItemStack(piece.material());
        ItemMeta rawMeta = item.getItemMeta();
        if (!(rawMeta instanceof ArmorMeta meta)) {
            plugin.getLogger().severe("Configured Crimson piece is not armor: " + piece.id() + " -> " + piece.material());
            return Optional.empty();
        }

        meta.displayName(parse(piece.name()));
        List<Component> lore = new ArrayList<>();
        for (String line : commonLore) lore.add(parse(line));
        for (String line : piece.additionalLore()) lore.add(parse(line));

        for (EnchantDefinition enchant : piece.visibleEnchantments()) {
            addEnchantment(meta, enchant, false);
            if (manualEnchantmentLore) appendEnchantLore(lore, enchant);
        }
        for (EnchantDefinition curse : hiddenEnchantments) {
            addEnchantment(meta, curse, true);
        }

        List<String> footer = plugin.crimsonConfig().getStringList("presentation.footer-lore");
        if (footer.isEmpty()) footer = List.of("", "<red><bold>⚠ VANISHES WHEN YOU DIE</bold></red>");
        for (String line : footer) lore.add(parse(line));

        meta.lore(lore);
        // Selective hiding is not available. Keep mechanics, hide the component,
        // and render every non-hidden enchantment manually above.
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setTrim(new ArmorTrim(trimMaterial, trimPattern));
        meta.getPersistentDataContainer().set(plugin.keys().crimsonPiece(), PersistentDataType.STRING, piece.id());
        meta.getPersistentDataContainer().set(plugin.keys().crimsonSchema(), PersistentDataType.INTEGER, schemaVersion);
        item.setItemMeta(meta);
        return Optional.of(item);
    }

    public boolean isPiece(ItemStack item, String expectedId) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        String value = meta.getPersistentDataContainer().get(plugin.keys().crimsonPiece(), PersistentDataType.STRING);
        Integer schema = meta.getPersistentDataContainer().get(plugin.keys().crimsonSchema(), PersistentDataType.INTEGER);
        return normalize(expectedId).equals(value) && schema != null && schema == schemaVersion;
    }

    public boolean hasFullSet(Player player) {
        PlayerInventory inventory = player.getInventory();
        return isPiece(inventory.getHelmet(), "helmet")
                && isPiece(inventory.getChestplate(), "chestplate")
                && isPiece(inventory.getLeggings(), "leggings")
                && isPiece(inventory.getBoots(), "boots");
    }

    public void refreshEffects() {
        YamlConfiguration config = plugin.crimsonConfig();
        if (!config.getBoolean("abilities.enabled", true)) return;
        int duration = Math.max(40, config.getInt("abilities.effect-duration-ticks", 80));
        int speed = Math.max(0, config.getInt("abilities.speed-amplifier", 0));
        int fire = Math.max(0, config.getInt("abilities.fire-resistance-amplifier", 0));
        boolean particles = config.getBoolean("abilities.effect-particles", false);
        boolean icon = config.getBoolean("abilities.effect-icon", true);

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!hasFullSet(player)) continue;
            if (config.getBoolean("abilities.speed", true)) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, speed, true, particles, icon));
            }
            if (config.getBoolean("abilities.fire-resistance", true)) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, duration, fire, true, particles, icon));
            }
        }
    }

    public int schemaVersion() {
        return schemaVersion;
    }

    private void appendEnchantLore(List<Component> lore, EnchantDefinition enchant) {
        String visibleName = enchant.displayName() == null || enchant.displayName().isBlank()
                ? prettify(enchant.key().getKey())
                : enchant.displayName();
        String level = roman(enchant.level());
        for (String format : enchantLoreFormat) {
            lore.add(parse(format.replace("<enchantment>", escapeMiniMessage(visibleName))
                    .replace("<level>", escapeMiniMessage(level))));
        }
    }

    private void addEnchantment(ItemMeta meta, EnchantDefinition definition, boolean hidden) {
        Enchantment enchantment = Registry.ENCHANTMENT.get(definition.key());
        if (enchantment == null) {
            String warningKey = definition.key().toString();
            if (missingEnchantWarnings.add(warningKey)) {
                String severity = hidden ? "hidden curse" : "visible enchantment";
                plugin.getLogger().warning("Could not resolve Crimson armor " + severity + " '" + warningKey
                        + "'. It will be omitted until the providing plugin/registry entry is available.");
            }
            return;
        }
        meta.addEnchant(enchantment, definition.level(), true);
    }

    private List<EnchantDefinition> readEnchantments(YamlConfiguration config, String path,
                                                       Map<String, Integer> defaults) {
        ConfigurationSection section = config.getConfigurationSection(path);
        List<EnchantDefinition> result = new ArrayList<>();
        if (section == null) {
            defaults.forEach((key, level) -> {
                EnchantDefinition parsed = parseEnchant(key, level);
                if (parsed != null) result.add(parsed);
            });
            return List.copyOf(result);
        }
        for (String key : section.getKeys(false)) {
            int level;
            String display = null;
            if (section.isConfigurationSection(key)) {
                level = Math.max(1, section.getInt(key + ".level", 1));
                display = section.getString(key + ".display-name");
            } else {
                level = Math.max(1, section.getInt(key, 1));
            }
            EnchantDefinition parsed = parseEnchant(key, level);
            if (parsed != null) result.add(new EnchantDefinition(parsed.key(), level, display));
        }
        return List.copyOf(result);
    }

    private EnchantDefinition parseEnchant(String raw, int level) {
        if (raw == null || raw.isBlank()) return null;
        NamespacedKey key = NamespacedKey.fromString(raw.toLowerCase(Locale.ROOT));
        if (key == null) {
            plugin.getLogger().severe("Invalid Crimson enchantment key: " + raw);
            return null;
        }
        return new EnchantDefinition(key, Math.max(1, level), null);
    }

    private TrimMaterial resolveTrimMaterial(String raw) {
        NamespacedKey key = NamespacedKey.minecraft(raw.toLowerCase(Locale.ROOT));
        TrimMaterial material = Registry.TRIM_MATERIAL.get(key);
        if (material == null) {
            plugin.getLogger().severe("Invalid Crimson trim material '" + raw + "'; using REDSTONE.");
            return TrimMaterial.REDSTONE;
        }
        return material;
    }

    private TrimPattern resolveTrimPattern(String raw) {
        NamespacedKey key = NamespacedKey.minecraft(raw.toLowerCase(Locale.ROOT));
        TrimPattern pattern = Registry.TRIM_PATTERN.get(key);
        if (pattern == null) {
            plugin.getLogger().severe("Invalid Crimson trim pattern '" + raw + "'; using SILENCE.");
            return TrimPattern.SILENCE;
        }
        return pattern;
    }

    private Component parse(String input) {
        return input == null || input.isEmpty() ? Component.empty() : miniMessage.deserialize(input);
    }

    private static String normalize(String id) {
        return id == null ? "" : id.trim().toLowerCase(Locale.ROOT);
    }

    private static Material defaultMaterial(String id) {
        return switch (id) {
            case "helmet" -> Material.NETHERITE_HELMET;
            case "chestplate" -> Material.NETHERITE_CHESTPLATE;
            case "leggings" -> Material.NETHERITE_LEGGINGS;
            case "boots" -> Material.NETHERITE_BOOTS;
            default -> throw new IllegalArgumentException("Unknown Crimson piece: " + id);
        };
    }

    private static String defaultName(String id) {
        return switch (id) {
            case "helmet" -> "<bold><color:#DC143C>Crimson Helmet</color></bold>";
            case "chestplate" -> "<bold><color:#DC143C>Crimson Chestplate</color></bold>";
            case "leggings" -> "<bold><color:#DC143C>Crimson Leggings</color></bold>";
            case "boots" -> "<bold><color:#DC143C>Crimson Boots</color></bold>";
            default -> id;
        };
    }

    private static Map<String, Integer> defaultEnchantments(String id) {
        return switch (id) {
            case "helmet" -> orderedMap(
                    "minecraft:protection", 5,
                    "minecraft:respiration", 3,
                    "minecraft:aqua_affinity", 1,
                    "minecraft:unbreaking", 5,
                    "minecraft:mending", 1);
            case "chestplate" -> orderedMap(
                    "minecraft:protection", 5,
                    "minecraft:unbreaking", 5,
                    "minecraft:mending", 1);
            case "leggings" -> orderedMap(
                    "minecraft:protection", 5,
                    "minecraft:swift_sneak", 3,
                    "minecraft:unbreaking", 5,
                    "minecraft:mending", 1);
            case "boots" -> orderedMap(
                    "minecraft:protection", 5,
                    "minecraft:feather_falling", 5,
                    "minecraft:depth_strider", 3,
                    "minecraft:soul_speed", 3,
                    "minecraft:unbreaking", 5,
                    "minecraft:mending", 1);
            default -> Map.of();
        };
    }

    private static Map<String, Integer> orderedMap(Object... values) {
        Map<String, Integer> result = new LinkedHashMap<>();
        for (int i = 0; i < values.length; i += 2) {
            result.put((String) values[i], (Integer) values[i + 1]);
        }
        return result;
    }

    private static String prettify(String key) {
        String[] words = key.replace('_', ' ').split(" ");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (!builder.isEmpty()) builder.append(' ');
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return builder.toString();
    }

    private static String roman(int number) {
        if (number <= 0 || number > 3999) return Integer.toString(number);
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder result = new StringBuilder();
        int remaining = number;
        for (int i = 0; i < values.length; i++) {
            while (remaining >= values[i]) {
                result.append(symbols[i]);
                remaining -= values[i];
            }
        }
        return result.toString();
    }

    /** Prevents user-configured literal angle brackets from becoming MiniMessage tags. */
    private static String escapeMiniMessage(String value) {
        return value.replace("<", "\\<").replace(">", "\\>");
    }

    private record PieceDefinition(String id, Material material, String name,
                                   List<EnchantDefinition> visibleEnchantments,
                                   List<String> additionalLore) {}

    private record EnchantDefinition(NamespacedKey key, int level, String displayName) {}
}
