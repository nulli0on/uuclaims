package dev.crimsonprogression.integration;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.node.types.InheritanceNode;
import net.luckperms.api.node.types.MetaNode;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class LuckPermsHook {
    private final LuckPerms api = LuckPermsProvider.get();

    public CompletableFuture<Boolean> addGroup(UUID uuid, String groupName) {
        Group group = api.getGroupManager().getGroup(groupName);
        if (group == null) return CompletableFuture.completedFuture(false);
        return api.getUserManager().loadUser(uuid).thenCompose(user -> {
            user.data().add(InheritanceNode.builder(group).build());
            return api.getUserManager().saveUser(user).thenApply(ignored -> true);
        });
    }

    public CompletableFuture<Boolean> setMeta(UUID uuid, String key, String value) {
        if (key == null || key.isBlank()) return CompletableFuture.completedFuture(false);
        return api.getUserManager().loadUser(uuid).thenCompose(user -> {
            user.data().clear(node -> node instanceof MetaNode meta && meta.getMetaKey().equals(key));
            if (value != null && !value.isBlank()) user.data().add(MetaNode.builder(key, value).build());
            return api.getUserManager().saveUser(user).thenApply(ignored -> true);
        });
    }

    public boolean groupExists(String group) { return api.getGroupManager().getGroup(group) != null; }
}
