package dev.crimsonprogression.core;
import java.util.*;
public final class RewardCalculator {
    private RewardCalculator() {}
    public static List<Reward> calculate(List<DamageLedger.Entry> sorted, Map<Integer,Integer> table) {
        Objects.requireNonNull(sorted); Objects.requireNonNull(table);
        List<Reward> out = new ArrayList<>();
        for (int i=0; i<sorted.size(); i++) {
            int place=i+1; int amount=Math.max(0, table.getOrDefault(place,0));
            if (amount == 0) continue;
            DamageLedger.Entry e=sorted.get(i);
            out.add(new Reward(place,e.playerId(),e.lastKnownName(),e.damage(),amount,e.killingBlow()));
        }
        return List.copyOf(out);
    }
    public record Reward(int placement, UUID playerId, String name, double damage, int tokens, boolean killingBlow) {}
}
