package dev.crimsonprogression.token;

import dev.crimsonprogression.integration.ExcellentEconomyHook;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class TokenService {
    private final ExcellentEconomyHook economy;
    private final Map<UUID, Double> cache = new ConcurrentHashMap<>();

    public TokenService(ExcellentEconomyHook economy) {
        this.economy = economy;
    }

    public boolean available() {
        return economy != null && economy.available();
    }

    public CompletableFuture<Double> refresh(UUID playerId) {
        if (!available()) return CompletableFuture.completedFuture(0D);
        return economy.balance(playerId).thenApply(balance -> {
            cache.put(playerId, balance);
            return balance;
        });
    }

    public double cached(UUID playerId) {
        return cache.getOrDefault(playerId, 0D);
    }

    public CompletableFuture<Boolean> give(UUID playerId, double amount) {
        if (!available() || amount < 0) return CompletableFuture.completedFuture(false);
        return economy.deposit(playerId, amount).thenCompose(success ->
                success ? refresh(playerId).thenApply(ignored -> true) : CompletableFuture.completedFuture(false));
    }

    public CompletableFuture<Boolean> take(UUID playerId, double amount) {
        if (!available() || amount < 0) return CompletableFuture.completedFuture(false);
        return economy.withdraw(playerId, amount).thenCompose(success ->
                success ? refresh(playerId).thenApply(ignored -> true) : CompletableFuture.completedFuture(false));
    }

    public CompletableFuture<Boolean> set(UUID playerId, double amount) {
        if (!available() || amount < 0) return CompletableFuture.completedFuture(false);
        return economy.set(playerId, amount).thenCompose(success ->
                success ? refresh(playerId).thenApply(ignored -> true) : CompletableFuture.completedFuture(false));
    }

    public void unload(UUID playerId) {
        cache.remove(playerId);
    }
}
