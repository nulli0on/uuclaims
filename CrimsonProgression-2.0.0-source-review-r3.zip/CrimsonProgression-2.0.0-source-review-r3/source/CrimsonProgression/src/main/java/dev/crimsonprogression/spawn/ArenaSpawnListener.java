package dev.crimsonprogression.spawn;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.boss.BossManager;
import dev.crimsonprogression.integration.MythicMobsHook;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ArenaSpawnListener implements Listener {
    private final CrimsonProgressionPlugin plugin;
    private volatile String world;
    private volatile Set<CreatureSpawnEvent.SpawnReason> blocked = Set.of();
    private volatile Set<CreatureSpawnEvent.SpawnReason> allowed = Set.of();
    private volatile boolean allowActiveBossPdc;
    private volatile boolean allowMythicMobs;
    private final BossManager bosses;
    private final MythicMobsHook mythic;
    private final AtomicBoolean mythicLookupWarningLogged = new AtomicBoolean();

    public ArenaSpawnListener(CrimsonProgressionPlugin plugin, BossManager bosses,
                              MythicMobsHook mythic) {
        this.plugin = plugin;
        this.bosses = bosses;
        this.mythic = mythic;
        reload();
    }

    public void reload() {
        world = plugin.spawnConfig().getString("world", "bossarena");
        blocked = Set.copyOf(parse(plugin.spawnConfig().getStringList("blocked-reasons"), plugin));
        allowed = Set.copyOf(parse(plugin.spawnConfig().getStringList("allowed-reasons"), plugin));
        allowActiveBossPdc = plugin.spawnConfig().getBoolean("allow-active-boss-pdc", true);
        allowMythicMobs = plugin.spawnConfig().getBoolean("allow-mythicmobs", true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (!plugin.getConfig().getBoolean("features.natural-spawn-control", true)) return;
        if (!event.getLocation().getWorld().getName().equals(world)) return;
        if (allowed.contains(event.getSpawnReason())) return;
        if (allowActiveBossPdc && bosses.isBoss(event.getEntity())) return;
        if (allowMythicMobs && isMythicMob(event)) return;
        if (blocked.contains(event.getSpawnReason())) event.setCancelled(true);
    }

    private boolean isMythicMob(CreatureSpawnEvent event) {
        try {
            return mythic.isMythicMob(event.getEntity());
        } catch (RuntimeException error) {
            if (mythicLookupWarningLogged.compareAndSet(false, true)) {
                plugin.getLogger().log(java.util.logging.Level.WARNING,
                        "MythicMobs entity detection failed; configured spawn-reason rules will be used instead.",
                        error);
            }
            return false;
        }
    }

    private static Set<CreatureSpawnEvent.SpawnReason> parse(
            List<String> values, CrimsonProgressionPlugin plugin) {
        Set<CreatureSpawnEvent.SpawnReason> result =
                EnumSet.noneOf(CreatureSpawnEvent.SpawnReason.class);
        for (String value : values) {
            try {
                result.add(CreatureSpawnEvent.SpawnReason.valueOf(
                        value.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Unknown CreatureSpawnEvent reason: " + value);
            }
        }
        return result;
    }
}
