package dev.crimsonprogression.message;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.List;
import java.util.Map;

public final class MessageService {
    private volatile YamlConfiguration config;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    public MessageService(YamlConfiguration config) { this.config = config; }
    public void reload(YamlConfiguration replacement) { this.config = replacement; }
    public void send(CommandSender target, String key) { send(target, key, Map.of()); }

    public void send(CommandSender target, String key, Map<String, String> values) {
        YamlConfiguration snapshot = config;
        String text = snapshot.getString(key, "<red>Missing message: " + key + "</red>");
        String prefix = snapshot.getString("prefix", "");
        target.sendMessage(miniMessage.deserialize(replace(prefix + text, values)));
    }

    public void sendLines(CommandSender target, List<String> lines, Map<String, String> values) {
        for (String line : lines) target.sendMessage(miniMessage.deserialize(replace(line, values)));
    }

    private static String replace(String text, Map<String, String> values) {
        String output = text;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            output = output.replace("<" + entry.getKey() + ">", escape(entry.getValue()));
        }
        return output;
    }

    private static String escape(String text) {
        return text == null ? "" : text.replace("\\", "\\\\").replace("<", "\\<");
    }
}
