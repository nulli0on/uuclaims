package dev.crimsonprogression.crimson;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.boss.BossManager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.potion.PotionEffectType;

public final class CrimsonArmorListener implements Listener {
    private final CrimsonProgressionPlugin plugin;
    private final CrimsonArmorService armor;
    private final BossManager bosses;

    public CrimsonArmorListener(CrimsonProgressionPlugin plugin,
                                CrimsonArmorService armor,
                                BossManager bosses) {
        this.plugin = plugin;
        this.armor = armor;
        this.bosses = bosses;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!bosses.isBoss(event.getEntity())) return;
        Player player = player(event.getDamager());
        if (player == null || !armor.hasFullSet(player)) return;
        double configured = plugin.crimsonConfig().getDouble("abilities.boss-damage-multiplier", 1.20D);
        double multiplier = Double.isFinite(configured)
                ? Math.max(0.0D, Math.min(10.0D, configured)) : 1.0D;
        double damage = event.getDamage();
        if (!Double.isFinite(damage)) return;
        event.setDamage(Math.max(0.0D, damage * multiplier));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onWitherDamage(EntityDamageEvent event) {
        if (!witherImmune()
                || event.getCause() != EntityDamageEvent.DamageCause.WITHER
                || !(event.getEntity() instanceof Player player)
                || !armor.hasFullSet(player)) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPotion(EntityPotionEffectEvent event) {
        if (!witherImmune()
                || !(event.getEntity() instanceof Player player)
                || !armor.hasFullSet(player)
                || event.getNewEffect() == null
                || event.getNewEffect().getType() != PotionEffectType.WITHER) {
            return;
        }
        event.setCancelled(true);
    }

    private boolean witherImmune() {
        return plugin.crimsonConfig().getBoolean("abilities.wither-immunity", true);
    }

    public static Player player(Entity damager) {
        if (damager instanceof Player player) return player;
        if (damager instanceof Projectile projectile) {
            ProjectileSource source = projectile.getShooter();
            if (source instanceof Player player) return player;
        }
        return null;
    }
}
