package dev.crimsonprogression.tag;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.database.DatabaseService;
import dev.crimsonprogression.integration.LuckPermsHook;
import org.bukkit.configuration.ConfigurationSection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** SQLite-authoritative tag ownership and selection cache. */
public final class TagService {
    private final CrimsonProgressionPlugin plugin;
    private final DatabaseService database;
    private final LuckPermsHook luckPerms;
    private final Map<UUID, Set<String>> ownedCache = new ConcurrentHashMap<>();
    private final Map<UUID, String> selectedCache = new ConcurrentHashMap<>();
    private volatile Map<String, TagDefinition> definitions = Map.of();

    public TagService(CrimsonProgressionPlugin plugin, DatabaseService database, LuckPermsHook luckPerms) {
        this.plugin = plugin;
        this.database = database;
        this.luckPerms = luckPerms;
        reloadDefinitions();
    }

    public void reloadDefinitions() {
        Map<String, TagDefinition> loaded = new LinkedHashMap<>();
        ConfigurationSection root = plugin.tagConfig().getConfigurationSection("tags");
        if (root != null) {
            for (String rawId : root.getKeys(false)) {
                String id = normalize(rawId);
                if (!id.matches("[a-z0-9_-]{1,48}")) {
                    plugin.getLogger().severe("Disabled tag with invalid ID: " + rawId);
                    continue;
                }
                String display = root.getString(rawId + ".display", "[" + rawId + "]");
                String plain = root.getString(rawId + ".plain", "[" + rawId + "]");
                loaded.put(id, new TagDefinition(id, display, plain));
            }
        }
        definitions = Map.copyOf(loaded);
        // Invalid selections are suppressed immediately; DB cleanup occurs on next load/select.
        selectedCache.entrySet().removeIf(entry -> !definitions.containsKey(entry.getValue()));
    }

    public Set<String> definitionIds() { return definitions.keySet(); }

    public Optional<TagDefinition> definition(String id) {
        return Optional.ofNullable(definitions.get(normalize(id)));
    }

    public CompletableFuture<Void> load(UUID playerId) {
        return database.submit(connection -> {
            Set<String> owned = new HashSet<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT tag_id FROM owned_tags WHERE player_uuid=?")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) owned.add(normalize(result.getString(1)));
                }
            }
            String selected = null;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT tag_id FROM selected_tags WHERE player_uuid=?")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (result.next()) selected = normalize(result.getString(1));
                }
            }
            ownedCache.put(playerId, Set.copyOf(owned));
            if (selected != null && owned.contains(selected) && definitions.containsKey(selected)) {
                selectedCache.put(playerId, selected);
            } else {
                selectedCache.remove(playerId);
            }
            return selectedCache.get(playerId);
        }).thenCompose(selected -> syncLuckPerms(playerId, selected).thenApply(ignored -> null));
    }

    public void unload(UUID playerId) {
        ownedCache.remove(playerId);
        selectedCache.remove(playerId);
    }

    public CompletableFuture<Boolean> grant(UUID playerId, String tagId, String source) {
        String normalized = normalize(tagId);
        if (!definitions.containsKey(normalized)) return CompletableFuture.completedFuture(false);
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT OR IGNORE INTO owned_tags(player_uuid,tag_id,source,acquired_at) VALUES(?,?,?,?)")) {
                statement.setString(1, playerId.toString());
                statement.setString(2, normalized);
                statement.setString(3, source == null ? "UNKNOWN" : source);
                statement.setLong(4, System.currentTimeMillis());
                statement.executeUpdate();
            }
            ownedCache.compute(playerId, (uuid, previous) -> {
                Set<String> mutable = new HashSet<>(previous == null ? Set.of() : previous);
                mutable.add(normalized);
                return Set.copyOf(mutable);
            });
            return true;
        });
    }

    public CompletableFuture<Boolean> select(UUID playerId, String tagId) {
        String normalized = normalize(tagId);
        if (!definitions.containsKey(normalized) || !owns(playerId, normalized)) {
            return CompletableFuture.completedFuture(false);
        }
        return database.transaction(connection -> {
            // Re-check authoritative ownership in the same DB transaction.
            try (PreparedStatement owned = connection.prepareStatement(
                    "SELECT 1 FROM owned_tags WHERE player_uuid=? AND tag_id=?")) {
                owned.setString(1, playerId.toString());
                owned.setString(2, normalized);
                try (ResultSet result = owned.executeQuery()) {
                    if (!result.next()) return false;
                }
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO selected_tags(player_uuid,tag_id,updated_at) VALUES(?,?,?) "
                            + "ON CONFLICT(player_uuid) DO UPDATE SET tag_id=excluded.tag_id,updated_at=excluded.updated_at")) {
                statement.setString(1, playerId.toString());
                statement.setString(2, normalized);
                statement.setLong(3, System.currentTimeMillis());
                statement.executeUpdate();
            }
            selectedCache.put(playerId, normalized);
            return true;
        }).thenCompose(success -> success
                ? syncLuckPerms(playerId, normalized).thenApply(ignored -> true)
                : CompletableFuture.completedFuture(false));
    }

    public CompletableFuture<Void> clear(UUID playerId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM selected_tags WHERE player_uuid=?")) {
                statement.setString(1, playerId.toString());
                statement.executeUpdate();
            }
            selectedCache.remove(playerId);
            return null;
        }).thenCompose(ignored -> syncLuckPerms(playerId, null).thenApply(success -> null));
    }

    private CompletableFuture<Boolean> syncLuckPerms(UUID playerId, String tagId) {
        if (luckPerms == null || !plugin.tagConfig().getBoolean("sync-to-luckperms", true)) {
            return CompletableFuture.completedFuture(true);
        }
        String value = tagId == null ? null : definitions.get(tagId).display();
        String metaKey = plugin.tagConfig().getString("luckperms-meta-key", "crimson-tag");
        return luckPerms.setMeta(playerId, metaKey, value);
    }

    public boolean owns(UUID playerId, String tagId) {
        return ownedCache.getOrDefault(playerId, Set.of()).contains(normalize(tagId));
    }

    public Set<String> owned(UUID playerId) { return ownedCache.getOrDefault(playerId, Set.of()); }
    public Optional<String> selectedId(UUID playerId) { return Optional.ofNullable(selectedCache.get(playerId)); }
    public String display(UUID playerId) { return selectedId(playerId).map(definitions::get).map(TagDefinition::display).orElse(""); }
    public String plain(UUID playerId) { return selectedId(playerId).map(definitions::get).map(TagDefinition::plain).orElse(""); }

    private static String normalize(String id) {
        return id == null ? "" : id.trim().toLowerCase(Locale.ROOT);
    }

    public record TagDefinition(String id, String display, String plain) {}
}
