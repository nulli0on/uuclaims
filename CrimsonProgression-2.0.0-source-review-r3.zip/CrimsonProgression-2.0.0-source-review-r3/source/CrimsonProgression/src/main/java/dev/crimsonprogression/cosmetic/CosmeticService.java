package dev.crimsonprogression.cosmetic;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.database.DatabaseService;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.scheduler.BukkitTask;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** Persistent, non-gameplay cosmetic ownership and effects. */
public final class CosmeticService {
    private final CrimsonProgressionPlugin plugin;
    private final DatabaseService database;
    private volatile Map<String, CosmeticDefinition> definitions = Map.of();
    private final Map<UUID, Set<String>> ownership = new ConcurrentHashMap<>();
    private final Map<UUID, String> selected = new ConcurrentHashMap<>();
    private final Map<UUID, String> projectileTrails = new ConcurrentHashMap<>();
    private final Map<UUID, Long> combatUntil = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> victoryTasks = new ConcurrentHashMap<>();
    private BukkitTask ambientTask;
    private BukkitTask projectileTask;
    private long ambientTicks;

    public CosmeticService(CrimsonProgressionPlugin plugin, DatabaseService database) {
        this.plugin = plugin;
        this.database = database;
        reloadDefinitions();
    }

    public void reloadDefinitions() {
        Map<String, CosmeticDefinition> loaded = new LinkedHashMap<>();
        ConfigurationSection root = plugin.cosmeticConfig().getConfigurationSection("catalogue");
        if (root == null) {
            definitions = Map.of();
            return;
        }
        for (String rawId : root.getKeys(false)) {
            String id = rawId.toLowerCase(Locale.ROOT);
            ConfigurationSection section = root.getConfigurationSection(rawId);
            if (section == null || !section.getBoolean("enabled", true)) continue;
            String effect = section.getString("effect", "NONE").toUpperCase(Locale.ROOT);
            if (!Set.of("FOOTSTEP_PARTICLE", "HALO_PARTICLE", "PROJECTILE_TRAIL", "JOIN_EFFECT", "BOSS_VICTORY").contains(effect)) {
                plugin.getLogger().warning("Disabled cosmetic '" + id + "': unsupported effect " + effect);
                continue;
            }
            String particle = section.getString("particle", "FLAME");
            try {
                Particle.valueOf(particle.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Disabled cosmetic '" + id + "': unknown particle " + particle);
                continue;
            }
            loaded.put(id, new CosmeticDefinition(
                    id,
                    section.getString("display-name", id),
                    effect,
                    particle,
                    section.getBoolean("resource-pack-required", false)
            ));
        }
        definitions = Map.copyOf(loaded);
    }

    public CompletableFuture<Void> load(UUID playerId) {
        return database.submit(connection -> {
            Set<String> found = new HashSet<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT cosmetic_id FROM cosmetic_unlocks WHERE player_uuid=?")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        String id = result.getString(1).toLowerCase(Locale.ROOT);
                        if (definitions.containsKey(id)) found.add(id);
                    }
                }
            }
            ownership.put(playerId, Set.copyOf(found));
            selected.remove(playerId);
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT cosmetic_id FROM selected_cosmetics WHERE player_uuid=? AND cosmetic_slot='PRIMARY'")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (result.next()) {
                        String id = result.getString(1).toLowerCase(Locale.ROOT);
                        if (found.contains(id) && definitions.containsKey(id)) selected.put(playerId, id);
                    }
                }
            }
            return null;
        });
    }

    public void unload(UUID playerId) {
        ownership.remove(playerId);
        selected.remove(playerId);
        combatUntil.remove(playerId);
        BukkitTask victory = victoryTasks.remove(playerId);
        if (victory != null) victory.cancel();
        projectileTrails.entrySet().removeIf(entry -> {
            var entity = Bukkit.getEntity(entry.getKey());
            return entity instanceof Projectile projectile
                    && projectile.getShooter() instanceof Player player
                    && player.getUniqueId().equals(playerId);
        });
    }

    public CompletableFuture<Boolean> grant(UUID playerId, String rawCosmeticId, String source) {
        String cosmeticId = normalize(rawCosmeticId);
        if (!definitions.containsKey(cosmeticId)) return CompletableFuture.completedFuture(false);
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT OR IGNORE INTO cosmetic_unlocks(player_uuid,cosmetic_id,source,acquired_at) VALUES(?,?,?,?)")) {
                statement.setString(1, playerId.toString());
                statement.setString(2, cosmeticId);
                statement.setString(3, source == null ? "UNKNOWN" : source);
                statement.setLong(4, System.currentTimeMillis());
                statement.executeUpdate();
            }
            ownership.compute(playerId, (uuid, previous) -> {
                Set<String> mutable = new HashSet<>(previous == null ? Set.of() : previous);
                mutable.add(cosmeticId);
                return Set.copyOf(mutable);
            });
            return true;
        });
    }

    public CompletableFuture<Boolean> select(UUID playerId, String rawCosmeticId) {
        String cosmeticId = normalize(rawCosmeticId);
        if (!definitions.containsKey(cosmeticId)
                || !ownership.getOrDefault(playerId, Set.of()).contains(cosmeticId)) {
            return CompletableFuture.completedFuture(false);
        }
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO selected_cosmetics(player_uuid,cosmetic_slot,cosmetic_id,updated_at) VALUES(?,'PRIMARY',?,?) "
                            + "ON CONFLICT(player_uuid,cosmetic_slot) DO UPDATE SET cosmetic_id=excluded.cosmetic_id,updated_at=excluded.updated_at")) {
                statement.setString(1, playerId.toString());
                statement.setString(2, cosmeticId);
                statement.setLong(3, System.currentTimeMillis());
                statement.executeUpdate();
            }
            selected.put(playerId, cosmeticId);
            return true;
        });
    }

    public CompletableFuture<Void> clear(UUID playerId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM selected_cosmetics WHERE player_uuid=? AND cosmetic_slot='PRIMARY'")) {
                statement.setString(1, playerId.toString());
                statement.executeUpdate();
            }
            selected.remove(playerId);
            return null;
        });
    }

    public void start() {
        stop();
        ambientTask = Bukkit.getScheduler().runTaskTimer(plugin, this::ambientTick, 10L, 2L);
        projectileTask = Bukkit.getScheduler().runTaskTimer(plugin, this::projectileTick, 2L, 2L);
    }

    public void stop() {
        if (ambientTask != null) ambientTask.cancel();
        if (projectileTask != null) projectileTask.cancel();
        ambientTask = null;
        projectileTask = null;
        projectileTrails.clear();
        victoryTasks.values().forEach(BukkitTask::cancel);
        victoryTasks.clear();
    }

    private void ambientTick() {
        ambientTicks += 2;
        if (ambientTicks % 10 != 0) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (suppressed(player.getUniqueId())) continue;
            CosmeticDefinition definition = selectedDefinition(player.getUniqueId());
            if (definition == null) continue;
            if ("FOOTSTEP_PARTICLE".equals(definition.effect()) && player.getVelocity().lengthSquared() > 0.01D) {
                spawn(player.getWorld(), definition, player.getLocation(), 2, .12, .02, .12, 0);
            } else if ("HALO_PARTICLE".equals(definition.effect())) {
                double angle = (System.currentTimeMillis() / 100.0D) % (Math.PI * 2);
                Location location = player.getLocation().add(Math.cos(angle) * .45, 2.15, Math.sin(angle) * .45);
                spawn(player.getWorld(), definition, location, 1, 0, 0, 0, 0);
            }
        }
    }

    private void projectileTick() {
        Iterator<Map.Entry<UUID, String>> iterator = projectileTrails.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, String> entry = iterator.next();
            var entity = Bukkit.getEntity(entry.getKey());
            if (!(entity instanceof Projectile projectile) || !projectile.isValid() || projectile.isDead()) {
                iterator.remove();
                continue;
            }
            if (!(projectile.getShooter() instanceof Player player) || suppressed(player.getUniqueId())) continue;
            CosmeticDefinition definition = definitions.get(entry.getValue());
            if (definition == null || !"PROJECTILE_TRAIL".equals(definition.effect())) {
                iterator.remove();
                continue;
            }
            spawn(projectile.getWorld(), definition, projectile.getLocation(), 2, .03, .03, .03, 0);
        }
    }

    public void trackProjectile(Projectile projectile, Player owner) {
        if (suppressed(owner.getUniqueId())) return;
        CosmeticDefinition definition = selectedDefinition(owner.getUniqueId());
        if (definition != null && "PROJECTILE_TRAIL".equals(definition.effect())) {
            projectileTrails.put(projectile.getUniqueId(), definition.id());
        }
    }

    public void untrackProjectile(UUID projectileId) {
        projectileTrails.remove(projectileId);
    }

    public void markCombat(Player player) {
        long duration = Math.max(0, plugin.cosmeticConfig().getLong("combat-disable-seconds", 10)) * 1000L;
        if (duration > 0) combatUntil.put(player.getUniqueId(), System.currentTimeMillis() + duration);
    }

    public void joinEffect(Player player) {
        if (suppressed(player.getUniqueId())) return;
        CosmeticDefinition definition = selectedDefinition(player.getUniqueId());
        if (definition != null && "JOIN_EFFECT".equals(definition.effect())) {
            spawn(player.getWorld(), definition, player.getLocation().add(0, 1, 0), 35, .6, 1.0, .6, .05);
        }
    }

    public void bossVictory(Player player) {
        if (!player.isOnline() || suppressed(player.getUniqueId())) return;
        CosmeticDefinition definition = selectedDefinition(player.getUniqueId());
        if (definition == null || !"BOSS_VICTORY".equals(definition.effect())) return;
        BukkitTask old = victoryTasks.remove(player.getUniqueId());
        if (old != null) old.cancel();
        AtomicInteger step = new AtomicInteger();
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || suppressed(player.getUniqueId()) || step.get() >= 30) {
                BukkitTask current = victoryTasks.remove(player.getUniqueId());
                if (current != null) current.cancel();
                return;
            }
            int current = step.getAndIncrement();
            double angle = current * 0.65D;
            double radius = 0.25D + current * 0.018D;
            Location base = player.getLocation().add(0, 0.2D + current * 0.055D, 0);
            spawn(player.getWorld(), definition,
                    base.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius),
                    3, .03, .03, .03, 0);
        }, 0L, 2L);
        victoryTasks.put(player.getUniqueId(), holder[0]);
    }

    private CosmeticDefinition selectedDefinition(UUID playerId) {
        return definitions.get(selected.get(playerId));
    }

    private boolean suppressed(UUID playerId) {
        Long until = combatUntil.get(playerId);
        if (until == null) return false;
        if (until <= System.currentTimeMillis()) {
            combatUntil.remove(playerId, until);
            return false;
        }
        return true;
    }

    private void spawn(World world, CosmeticDefinition definition, Location location, int count,
                       double offsetX, double offsetY, double offsetZ, double extra) {
        Particle particle = Particle.valueOf(definition.particle().toUpperCase(Locale.ROOT));
        if (particle == Particle.DUST) {
            String raw = plugin.cosmeticConfig().getString("catalogue." + definition.id() + ".dust-color", "#CC2222");
            float size = (float) plugin.cosmeticConfig().getDouble("catalogue." + definition.id() + ".dust-size", 1.0D);
            Color color;
            try { color = Color.fromRGB(Integer.parseInt(raw.replace("#", ""), 16)); }
            catch (RuntimeException ignored) { color = Color.fromRGB(204, 34, 34); }
            world.spawnParticle(particle, location, count, offsetX, offsetY, offsetZ, extra,
                    new Particle.DustOptions(color, Math.max(.1F, Math.min(4F, size))));
        } else {
            world.spawnParticle(particle, location, count, offsetX, offsetY, offsetZ, extra);
        }
    }

    public Set<String> ids() { return definitions.keySet(); }
    public Set<String> owned(UUID playerId) { return ownership.getOrDefault(playerId, Set.of()); }
    public Optional<String> selected(UUID playerId) { return Optional.ofNullable(selected.get(playerId)); }
    public Optional<CosmeticDefinition> definition(String id) { return Optional.ofNullable(definitions.get(normalize(id))); }

    private static String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
    }

    public record CosmeticDefinition(String id, String display, String effect, String particle,
                                     boolean resourcePackRequired) {}
}
