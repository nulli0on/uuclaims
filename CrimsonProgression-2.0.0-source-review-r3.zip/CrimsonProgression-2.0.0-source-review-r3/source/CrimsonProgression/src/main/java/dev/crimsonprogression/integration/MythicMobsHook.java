package dev.crimsonprogression.integration;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

/** Calls the supported MythicBukkit managers without using NMS. */
public final class MythicMobsHook {
    private final Class<?> mythicBukkit;
    private final Class<?> bukkitAdapter;

    public MythicMobsHook() {
        try {
            ClassLoader loader = MythicMobsHook.class.getClassLoader();
            mythicBukkit = Class.forName("io.lumine.mythic.bukkit.MythicBukkit", true, loader);
            bukkitAdapter = Class.forName("io.lumine.mythic.bukkit.BukkitAdapter", true, loader);
        } catch (ClassNotFoundException exception) {
            throw new IllegalStateException("MythicMobs Bukkit API is unavailable", exception);
        }
    }

    public Optional<Entity> spawn(String id, Location location) {
        Object instance = ReflectionSupport.invoke(mythicBukkit, "inst");
        Object manager = ReflectionSupport.invoke(instance, "getMobManager");
        Object optional = ReflectionSupport.invoke(manager, "getMythicMob", id);
        Object mob = optionalValue(optional);
        if (mob == null) return Optional.empty();
        Object abstractLocation = ReflectionSupport.invoke(bukkitAdapter, "adapt", location);
        Object activeMob = ReflectionSupport.invoke(mob, "spawn", abstractLocation, 1D);
        if (activeMob == null) return Optional.empty();
        Object abstractEntity = ReflectionSupport.invoke(activeMob, "getEntity");
        Object entity = ReflectionSupport.invoke(abstractEntity, "getBukkitEntity");
        return entity instanceof Entity bukkitEntity ? Optional.of(bukkitEntity) : Optional.empty();
    }

    public boolean isMythicMob(Entity entity) {
        Object instance = ReflectionSupport.invoke(mythicBukkit, "inst");
        Object manager = ReflectionSupport.invoke(instance, "getMobManager");
        return Boolean.TRUE.equals(ReflectionSupport.invoke(manager, "isMythicMob", entity));
    }

    public boolean mobExists(String id) {
        try {
            Object instance = ReflectionSupport.invoke(mythicBukkit, "inst");
            Object manager = ReflectionSupport.invoke(instance, "getMobManager");
            Object optional = ReflectionSupport.invoke(manager, "getMythicMob", id);
            return optionalValue(optional) != null;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public Optional<ItemStack> item(String id) {
        try {
            Object instance = ReflectionSupport.invoke(mythicBukkit, "inst");
            Object manager = ReflectionSupport.invoke(instance, "getItemManager");
            Object value = ReflectionSupport.invoke(manager, "getItemStack", id);
            return value instanceof ItemStack stack ? Optional.of(stack.clone()) : Optional.empty();
        } catch (RuntimeException exception) {
            return Optional.empty();
        }
    }

    private static Object optionalValue(Object optional) {
        if (optional instanceof Optional<?> value) return value.orElse(null);
        return optional;
    }
}
