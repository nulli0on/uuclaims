package dev.crimsonprogression.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

public final class ConfigFiles {
    private final JavaPlugin plugin;
    private final Map<String, YamlConfiguration> files = new HashMap<>();

    public ConfigFiles(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll(String... names) {
        for (String name : names) load(name);
    }

    public YamlConfiguration load(String name) {
        YamlConfiguration yaml = readStrict(name);
        files.put(name, yaml);
        return yaml;
    }

    public YamlConfiguration get(String name) {
        YamlConfiguration value = files.get(name);
        if (value == null) {
            throw new IllegalStateException("Configuration not loaded: " + name);
        }
        return value;
    }

    public void reload() {
        Map<String, YamlConfiguration> reloaded = new LinkedHashMap<>();
        for (String name : new ArrayList<>(files.keySet())) {
            reloaded.put(name, readStrict(name));
        }
        files.clear();
        files.putAll(reloaded);
    }

    private YamlConfiguration readStrict(String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) plugin.saveResource(name, false);
        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(file);
            mergeMissingDefaults(name, file, yaml);
        } catch (Exception exception) {
            throw new IllegalStateException("Invalid configuration file: " + name, exception);
        }
        return yaml;
    }

    /** Adds newly bundled keys without replacing administrator-customized values. */
    private void mergeMissingDefaults(String name, File file, YamlConfiguration existing) throws Exception {
        try (InputStream stream = plugin.getResource(name)) {
            if (stream == null) return;
            YamlConfiguration bundled = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(stream, StandardCharsets.UTF_8));
            boolean changed = false;
            for (String key : bundled.getKeys(true)) {
                if (bundled.isConfigurationSection(key) || existing.contains(key)) continue;
                existing.set(key, bundled.get(key));
                changed = true;
            }

            int bundledVersion = bundled.getInt("config-version", 0);
            int currentVersion = existing.getInt("config-version", 0);
            if (bundledVersion > currentVersion) {
                existing.set("config-version", bundledVersion);
                changed = true;
            }
            if (!changed) return;

            File backup = new File(file.getParentFile(), name + ".pre-merge.bak");
            Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            existing.save(file);
            plugin.getLogger().warning("Merged new defaults into " + name
                    + "; previous contents were backed up as " + backup.getName());
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING,
                    "Could not merge newly bundled defaults into " + name, exception);
            throw exception;
        }
    }
}
