package dev.crimsonprogression.integration;

import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Optional public Bukkit service bridge exposed by UltimateClaims 1.1+. */
public final class UltimateClaimsHook {
    private static final String API_CLASS = "dev.ultimateclaims.api.UltimateClaimsApi";
    private final Object api;

    private UltimateClaimsHook(Object api) {
        this.api = api;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static UltimateClaimsHook hook() {
        try {
            Class type = Class.forName(API_CLASS, true, UltimateClaimsHook.class.getClassLoader());
            RegisteredServiceProvider registration = Bukkit.getServicesManager().getRegistration(type);
            return registration == null || registration.getProvider() == null
                    ? null : new UltimateClaimsHook(registration.getProvider());
        } catch (ClassNotFoundException exception) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public CompletableFuture<Boolean> addClaimBlocks(UUID playerId, int amount) {
        if (amount <= 0) return CompletableFuture.completedFuture(false);
        Object value = ReflectionSupport.invoke(api, "addClaimBlocks", playerId, amount);
        if (!(value instanceof CompletableFuture<?> future)) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "UltimateClaims API returned no CompletableFuture"));
        }
        return ((CompletableFuture<Object>) future).thenApply(Boolean.TRUE::equals);
    }
}
