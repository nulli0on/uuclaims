package dev.crimsonprogression.core;

import java.util.UUID;
import java.util.regex.Pattern;

public record VoucherPayload(String rewardId, UUID nonce, int schemaVersion, long createdAt, UUID issuer) {
    private static final Pattern REWARD_ID = Pattern.compile("[a-z0-9_-]{1,64}");

    public VoucherPayload {
        if (rewardId == null || !REWARD_ID.matcher(rewardId).matches()) throw new IllegalArgumentException("Invalid reward id");
        if (nonce == null) throw new IllegalArgumentException("nonce");
        if (schemaVersion < 1) throw new IllegalArgumentException("schemaVersion");
        if (createdAt <= 0) throw new IllegalArgumentException("createdAt");
    }

    public String canonical() {
        return rewardId + "\n" + nonce + "\n" + schemaVersion + "\n" + createdAt + "\n" + (issuer == null ? "" : issuer);
    }
}
