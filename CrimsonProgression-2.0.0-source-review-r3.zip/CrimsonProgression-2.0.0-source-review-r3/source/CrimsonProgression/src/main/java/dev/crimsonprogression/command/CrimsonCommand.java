package dev.crimsonprogression.command;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/** Player and granular administrative command surface. */
public final class CrimsonCommand implements CommandExecutor, TabCompleter {
    private final CrimsonProgressionPlugin plugin;

    public CrimsonCommand(CrimsonProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "bossfight" -> bossFight(sender);
            case "tokens" -> tokens(sender);
            case "tags" -> tags(sender);
            case "tag" -> tag(sender, args);
            case "cosmetics" -> cosmetics(sender);
            case "cosmetic" -> cosmetic(sender, args);
            case "crimsonprogression" -> admin(sender, args);
            default -> false;
        };
    }

    private boolean requireReady(CommandSender sender) {
        if (plugin.ready()) return true;
        plugin.messages().send(sender, "feature-disabled");
        return false;
    }

    private boolean bossFight(CommandSender sender) {
        if (!requireReady(sender)) return true;
        if (plugin.bossManager() == null) {
            plugin.messages().send(sender, "no-active-fight");
            return true;
        }
        if (plugin.bossManager().recoveryBlocked()) {
            plugin.messages().send(sender, "boss-recovery-blocked");
            return true;
        }
        if (plugin.bossManager().active().isEmpty()) {
            plugin.messages().send(sender, "no-active-fight");
            return true;
        }
        var fight = plugin.bossManager().active().orElseThrow();
        plugin.messages().send(sender, "active-fight", Map.of(
                "boss", fight.definition().displayName(),
                "health", plugin.bossManager().currentHealth(),
                "max_health", String.format(Locale.US, "%.0f", fight.maxHealth())));
        return true;
    }

    private boolean tokens(CommandSender sender) {
        if (!requireReady(sender)) return true;
        if (!(sender instanceof Player player)) return playerOnly(sender);
        plugin.tokenService().refresh(player.getUniqueId()).whenComplete((balance, error) -> main(() -> {
            if (error != null) plugin.fail(player, "tokens-balance", error);
            else plugin.messages().send(player, "tokens-balance", Map.of("amount", format(balance)));
        }));
        return true;
    }

    private boolean tags(CommandSender sender) {
        if (!requireReady(sender)) return true;
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Set<String> owned = plugin.tagService().owned(player.getUniqueId());
        if (owned.isEmpty()) plugin.messages().send(player, "tags-empty");
        else plugin.messages().send(player, "tags-list", Map.of("tags", String.join(", ", new TreeSet<>(owned))));
        return true;
    }

    private boolean tag(CommandSender sender, String[] args) {
        if (!requireReady(sender)) return true;
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length != 1) {
            sender.sendMessage("/tag <id|clear>");
            return true;
        }
        if ("clear".equalsIgnoreCase(args[0])) {
            plugin.tagService().clear(player.getUniqueId()).whenComplete((ignored, error) -> main(() -> {
                if (error != null) plugin.fail(player, "tag-clear", error);
                else plugin.messages().send(player, "tag-cleared");
            }));
            return true;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        plugin.tagService().select(player.getUniqueId(), id).whenComplete((success, error) -> main(() -> {
            if (error != null) plugin.fail(player, "tag-select", error);
            else if (!success) plugin.messages().send(player, "tag-not-owned");
            else plugin.messages().send(player, "tag-selected", Map.of("tag", id));
        }));
        return true;
    }

    private boolean cosmetics(CommandSender sender) {
        if (!requireReady(sender)) return true;
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Set<String> owned = plugin.cosmeticService().owned(player.getUniqueId());
        if (owned.isEmpty()) plugin.messages().send(player, "cosmetics-empty");
        else plugin.messages().send(player, "cosmetics-list", Map.of(
                "cosmetics", String.join(", ", new TreeSet<>(owned)),
                "selected", plugin.cosmeticService().selected(player.getUniqueId()).orElse("none")));
        return true;
    }

    private boolean cosmetic(CommandSender sender, String[] args) {
        if (!requireReady(sender)) return true;
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length != 1) {
            sender.sendMessage("/cosmetic <id|clear>");
            return true;
        }
        if ("clear".equalsIgnoreCase(args[0])) {
            plugin.cosmeticService().clear(player.getUniqueId()).whenComplete((ignored, error) -> main(() -> {
                if (error != null) plugin.fail(player, "cosmetic-clear", error);
                else plugin.messages().send(player, "cosmetic-cleared");
            }));
            return true;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        plugin.cosmeticService().select(player.getUniqueId(), id).whenComplete((success, error) -> main(() -> {
            if (error != null) plugin.fail(player, "cosmetic-select", error);
            else if (!success) plugin.messages().send(player, "cosmetic-not-owned");
            else plugin.messages().send(player, "cosmetic-selected", Map.of("cosmetic", id));
        }));
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (!requireReady(sender)) return true;
        if (args.length == 0) return adminHelp(sender);
        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> reload(sender);
            case "boss" -> bossAdmin(sender, args);
            case "tokens" -> tokenAdmin(sender, args);
            case "voucher" -> voucherAdmin(sender, args);
            case "cosmetic" -> cosmeticAdmin(sender, args);
            case "tag" -> tagAdmin(sender, args);
            case "summoner" -> summonerAdmin(sender, args);
            case "crimson" -> crimsonAdmin(sender, args);
            case "shop" -> shopAdmin(sender, args);
            case "payouts" -> payoutAdmin(sender, args);
            case "deliveries" -> pendingDeliveryAdmin(sender, args);
            case "debug" -> debug(sender);
            default -> adminHelp(sender);
        };
    }

    private boolean adminHelp(CommandSender sender) {
        if (!can(sender, "crimsonprogression.admin")) return denied(sender);
        sender.sendMessage("/cp reload | boss status|reset|recover | tokens give|take|set <player> <amount>");
        sender.sendMessage("/cp voucher give <player> <reward> | cosmetic give <player> <id>");
        sender.sendMessage("/cp tag grant <player> <id> | summoner give <player> <id> | crimson give <player> <piece>");
        sender.sendMessage("/cp shop deliver|review|retry|markcompleted | payouts review|retry|markpaid");
        sender.sendMessage("/cp deliveries review|retry|markcompleted | debug");
        return true;
    }

    private boolean reload(CommandSender sender) {
        if (!can(sender, "crimsonprogression.admin.reload")) return denied(sender);
        try {
            plugin.reloadFeatureConfigs();
            sender.sendMessage("Reloadable configuration reloaded. Database, secrets and integration dependencies require restart.");
        } catch (Exception exception) {
            plugin.fail(sender, "reload", exception);
        }
        return true;
    }

    private boolean bossAdmin(CommandSender sender, String[] args) {
        if (args.length < 2 || plugin.bossManager() == null) return false;
        if ("status".equalsIgnoreCase(args[1])) {
            if (!can(sender, "crimsonprogression.admin.boss.status")) return denied(sender);
            return bossFight(sender);
        }
        if ("reset".equalsIgnoreCase(args[1])) {
            if (!can(sender, "crimsonprogression.admin.boss.reset")) return denied(sender);
            plugin.bossManager().reset(true);
            sender.sendMessage("Boss fight reset requested.");
            return true;
        }
        if ("recover".equalsIgnoreCase(args[1])) {
            if (!can(sender, "crimsonprogression.admin.boss.recover")) return denied(sender);
            boolean started = plugin.bossManager().recover();
            sender.sendMessage(started
                    ? "Boss recovery retry started."
                    : "Boss recovery was not started because a fight or transition is already active.");
            return true;
        }
        return false;
    }

    private boolean tokenAdmin(CommandSender sender, String[] args) {
        if (args.length != 4) return false;
        String operation = args[1].toLowerCase(Locale.ROOT);
        if (!Set.of("give", "take", "set").contains(operation)) return false;
        if (!can(sender, "crimsonprogression.admin.tokens." + operation)) return denied(sender);
        OfflinePlayer target = resolveCached(args[2]);
        if (target == null) {
            sender.sendMessage("Player is not online or cached. Use a UUID for known offline players.");
            return true;
        }
        double amount;
        try { amount = Double.parseDouble(args[3]); }
        catch (NumberFormatException exception) { sender.sendMessage("Invalid amount."); return true; }
        if (!Double.isFinite(amount) || amount < 0) {
            sender.sendMessage("Amount must be finite and non-negative.");
            return true;
        }
        CompletableFuture<Boolean> future = switch (operation) {
            case "give" -> plugin.tokenService().give(target.getUniqueId(), amount);
            case "take" -> plugin.tokenService().take(target.getUniqueId(), amount);
            case "set" -> plugin.tokenService().set(target.getUniqueId(), amount);
            default -> throw new IllegalStateException();
        };
        future.whenComplete((success, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "token-admin", error);
            else sender.sendMessage(success ? "Token operation completed." : "Token operation rejected by ExcellentEconomy.");
        }));
        return true;
    }

    private boolean voucherAdmin(CommandSender sender, String[] args) {
        if (args.length != 4 || !"give".equalsIgnoreCase(args[1])) return false;
        if (!can(sender, "crimsonprogression.admin.voucher.give")) return denied(sender);
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) { sender.sendMessage("Player must be online."); return true; }
        plugin.voucherService().issue(args[3], target.getUniqueId()).whenComplete((item, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "voucher-give", error);
            else deliverOrQueue(sender, target, item, "VOUCHER", "Voucher issued.", "voucher-give-delivery");
        }));
        return true;
    }

    private boolean cosmeticAdmin(CommandSender sender, String[] args) {
        if (args.length != 4 || !"give".equalsIgnoreCase(args[1])) return false;
        if (!can(sender, "crimsonprogression.admin.cosmetic.give")) return denied(sender);
        OfflinePlayer target = resolveCached(args[2]);
        if (target == null) { sender.sendMessage("Unknown cached player."); return true; }
        plugin.cosmeticService().grant(target.getUniqueId(), args[3], "ADMIN").whenComplete((success, error) ->
                main(() -> sender.sendMessage(error == null && success ? "Cosmetic granted." : "Cosmetic grant failed.")));
        return true;
    }

    private boolean tagAdmin(CommandSender sender, String[] args) {
        if (args.length != 4 || !"grant".equalsIgnoreCase(args[1])) return false;
        if (!can(sender, "crimsonprogression.admin.tag.grant")) return denied(sender);
        OfflinePlayer target = resolveCached(args[2]);
        if (target == null) { sender.sendMessage("Unknown cached player."); return true; }
        plugin.tagService().grant(target.getUniqueId(), args[3], "ADMIN").whenComplete((success, error) ->
                main(() -> sender.sendMessage(error == null && success ? "Tag granted." : "Tag grant failed.")));
        return true;
    }

    private boolean summonerAdmin(CommandSender sender, String[] args) {
        if (args.length != 4 || !"give".equalsIgnoreCase(args[1]) || plugin.bossManager() == null) return false;
        if (!can(sender, "crimsonprogression.admin.summoner.give")) return denied(sender);
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) { sender.sendMessage("Player must be online."); return true; }
        Optional<ItemStack> item = plugin.bossManager().summoners().create(args[3]);
        if (item.isEmpty()) { sender.sendMessage("Unknown summoner or MythicMobs item."); return true; }
        deliverOrQueue(sender, target, item.get(), "SUMMONER",
                "Secure summoner delivered.", "summoner-give-delivery");
        return true;
    }

    private boolean crimsonAdmin(CommandSender sender, String[] args) {
        if (args.length != 4 || !"give".equalsIgnoreCase(args[1])) return false;
        if (!can(sender, "crimsonprogression.admin.crimson.give")) return denied(sender);
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) { sender.sendMessage("Player must be online."); return true; }
        Optional<ItemStack> item = plugin.crimsonArmorService().create(args[3]);
        if (item.isEmpty()) { sender.sendMessage("Unknown Crimson piece."); return true; }
        deliverOrQueue(sender, target, item.get(), "CRIMSON_ARMOR",
                "Crimson armor delivered.", "crimson-give-delivery");
        return true;
    }

    /** Reports success only after the item is in inventory or durably queued in SQLite. */
    private void deliverOrQueue(CommandSender sender, Player target, ItemStack item,
                                String deliveryType, String successMessage, String operation) {
        try {
            if (plugin.pendingDeliveries().tryDeliverNow(target, item)) {
                sender.sendMessage(successMessage);
                return;
            }
        } catch (RuntimeException deliveryError) {
            plugin.getLogger().log(Level.WARNING,
                    "Immediate admin delivery failed; attempting durable queue for "
                            + target.getUniqueId() + " [" + deliveryType + "]", deliveryError);
        }

        plugin.pendingDeliveries().queueItem(target.getUniqueId(), item, deliveryType)
                .whenComplete((ignored, queueError) -> main(() -> {
                    if (queueError != null) {
                        plugin.fail(sender, operation, queueError);
                        return;
                    }
                    sender.sendMessage(successMessage + " Inventory was full, so it was queued for delivery.");
                    if (target.isOnline()) plugin.pendingDeliveries().deliverOnJoin(target);
                }));
    }

    private boolean shopAdmin(CommandSender sender, String[] args) {
        if (args.length < 2) return false;
        return switch (args[1].toLowerCase(Locale.ROOT)) {
            case "deliver" -> shopDeliver(sender, args);
            case "review" -> shopReview(sender);
            case "retry" -> shopTransition(sender, args, false);
            case "markcompleted" -> shopTransition(sender, args, true);
            default -> false;
        };
    }

    private boolean shopDeliver(CommandSender sender, String[] args) {
        if (args.length != 4) return false;
        if (!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage("This ExcellentShop delivery command is console-only.");
            return true;
        }
        OfflinePlayer target = resolveCached(args[2]);
        if (target == null) {
            sender.sendMessage("Delivery rejected: the player name is not cached. Configure ExcellentShop to pass the player UUID when supported.");
            return true;
        }
        plugin.shopDeliveryService().deliver(target.getUniqueId(), args[3]).whenComplete((result, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "shop-delivery", error);
            else sender.sendMessage("Delivery " + (result.success() ? "accepted" : "rejected")
                    + " [" + result.transactionId() + "]: " + result.message());
        }));
        return true;
    }

    private boolean shopReview(CommandSender sender) {
        if (!can(sender, "crimsonprogression.admin.shop.reconcile")) return denied(sender);
        plugin.shopDeliveryService().reviewRequired().whenComplete((rows, error) -> main(() -> {
            if (error != null) { plugin.fail(sender, "shop-review", error); return; }
            sender.sendMessage("ExcellentShop deliveries requiring review: " + rows.size());
            rows.stream().limit(20).forEach(row -> sender.sendMessage(row.transactionId() + " player="
                    + row.playerId() + " product=" + row.productId() + " attempts=" + row.attempts()
                    + " error=" + row.lastError()));
        }));
        return true;
    }

    private boolean shopTransition(CommandSender sender, String[] args, boolean complete) {
        if (args.length != 3) return false;
        if (!can(sender, "crimsonprogression.admin.shop.reconcile")) return denied(sender);
        UUID id = parseUuid(sender, args[2]);
        if (id == null) return true;
        CompletableFuture<Boolean> action = complete
                ? plugin.shopDeliveryService().markCompleted(id)
                : plugin.shopDeliveryService().retry(id);
        action.whenComplete((changed, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "shop-reconcile", error);
            else sender.sendMessage(changed ? "Delivery state updated." : "No matching REVIEW_REQUIRED delivery.");
        }));
        return true;
    }

    private boolean pendingDeliveryAdmin(CommandSender sender, String[] args) {
        if (args.length < 2) return false;
        if (!can(sender, "crimsonprogression.admin.deliveries.reconcile")) return denied(sender);
        return switch (args[1].toLowerCase(Locale.ROOT)) {
            case "review" -> pendingDeliveryReview(sender);
            case "retry" -> pendingDeliveryTransition(sender, args, false);
            case "markcompleted" -> pendingDeliveryTransition(sender, args, true);
            default -> false;
        };
    }

    private boolean pendingDeliveryReview(CommandSender sender) {
        plugin.pendingDeliveries().reviewRequired().whenComplete((rows, error) -> main(() -> {
            if (error != null) { plugin.fail(sender, "pending-delivery-review", error); return; }
            sender.sendMessage("Inventory deliveries requiring review: " + rows.size());
            rows.stream().limit(20).forEach(row -> sender.sendMessage(row.id() + " player="
                    + row.playerId() + " type=" + row.type() + " attempts=" + row.attempts()
                    + " error=" + row.lastError()));
        }));
        return true;
    }

    private boolean pendingDeliveryTransition(CommandSender sender, String[] args, boolean complete) {
        if (args.length != 3) return false;
        UUID id = parseUuid(sender, args[2]);
        if (id == null) return true;
        CompletableFuture<Boolean> action = complete
                ? plugin.pendingDeliveries().markCompleted(id)
                : plugin.pendingDeliveries().retry(id);
        action.whenComplete((changed, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "pending-delivery-reconcile", error);
            else sender.sendMessage(changed ? "Delivery state updated." : "No matching REVIEW_REQUIRED delivery.");
        }));
        return true;
    }

    private boolean payoutAdmin(CommandSender sender, String[] args) {
        if (args.length < 2) return false;
        if (!can(sender, "crimsonprogression.admin.payouts.reconcile")) return denied(sender);
        return switch (args[1].toLowerCase(Locale.ROOT)) {
            case "review" -> payoutReview(sender);
            case "retry" -> payoutTransition(sender, args, false);
            case "markpaid" -> payoutTransition(sender, args, true);
            default -> false;
        };
    }

    private boolean payoutReview(CommandSender sender) {
        plugin.tokenPayoutService().reviewRequired().whenComplete((rows, error) -> main(() -> {
            if (error != null) { plugin.fail(sender, "payout-review", error); return; }
            sender.sendMessage("Token payouts requiring review: " + rows.size());
            rows.stream().limit(20).forEach(row -> sender.sendMessage(row.payoutId() + " player="
                    + row.playerId() + " amount=" + row.amount() + " place=" + row.placement()
                    + " attempts=" + row.attempts() + " error=" + row.lastError()));
        }));
        return true;
    }

    private boolean payoutTransition(CommandSender sender, String[] args, boolean paid) {
        if (args.length != 3) return false;
        UUID id = parseUuid(sender, args[2]);
        if (id == null) return true;
        CompletableFuture<Boolean> action = paid
                ? plugin.tokenPayoutService().markPaid(id)
                : plugin.tokenPayoutService().retry(id);
        action.whenComplete((changed, error) -> main(() -> {
            if (error != null) plugin.fail(sender, "payout-reconcile", error);
            else {
                sender.sendMessage(changed ? "Payout state updated." : "No matching REVIEW_REQUIRED payout.");
                if (changed && !paid) plugin.tokenPayoutService().processPending();
            }
        }));
        return true;
    }

    private boolean debug(CommandSender sender) {
        if (!can(sender, "crimsonprogression.admin.debug")) return denied(sender);
        sender.sendMessage("ready=" + plugin.ready());
        sender.sendMessage("bosses=" + (plugin.bossManager() != null));
        sender.sendMessage("tokens=" + plugin.tokenService().available());
        sender.sendMessage("tags=" + plugin.tagService().definitionIds().size());
        sender.sendMessage("cosmetics=" + plugin.cosmeticService().ids().size());
        sender.sendMessage("shopProducts=" + plugin.shopDeliveryService().productIds().size());
        return true;
    }

    private boolean can(CommandSender sender, String permission) {
        return sender.hasPermission(permission) || sender.hasPermission("crimsonprogression.admin");
    }

    private boolean denied(CommandSender sender) {
        plugin.messages().send(sender, "no-permission");
        return true;
    }

    private boolean playerOnly(CommandSender sender) {
        sender.sendMessage("Player-only command.");
        return true;
    }

    private void main(Runnable action) {
        Bukkit.getScheduler().runTask(plugin, action);
    }

    private static UUID parseUuid(CommandSender sender, String input) {
        try { return UUID.fromString(input); }
        catch (IllegalArgumentException exception) { sender.sendMessage("Invalid UUID."); return null; }
    }

    private static OfflinePlayer resolveCached(String input) {
        try { return Bukkit.getOfflinePlayer(UUID.fromString(input)); }
        catch (IllegalArgumentException ignored) {
            Player online = Bukkit.getPlayerExact(input);
            if (online != null) return online;
            return Bukkit.getOfflinePlayerIfCached(input);
        }
    }

    private static String format(double amount) {
        return Math.rint(amount) == amount ? Long.toString((long) amount) : String.format(Locale.US, "%.2f", amount);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (("tag".equals(name) || "cosmetic".equals(name)) && args.length == 1 && sender instanceof Player player && plugin.ready()) {
            List<String> values = new ArrayList<>("tag".equals(name)
                    ? plugin.tagService().owned(player.getUniqueId())
                    : plugin.cosmeticService().owned(player.getUniqueId()));
            values.add("clear");
            return filter(values, args[0]);
        }
        if (!"crimsonprogression".equals(name)) return List.of();
        if (args.length == 1) return filter(List.of("reload", "boss", "tokens", "voucher", "cosmetic", "tag",
                "summoner", "crimson", "shop", "payouts", "deliveries", "debug"), args[0]);
        if (args.length == 2) {
            return switch (args[0].toLowerCase(Locale.ROOT)) {
                case "boss" -> filter(List.of("status", "reset", "recover"), args[1]);
                case "tokens" -> filter(List.of("give", "take", "set"), args[1]);
                case "voucher", "cosmetic", "summoner", "crimson" -> filter(List.of("give"), args[1]);
                case "tag" -> filter(List.of("grant"), args[1]);
                case "shop" -> filter(List.of("deliver", "review", "retry", "markcompleted"), args[1]);
                case "payouts" -> filter(List.of("review", "retry", "markpaid"), args[1]);
                case "deliveries" -> filter(List.of("review", "retry", "markcompleted"), args[1]);
                default -> List.of();
            };
        }
        if (args.length == 4 && "voucher".equalsIgnoreCase(args[0])) return filter(plugin.voucherService().ids(), args[3]);
        if (args.length == 4 && "cosmetic".equalsIgnoreCase(args[0])) return filter(plugin.cosmeticService().ids(), args[3]);
        if (args.length == 4 && "tag".equalsIgnoreCase(args[0])) return filter(plugin.tagService().definitionIds(), args[3]);
        if (args.length == 4 && "summoner".equalsIgnoreCase(args[0])) return filter(plugin.bossDefinitions().keySet(), args[3]);
        if (args.length == 4 && "crimson".equalsIgnoreCase(args[0])) return filter(List.of("helmet", "chestplate", "leggings", "boots"), args[3]);
        if (args.length == 4 && "shop".equalsIgnoreCase(args[0])) return filter(plugin.shopDeliveryService().productIds(), args[3]);
        return List.of();
    }

    private static List<String> filter(Collection<String> values, String prefix) {
        String normalized = prefix.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(normalized)).sorted().toList();
    }
}
