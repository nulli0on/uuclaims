package dev.crimsonprogression.boss;
public record BossDefinition(String summonerId,String mythicItemId,String mythicMobId,String displayName) {}
