package dev.crimsonprogression.boss;

import dev.crimsonprogression.database.DatabaseService;
import org.bukkit.inventory.ItemStack;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Durable summoner escrow with guarded, idempotent state transitions. */
public final class EscrowRepository {
    private final DatabaseService database;

    public EscrowRepository(DatabaseService database) {
        this.database = database;
    }

    /**
     * Reserves a summoner before it is removed from the player's inventory.
     *
     * <p>Signed summoners carry a nonce. The database enforces that a nonce can
     * only have one live or permanently consumed escrow, so cloned item data
     * cannot start another fight. Legacy summoners have no nonce and are only
     * accepted when the explicit migration setting is enabled.</p>
     */
    public CompletableFuture<Optional<UUID>> createWithFight(ActiveFight fight, UUID playerId,
                                                              String summonerId, UUID summonerNonce,
                                                              int slot, ItemStack item) {
        UUID escrowId = UUID.randomUUID();
        byte[] bytes = item.serializeAsBytes();
        String fingerprint = HexFormat.of().formatHex(hash(bytes));
        return database.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT OR IGNORE INTO summoner_escrow(escrow_uuid,fight_uuid,player_uuid,summoner_id,"
                            + "summoner_nonce,item_blob,inventory_slot,item_fingerprint,state,created_at) "
                            + "VALUES(?,?,?,?,?,?,?,?, 'PENDING_REMOVAL',?)")) {
                statement.setString(1, escrowId.toString());
                statement.setString(2, fight.fightId().toString());
                statement.setString(3, playerId.toString());
                statement.setString(4, summonerId);
                if (summonerNonce == null) statement.setNull(5, java.sql.Types.VARCHAR);
                else statement.setString(5, summonerNonce.toString());
                statement.setBytes(6, bytes);
                statement.setInt(7, slot);
                statement.setString(8, fingerprint);
                statement.setLong(9, System.currentTimeMillis());
                if (statement.executeUpdate() != 1) return Optional.empty();
            }
            FightRepository.insertEscrowFightSync(
                    connection, fight, dev.crimsonprogression.core.FightState.ESCROW_PENDING.name(), 0L);
            return Optional.of(escrowId);
        });
    }

    public CompletableFuture<Void> markRemoved(UUID id) {
        return transition(id, "PENDING_REMOVAL", "REMOVED", false);
    }

    /** Cancels an untouched escrow and removes its pre-spawn singleton fight atomically. */
    public CompletableFuture<Void> cancelIntact(UUID fightId, UUID escrowId) {
        return database.transaction(connection -> {
            int changed;
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE summoner_escrow SET state='CANCELLED',resolved_at=? "
                            + "WHERE escrow_uuid=? AND fight_uuid=? AND state='PENDING_REMOVAL'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, escrowId.toString());
                statement.setString(3, fightId.toString());
                changed = statement.executeUpdate();
            }
            if (changed != 1 && !hasState(connection, escrowId, "CANCELLED")) {
                throw new SQLException("Escrow was not cancellable: " + escrowId);
            }
            deleteFight(connection, fightId);
            return null;
        });
    }

    /**
     * Deletes the fight row and moves its latest summoner escrow to REFUND_PENDING in one
     * SQLite transaction. CONSUMED is intentionally refundable when restart recovery proves
     * that the persisted boss entity no longer exists.
     */
    public CompletableFuture<Optional<Escrow>> prepareRefundForFight(UUID fightId) {
        return database.transaction(connection -> {
            Optional<Escrow> optional = findForFight(connection, fightId);
            deleteFight(connection, fightId);
            if (optional.isEmpty()) return Optional.empty();

            Escrow row = optional.get();
            if ("REFUNDED".equals(row.state())) return optional;
            if ("CANCELLED".equals(row.state()) || "REVIEW_REQUIRED".equals(row.state())) {
                throw new SQLException("Escrow cannot be automatically refunded from state "
                        + row.state() + ": " + row.id());
            }

            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE summoner_escrow SET state='REFUND_PENDING',resolved_at=NULL "
                            + "WHERE escrow_uuid=? AND state IN "
                            + "('PENDING_REMOVAL','REMOVED','CONSUMED','REFUND_PENDING')")) {
                statement.setString(1, row.id().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Escrow refund transition failed: " + row.id());
                }
            }
            return Optional.of(new Escrow(row.id(), row.fightId(), row.player(), row.summonerId(),
                    row.item(), row.slot(), row.fingerprint(), "REFUND_PENDING"));
        });
    }

    /** Marks a refund complete only after the deterministic pending-delivery row exists. */
    public CompletableFuture<Void> completeRefund(UUID id) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE summoner_escrow SET state='REFUNDED',resolved_at=? "
                            + "WHERE escrow_uuid=? AND state='REFUND_PENDING'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, id.toString());
                if (statement.executeUpdate() == 1 || hasState(connection, id, "REFUNDED")) return null;
            }
            throw new SQLException("Escrow was not refund-pending: " + id);
        });
    }

    /** Deletes a fight and permanently consumes its escrow without issuing a refund. */
    public CompletableFuture<Void> forfeitForFight(UUID fightId) {
        return database.transaction(connection -> {
            Optional<Escrow> optional = findForFight(connection, fightId);
            deleteFight(connection, fightId);
            if (optional.isEmpty()) return null;

            Escrow row = optional.get();
            if ("FORFEITED".equals(row.state())) return null;
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE summoner_escrow SET state='FORFEITED',resolved_at=? "
                            + "WHERE escrow_uuid=? AND state IN ('PENDING_REMOVAL','REMOVED','CONSUMED')")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, row.id().toString());
                if (statement.executeUpdate() == 1) return null;
            }
            throw new SQLException("Escrow cannot be forfeited from state " + row.state() + ": " + row.id());
        });
    }

    public CompletableFuture<Optional<Escrow>> findForFight(UUID fightId) {
        return database.submit(connection -> findForFight(connection, fightId));
    }

    public CompletableFuture<List<Escrow>> unresolvedForPlayer(UUID playerId) {
        return database.submit(connection -> {
            List<Escrow> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM summoner_escrow WHERE player_uuid=? "
                            + "AND state IN ('PENDING_REMOVAL','REMOVED','REFUND_PENDING') ORDER BY created_at")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) rows.add(read(result));
                }
            }
            return List.copyOf(rows);
        });
    }

    private CompletableFuture<Void> transition(UUID id, String expected, String next, boolean terminal) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE summoner_escrow SET state=?,resolved_at=? WHERE escrow_uuid=? AND state=?")) {
                statement.setString(1, next);
                if (terminal) statement.setLong(2, System.currentTimeMillis());
                else statement.setNull(2, java.sql.Types.BIGINT);
                statement.setString(3, id.toString());
                statement.setString(4, expected);
                if (statement.executeUpdate() == 1 || hasState(connection, id, next)) return null;
            }
            throw new SQLException("Escrow transition " + expected + " -> " + next + " failed: " + id);
        });
    }

    private static Optional<Escrow> findForFight(Connection connection, UUID fightId) throws Exception {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM summoner_escrow WHERE fight_uuid=? ORDER BY created_at DESC LIMIT 1")) {
            statement.setString(1, fightId.toString());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? Optional.of(read(result)) : Optional.empty();
            }
        }
    }

    private static boolean hasState(Connection connection, UUID id, String state) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT 1 FROM summoner_escrow WHERE escrow_uuid=? AND state=?")) {
            statement.setString(1, id.toString());
            statement.setString(2, state);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private static void deleteFight(Connection connection, UUID fightId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "DELETE FROM active_fights WHERE fight_uuid=?")) {
            statement.setString(1, fightId.toString());
            statement.executeUpdate();
        }
    }

    private static Escrow read(ResultSet result) throws Exception {
        return new Escrow(
                UUID.fromString(result.getString("escrow_uuid")),
                UUID.fromString(result.getString("fight_uuid")),
                UUID.fromString(result.getString("player_uuid")),
                result.getString("summoner_id"),
                ItemStack.deserializeBytes(result.getBytes("item_blob")),
                result.getInt("inventory_slot"),
                result.getString("item_fingerprint"),
                result.getString("state"));
    }

    private static byte[] hash(byte[] bytes) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(bytes);
        } catch (Exception exception) {
            throw new IllegalStateException(exception);
        }
    }

    public record Escrow(UUID id, UUID fightId, UUID player, String summonerId, ItemStack item,
                         int slot, String fingerprint, String state) {}
}
