package dev.crimsonprogression;

import dev.crimsonprogression.boss.*;
import dev.crimsonprogression.command.CrimsonCommand;
import dev.crimsonprogression.config.ConfigFiles;
import dev.crimsonprogression.cosmetic.CosmeticService;
import dev.crimsonprogression.cosmetic.CosmeticListener;
import dev.crimsonprogression.crimson.*;
import dev.crimsonprogression.database.DatabaseService;
import dev.crimsonprogression.delivery.PendingDeliveryService;
import dev.crimsonprogression.discord.CoreDscNotifier;
import dev.crimsonprogression.integration.*;
import dev.crimsonprogression.listener.PlayerLifecycleListener;
import dev.crimsonprogression.listener.SummonerListener;
import dev.crimsonprogression.message.MessageService;
import dev.crimsonprogression.placeholder.CrimsonPlaceholderExpansion;
import dev.crimsonprogression.security.SecretManager;
import dev.crimsonprogression.shop.ShopDeliveryService;
import dev.crimsonprogression.spawn.ArenaSpawnListener;
import dev.crimsonprogression.tag.TagService;
import dev.crimsonprogression.token.*;
import dev.crimsonprogression.voucher.*;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

public final class CrimsonProgressionPlugin extends JavaPlugin {
    private final AtomicBoolean ready = new AtomicBoolean();

    private ConfigFiles configFiles;
    private Keys keys;
    private MessageService messages;
    private DatabaseService database;
    private dev.crimsonprogression.core.HmacSigner signer;

    private MythicMobsHook mythicMobs;
    private ExcellentEconomyHook excellentEconomy;
    private ExcellentCratesHook excellentCrates;
    private LuckPermsHook luckPerms;
    private UltimateClaimsHook ultimateClaims;

    private PendingDeliveryService pendingDeliveries;
    private TokenService tokenService;
    private TokenPayoutService tokenPayoutService;
    private TagService tagService;
    private CosmeticService cosmeticService;
    private VoucherService voucherService;
    private CrimsonArmorService crimsonArmorService;
    private ShopDeliveryService shopDeliveryService;
    private CoreDscNotifier discord;
    private BossManager bossManager;
    private ArenaSpawnListener arenaSpawnListener;
    private Map<String, BossDefinition> bossDefinitions = Map.of();
    private BukkitTask armorTask;
    private BukkitTask payoutTask;
    private BukkitTask shopDeliveryTask;

    @Override
    public void onEnable() {
        try {
            saveDefaultConfig();
            configFiles = new ConfigFiles(this);
            configFiles.loadAll("messages.yml", "bosses.yml", "vouchers.yml", "tags.yml",
                    "cosmetics.yml", "crimson.yml", "discord.yml", "spawns.yml", "shop-products.yml");
            messages = new MessageService(configFiles.get("messages.yml"));
            keys = Keys.create(this);
            registerCommands();

            Path secretFile = dataPath(
                    getConfig().getString("security.hmac-secret-file", "data/secret.key"),
                    "data/secret.key");
            signer = SecretManager.loadOrCreate(secretFile,
                    getConfig().getInt("security.minimum-secret-bytes", 32));

            Path databaseFile = dataPath(
                    getConfig().getString("database.file", "data/progression.db"),
                    "data/progression.db");
            database = new DatabaseService(this, databaseFile,
                    getConfig().getInt("database.executor-threads", 1));
            database.initialize(
                    getConfig().getInt("database.busy-timeout-millis", 10_000),
                    getConfig().getBoolean("database.backup-before-migration", true)
            ).whenComplete((ignored, error) -> Bukkit.getScheduler().runTask(this, () -> {
                if (error != null) {
                    getLogger().log(Level.SEVERE, "Database initialization failed; plugin is disabled safely.", error);
                    Bukkit.getPluginManager().disablePlugin(this);
                    return;
                }
                bootstrap();
            }));
        } catch (Exception exception) {
            getLogger().log(Level.SEVERE, "CrimsonProgression startup failed safely.", exception);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    private void bootstrap() {
        try {
            hookIntegrations();

            pendingDeliveries = new PendingDeliveryService(this, database);
            tokenService = new TokenService(excellentEconomy);
            tokenPayoutService = new TokenPayoutService(database, excellentEconomy, getLogger(),
                    getConfig().getInt("delivery.token-payout-max-automatic-attempts", 5));
            tagService = new TagService(this, database, luckPerms);
            cosmeticService = new CosmeticService(this, database);
            voucherService = new VoucherService(this, database, pendingDeliveries, signer);
            crimsonArmorService = new CrimsonArmorService(this);
            shopDeliveryService = new ShopDeliveryService(this, database, excellentCrates, luckPerms, ultimateClaims);
            discord = new CoreDscNotifier(this, signer);

            if (mythicMobs != null && getConfig().getBoolean("features.bosses", true)) {
                bossDefinitions = loadBossDefinitions();
                SummonerService summoners = new SummonerService(
                        keys, signer, mythicMobs, bossDefinitions,
                        bossConfig().getBoolean("legacy-summoners.enabled", false),
                        bossConfig().getBoolean("legacy-summoners.require-exact-mythic-item-match", true),
                        bossConfig().getBoolean("legacy-summoners.allow-name-lore-only-fallback", false));
                FightRepository fights = new FightRepository(database);
                EscrowRepository escrow = new EscrowRepository(database);
                bossManager = new BossManager(this, fights, escrow, pendingDeliveries, mythicMobs,
                        summoners, tokenPayoutService, loadRewardTable());
            } else {
                getLogger().severe("Boss feature disabled: MythicMobs is missing or bosses are disabled.");
            }

            registerListeners();
            startTasks();

            if (pluginEnabled("PlaceholderAPI")
                    && getConfig().getBoolean("integrations.placeholderapi", true)) {
                new CrimsonPlaceholderExpansion(this).register();
            }

            ready.set(true);
            for (var player : Bukkit.getOnlinePlayers()) {
                tagService.load(player.getUniqueId());
                cosmeticService.load(player.getUniqueId());
                tokenService.refresh(player.getUniqueId());
                voucherService.recoverPlayer(player).whenComplete((ignored, recoveryError) ->
                        Bukkit.getScheduler().runTask(this, () -> {
                            if (recoveryError != null) {
                                getLogger().log(Level.WARNING, "Voucher recovery failed for " + player.getUniqueId(), recoveryError);
                            } else if (player.isOnline()) {
                                pendingDeliveries.deliverOnJoin(player);
                            }
                        }));
            }
            if (bossManager != null) bossManager.recover();
            tokenPayoutService.processPending();
            shopDeliveryService.processPending();
            getLogger().info("CrimsonProgression initialized. Optional integrations are reported by /cp debug.");
        } catch (Exception exception) {
            getLogger().log(Level.SEVERE, "Feature bootstrap failed safely.", exception);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    private void hookIntegrations() {
        if (pluginEnabled("MythicMobs")) {
            try { mythicMobs = new MythicMobsHook(); }
            catch (Throwable error) { getLogger().log(Level.SEVERE, "MythicMobs hook failed.", error); }
        }
        if (pluginEnabled("ExcellentEconomy")) {
            try { excellentEconomy = ExcellentEconomyHook.hook("tokens"); }
            catch (Throwable error) { getLogger().log(Level.SEVERE, "ExcellentEconomy hook failed.", error); }
        }
        if (pluginEnabled("ExcellentCrates")) {
            try { excellentCrates = new ExcellentCratesHook(); }
            catch (Throwable error) { getLogger().log(Level.WARNING, "ExcellentCrates hook failed.", error); }
        }
        if (pluginEnabled("LuckPerms") && getConfig().getBoolean("integrations.luckperms", true)) {
            try { luckPerms = new LuckPermsHook(); }
            catch (Throwable error) { getLogger().log(Level.WARNING, "LuckPerms hook failed.", error); }
        }
        if (pluginEnabled("UltimateClaims")) {
            try { ultimateClaims = UltimateClaimsHook.hook(); }
            catch (Throwable error) { getLogger().log(Level.WARNING, "UltimateClaims API hook failed.", error); }
        }

        if (excellentEconomy == null) {
            getLogger().severe("ExcellentEconomy currency 'tokens' is unavailable. Token operations and payouts remain pending.");
        }
    }

    private boolean pluginEnabled(String name) {
        Plugin plugin = Bukkit.getPluginManager().getPlugin(name);
        return plugin != null && plugin.isEnabled();
    }

    private void registerCommands() {
        CrimsonCommand command = new CrimsonCommand(this);
        for (String name : List.of("bossfight", "tokens", "tags", "tag", "cosmetics", "cosmetic", "crimsonprogression")) {
            var pluginCommand = getCommand(name);
            if (pluginCommand == null) throw new IllegalStateException("Missing command in plugin.yml: " + name);
            pluginCommand.setExecutor(command);
            pluginCommand.setTabCompleter(command);
        }
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new PlayerLifecycleListener(this), this);
        Bukkit.getPluginManager().registerEvents(new VoucherListener(voucherService), this);
        Bukkit.getPluginManager().registerEvents(new CosmeticListener(cosmeticService), this);

        if (bossManager != null) {
            Bukkit.getPluginManager().registerEvents(new SummonerListener(this), this);
            Bukkit.getPluginManager().registerEvents(
                    new BossCombatListener(this, bossManager, crimsonArmorService), this);
            Bukkit.getPluginManager().registerEvents(
                    new CrimsonArmorListener(this, crimsonArmorService, bossManager), this);
            arenaSpawnListener = new ArenaSpawnListener(this, bossManager, mythicMobs);
            Bukkit.getPluginManager().registerEvents(arenaSpawnListener, this);
        }
    }

    private void startTasks() {
        cosmeticService.start();
        restartArmorTask();
        shopDeliveryTask = Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                () -> shopDeliveryService.processPending().exceptionally(error -> {
                    getLogger().log(Level.WARNING, "Shop delivery retry failed safely.", error);
                    return null;
                }), 240L, 20L * 60L);
        payoutTask = Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                () -> tokenPayoutService.processPending().exceptionally(error -> {
                    getLogger().log(Level.WARNING, "Token payout retry failed safely.", error);
                    return null;
                }), 200L, 20L * 60L);
    }

    @Override
    public void onDisable() {
        ready.set(false);
        if (armorTask != null) armorTask.cancel();
        if (payoutTask != null) payoutTask.cancel();
        if (shopDeliveryTask != null) shopDeliveryTask.cancel();
        if (cosmeticService != null) cosmeticService.stop();
        if (discord != null) discord.close();
        if (bossManager != null) {
            try { bossManager.shutdown(); }
            catch (Exception exception) { getLogger().log(Level.WARNING, "Boss shutdown flush failed.", exception); }
        }
        if (database != null) {
            try { database.close(); }
            catch (Exception exception) { getLogger().log(Level.WARNING, "Database shutdown failed.", exception); }
        }
    }

    public void reloadFeatureConfigs() {
        reloadConfig();
        configFiles.reload();
        messages.reload(configFiles.get("messages.yml"));

        if (bossManager != null) {
            Map<String, BossDefinition> reloadedDefinitions = loadBossDefinitions();
            bossDefinitions = reloadedDefinitions;
            bossManager.reload(
                    loadRewardTable(),
                    reloadedDefinitions,
                    bossConfig().getBoolean("legacy-summoners.enabled", false),
                    bossConfig().getBoolean("legacy-summoners.require-exact-mythic-item-match", true),
                    bossConfig().getBoolean("legacy-summoners.allow-name-lore-only-fallback", false));
        }
        if (arenaSpawnListener != null) arenaSpawnListener.reload();
        if (tagService != null) tagService.reloadDefinitions();
        if (cosmeticService != null) cosmeticService.reloadDefinitions();
        if (voucherService != null) voucherService.reload();
        if (crimsonArmorService != null) {
            crimsonArmorService.reload();
            restartArmorTask();
        }
        if (shopDeliveryService != null) shopDeliveryService.reload();
        if (discord != null) discord.reload();
    }

    private void restartArmorTask() {
        if (armorTask != null) armorTask.cancel();
        armorTask = Bukkit.getScheduler().runTaskTimer(this, crimsonArmorService::refreshEffects,
                1L, Math.max(10L, crimsonConfig().getLong("abilities.effect-refresh-ticks", 40L)));
    }

    private Path dataPath(String configured, String fallback) {
        String value = configured == null || configured.isBlank() ? fallback : configured.trim();
        Path root = getDataFolder().toPath().toAbsolutePath().normalize();
        Path relative = Path.of(value);
        if (relative.isAbsolute()) {
            throw new IllegalArgumentException("Configured data path must be relative to the plugin folder: " + value);
        }
        Path resolved = root.resolve(relative).normalize();
        if (!resolved.startsWith(root)) {
            throw new IllegalArgumentException("Configured data path escapes the plugin folder: " + value);
        }
        return resolved;
    }

    private Map<String, BossDefinition> loadBossDefinitions() {
        ConfigurationSection root = bossConfig().getConfigurationSection("summoners");
        if (root == null) throw new IllegalStateException("bosses.yml has no summoners section");
        Map<String, BossDefinition> definitions = new LinkedHashMap<>();
        for (String id : root.getKeys(false)) {
            String itemId = root.getString(id + ".mythic-item-id");
            String mobId = root.getString(id + ".mythic-mob-id");
            String display = root.getString(id + ".display-name", id);
            if (itemId == null || itemId.isBlank() || mobId == null || mobId.isBlank()) {
                getLogger().severe("Disabled invalid boss summoner definition: " + id);
                continue;
            }
            if (mythicMobs != null && mythicMobs.item(itemId).isEmpty()) {
                getLogger().severe("Disabled boss summoner '" + id
                        + "': MythicMobs item does not exist: " + itemId);
                continue;
            }
            if (mythicMobs != null && !mythicMobs.mobExists(mobId)) {
                getLogger().severe("Disabled boss summoner '" + id
                        + "': MythicMobs mob does not exist: " + mobId);
                continue;
            }
            definitions.put(id, new BossDefinition(id, itemId, mobId, display));
        }
        if (definitions.isEmpty()) throw new IllegalStateException("No valid boss definitions");
        return Map.copyOf(definitions);
    }

    private Map<Integer, Integer> loadRewardTable() {
        ConfigurationSection section = bossConfig().getConfigurationSection("rewards");
        Map<Integer, Integer> rewards = new TreeMap<>();
        if (section != null) {
            for (String key : section.getKeys(false)) {
                try {
                    int place = Integer.parseInt(key);
                    int amount = Math.max(0, section.getInt(key));
                    if (place > 0 && amount > 0) rewards.put(place, amount);
                } catch (NumberFormatException exception) {
                    getLogger().warning("Invalid boss reward placement: " + key);
                }
            }
        }
        return rewards.isEmpty() ? Map.of(1, 250, 2, 150, 3, 100, 4, 60, 5, 40) : Map.copyOf(rewards);
    }

    public void fail(CommandSender target, String operation, Throwable error) {
        String reference = UUID.randomUUID().toString().substring(0, 8);
        getLogger().log(Level.SEVERE, "Operation failed safely [" + operation + "/" + reference + "]", error);
        messages.send(target, "internal-error", Map.of("id", reference));
    }

    public boolean ready() { return ready.get(); }
    public Keys keys() { return keys; }
    public MessageService messages() { return messages; }
    public BossManager bossManager() { return bossManager; }
    public Map<String, BossDefinition> bossDefinitions() { return bossDefinitions; }
    public PendingDeliveryService pendingDeliveries() { return pendingDeliveries; }
    public TokenService tokenService() { return tokenService; }
    public TokenPayoutService tokenPayoutService() { return tokenPayoutService; }
    public TagService tagService() { return tagService; }
    public CosmeticService cosmeticService() { return cosmeticService; }
    public VoucherService voucherService() { return voucherService; }
    public CrimsonArmorService crimsonArmorService() { return crimsonArmorService; }
    public ShopDeliveryService shopDeliveryService() { return shopDeliveryService; }
    public CoreDscNotifier discord() { return discord; }

    public String cachedTokenBalance(UUID playerId) {
        if (tokenService == null) return "0";
        double value = tokenService.cached(playerId);
        return Math.rint(value) == value ? Long.toString((long) value) : String.format(Locale.US, "%.2f", value);
    }

    public YamlConfiguration bossConfig() { return configFiles.get("bosses.yml"); }
    public YamlConfiguration voucherConfig() { return configFiles.get("vouchers.yml"); }
    public YamlConfiguration tagConfig() { return configFiles.get("tags.yml"); }
    public YamlConfiguration cosmeticConfig() { return configFiles.get("cosmetics.yml"); }
    public YamlConfiguration crimsonConfig() { return configFiles.get("crimson.yml"); }
    public YamlConfiguration discordConfig() { return configFiles.get("discord.yml"); }
    public YamlConfiguration spawnConfig() { return configFiles.get("spawns.yml"); }
    public YamlConfiguration shopProductConfig() { return configFiles.get("shop-products.yml"); }
}
