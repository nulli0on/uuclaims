package dev.crimsonprogression.database;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.sql.*;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.logging.Level;

/** A single-writer SQLite service. No database work is executed on the Bukkit main thread. */
public final class DatabaseService implements AutoCloseable {
    private final JavaPlugin plugin;
    private final Path databaseFile;
    private final ExecutorService executor;
    private volatile Connection connection;
    private volatile boolean closing;

    public DatabaseService(JavaPlugin plugin, Path databaseFile, int requestedThreads) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.databaseFile = Objects.requireNonNull(databaseFile, "databaseFile").toAbsolutePath().normalize();
        if (requestedThreads != 1) {
            plugin.getLogger().warning("database.executor-threads=" + requestedThreads
                    + " was ignored. CrimsonProgression uses one serialized SQLite writer for consistency.");
        }
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "CrimsonProgression-DB");
            thread.setDaemon(true);
            thread.setUncaughtExceptionHandler((ignored, error) ->
                    plugin.getLogger().log(Level.SEVERE, "Uncaught database executor error", error));
            return thread;
        });
    }

    public CompletableFuture<Void> initialize(int busyTimeoutMillis, boolean backupBeforeMigrations) {
        return submit(sqlite -> {
            Path parent = databaseFile.getParent();
            if (parent != null) Files.createDirectories(parent);
            configure(sqlite, busyTimeoutMillis);
            if (backupBeforeMigrations && Files.exists(databaseFile) && Files.size(databaseFile) > 0) {
                backupDatabase(sqlite);
            }
            applyMigration(sqlite, 1, "db/migrations/V001__initial.sql");
            applyMigration(sqlite, 2, "db/migrations/V002__global_state_and_recovery.sql");
            applyMigration(sqlite, 3, "db/migrations/V003__voucher_delivery_journal.sql");
            applyMigration(sqlite, 4, "db/migrations/V004__payout_and_shop_recovery.sql");
            applyMigration(sqlite, 5, "db/migrations/V005__summoner_nonce_replay_protection.sql");
            return null;
        });
    }

    public <T> CompletableFuture<T> submit(SqlWork<T> work) {
        Objects.requireNonNull(work, "work");
        if (closing) return CompletableFuture.failedFuture(new IllegalStateException("Database is closing"));
        return CompletableFuture.supplyAsync(() -> {
            try {
                return work.run(connection());
            } catch (Exception exception) {
                throw new CompletionException(exception);
            }
        }, executor);
    }

    public <T> CompletableFuture<T> transaction(SqlWork<T> work) {
        return submit(sqlite -> {
            boolean previousAutoCommit = sqlite.getAutoCommit();
            sqlite.setAutoCommit(false);
            try {
                T result = work.run(sqlite);
                sqlite.commit();
                return result;
            } catch (Exception exception) {
                try {
                    sqlite.rollback();
                } catch (SQLException rollbackFailure) {
                    exception.addSuppressed(rollbackFailure);
                }
                throw exception;
            } finally {
                sqlite.setAutoCommit(previousAutoCommit);
            }
        });
    }

    public CompletableFuture<Void> barrier() {
        return submit(ignored -> null);
    }

    private Connection connection() throws SQLException {
        ensureSqliteDriverLoaded();
        Connection current = connection;
        if (current == null || current.isClosed()) {
            current = DriverManager.getConnection("jdbc:sqlite:" + databaseFile);
            connection = current;
        }
        return current;
    }

    private static volatile boolean driverLoaded;

    private static void ensureSqliteDriverLoaded() throws SQLException {
        if (driverLoaded) return;
        synchronized (DatabaseService.class) {
            if (driverLoaded) return;
            try {
                Class.forName("org.sqlite.JDBC", true, DatabaseService.class.getClassLoader());
                driverLoaded = true;
            } catch (ClassNotFoundException exception) {
                throw new SQLException("Bundled SQLite JDBC driver is missing", exception);
            }
        }
    }

    private static void configure(Connection sqlite, int busyTimeoutMillis) throws SQLException {
        try (Statement statement = sqlite.createStatement()) {
            statement.execute("PRAGMA foreign_keys=ON");
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=FULL");
            statement.execute("PRAGMA busy_timeout=" + Math.max(1_000, busyTimeoutMillis));
            statement.execute("PRAGMA wal_autocheckpoint=1000");
        }
    }

    private void applyMigration(Connection sqlite, int version, String resource) throws Exception {
        try (PreparedStatement statement = sqlite.prepareStatement(
                "CREATE TABLE IF NOT EXISTS schema_version("
                        + "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL, checksum TEXT NOT NULL)")) {
            statement.execute();
        }
        String sql = readResource(resource);
        String checksum = sha256(sql);
        try (PreparedStatement statement = sqlite.prepareStatement(
                "SELECT checksum FROM schema_version WHERE version=?")) {
            statement.setInt(1, version);
            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    String stored = result.getString(1);
                    if (!checksum.equals(stored)) {
                        throw new SQLException("Migration checksum mismatch for version " + version
                                + ": stored=" + stored + ", bundled=" + checksum);
                    }
                    return;
                }
            }
        }

        boolean previousAutoCommit = sqlite.getAutoCommit();
        sqlite.setAutoCommit(false);
        try {
            for (String sqlStatement : splitSql(sql)) {
                if (sqlStatement.isBlank()) continue;
                try (Statement statement = sqlite.createStatement()) {
                    statement.execute(sqlStatement);
                }
            }
            try (PreparedStatement statement = sqlite.prepareStatement(
                    "INSERT INTO schema_version(version,applied_at,checksum) VALUES(?,?,?)")) {
                statement.setInt(1, version);
                statement.setLong(2, System.currentTimeMillis());
                statement.setString(3, checksum);
                statement.executeUpdate();
            }
            sqlite.commit();
        } catch (Exception exception) {
            sqlite.rollback();
            throw exception;
        } finally {
            sqlite.setAutoCommit(previousAutoCommit);
        }
    }

    private String readResource(String name) throws IOException {
        try (InputStream input = plugin.getResource(name)) {
            if (input == null) throw new FileNotFoundException(name);
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static String[] splitSql(String sql) {
        return sql.replace("\r", "").split(";\\s*(?:\\n|$)");
    }

    private void backupDatabase(Connection sqlite) throws SQLException, IOException {
        Path directory = databaseFile.getParent().resolve("backups");
        Files.createDirectories(directory);
        Path target = directory.resolve("progression-" + Instant.now().toEpochMilli() + ".db").toAbsolutePath();
        String escaped = target.toString().replace("'", "''");
        try (Statement statement = sqlite.createStatement()) {
            statement.execute("PRAGMA wal_checkpoint(FULL)");
            statement.execute("VACUUM INTO '" + escaped + "'");
        }
        if (!Files.exists(target) || Files.size(target) == 0) {
            throw new IOException("SQLite migration backup was not created: " + target);
        }
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }

    @Override
    public void close() {
        closing = true;
        executor.shutdown();
        try {
            if (!executor.awaitTermination(15, TimeUnit.SECONDS)) executor.shutdownNow();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
        Connection current = connection;
        if (current != null) {
            try {
                current.close();
            } catch (SQLException exception) {
                plugin.getLogger().log(Level.WARNING, "Could not close SQLite", exception);
            }
        }
    }

    @FunctionalInterface
    public interface SqlWork<T> {
        T run(Connection connection) throws Exception;
    }
}
