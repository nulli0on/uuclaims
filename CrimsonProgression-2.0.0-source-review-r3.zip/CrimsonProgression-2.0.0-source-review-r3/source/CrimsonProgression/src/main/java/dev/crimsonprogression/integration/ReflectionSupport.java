package dev.crimsonprogression.integration;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

final class ReflectionSupport {
    private ReflectionSupport() {}

    static Object invoke(Object target, String method, Object... args) {
        if (target == null) throw new IllegalArgumentException("target");
        Method resolved = find(target instanceof Class<?> type ? type : target.getClass(), method, args);
        try {
            resolved.setAccessible(true);
            return resolved.invoke(target instanceof Class<?> ? null : target, args);
        } catch (IllegalAccessException exception) {
            throw new IllegalStateException("Cannot access " + resolved, exception);
        } catch (InvocationTargetException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            if (cause instanceof Error error) throw error;
            throw new IllegalStateException("Invocation failed: " + resolved, cause);
        }
    }

    static Method find(Class<?> type, String name, Object... args) {
        return Arrays.stream(type.getMethods())
                .filter(method -> method.getName().equals(name))
                .filter(method -> method.getParameterCount() == args.length)
                .filter(method -> compatible(method.getParameterTypes(), args))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No compatible method " + type.getName() + "#" + name));
    }

    private static boolean compatible(Class<?>[] parameters, Object[] args) {
        for (int index = 0; index < parameters.length; index++) {
            if (args[index] == null) continue;
            Class<?> parameter = wrap(parameters[index]);
            if (!parameter.isInstance(args[index])) return false;
        }
        return true;
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == char.class) return Character.class;
        return type;
    }
}
