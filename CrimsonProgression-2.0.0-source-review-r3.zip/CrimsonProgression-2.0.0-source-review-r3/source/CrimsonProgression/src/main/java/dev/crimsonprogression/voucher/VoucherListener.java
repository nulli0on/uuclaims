package dev.crimsonprogression.voucher;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class VoucherListener implements Listener {
    private final VoucherService service;

    public VoucherListener(VoucherService service) {
        this.service = service;
    }

    /** Required redemption method: left-click the voucher inside the player's own inventory. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof org.bukkit.entity.Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != player.getInventory()) return;
        if (!event.isLeftClick()) return;
        ItemStack item = event.getCurrentItem();
        if (!service.validate(item).valid()) return;
        event.setCancelled(true);
        service.claim(player, event.getSlot(), item.clone());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onUse(PlayerInteractEvent event) {
        if (!service.allowRightClick()) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() == null) return;
        ItemStack item = event.getItem();
        if (!service.validate(item).valid()) return;
        event.setCancelled(true);
        int slot = event.getHand() == EquipmentSlot.HAND
                ? event.getPlayer().getInventory().getHeldItemSlot() : 40;
        service.claim(event.getPlayer(), slot, item.clone());
    }
}
