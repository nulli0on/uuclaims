package dev.crimsonprogression.core;
import java.util.*;
public final class InventoryPlanner {
    private InventoryPlanner() {}
    public static boolean fits(List<Slot> storage, List<Stack> rewards) {
        List<Mutable> slots=new ArrayList<>(storage.size());
        for (Slot s:storage) slots.add(s.empty()?new Mutable(null,0,Math.max(1,s.maxStack())):new Mutable(s.key(),s.amount(),s.maxStack()));
        for (Stack reward:rewards) {
            int remaining=reward.amount();
            for (Mutable slot:slots) if (remaining>0 && reward.key().equals(slot.key) && slot.amount<slot.max) { int add=Math.min(remaining,slot.max-slot.amount); slot.amount+=add; remaining-=add; }
            for (Mutable slot:slots) if (remaining>0 && slot.key==null) { slot.key=reward.key(); slot.max=reward.maxStack(); int add=Math.min(remaining,slot.max); slot.amount=add; remaining-=add; }
            if (remaining>0) return false;
        }
        return true;
    }
    public record Slot(String key,int amount,int maxStack) { public boolean empty(){return key==null||amount<=0;} }
    public record Stack(String key,int amount,int maxStack) { public Stack { if(key==null||key.isBlank()||amount<=0||maxStack<=0) throw new IllegalArgumentException(); } }
    private static final class Mutable { String key; int amount; int max; Mutable(String key,int amount,int max){this.key=key;this.amount=amount;this.max=max;} }
}
