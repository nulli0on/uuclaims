package dev.crimsonprogression.security;

import dev.crimsonprogression.core.HmacSigner;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.Base64;

public final class SecretManager {
    private SecretManager() {}

    public static HmacSigner loadOrCreate(Path file, int minimumBytes) throws IOException {
        Path parent = file.getParent();
        if (parent != null) Files.createDirectories(parent);

        byte[] secret;
        if (Files.exists(file)) {
            secret = Base64.getDecoder().decode(Files.readString(file).trim());
        } else {
            secret = new byte[Math.max(32, minimumBytes)];
            new SecureRandom().nextBytes(secret);
            Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(
                    temporary,
                    Base64.getEncoder().encodeToString(secret),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );
            try {
                Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        return new HmacSigner(secret);
    }
}
