package dev.crimsonprogression.delivery;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.core.InventoryPlanner;
import dev.crimsonprogression.database.DatabaseService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/** Durable, all-or-nothing inventory bundles used for refunds and recovery. */
public final class PendingDeliveryService {
    private static final String PAYLOAD_VERSION = "v1";

    private final CrimsonProgressionPlugin plugin;
    private final DatabaseService database;

    public PendingDeliveryService(CrimsonProgressionPlugin plugin, DatabaseService database) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.database = Objects.requireNonNull(database, "database");
    }

    public CompletableFuture<Void> queueItem(UUID playerId, ItemStack item, String type) {
        return queueItems(playerId, List.of(item), type);
    }

    public CompletableFuture<Void> queueItems(UUID playerId, Collection<ItemStack> items, String type) {
        return queueItems(UUID.randomUUID(), playerId, items, type);
    }

    public CompletableFuture<Void> queueItems(UUID deliveryId, UUID playerId,
                                              Collection<ItemStack> items, String type) {
        List<ItemStack> safeItems = copyAndValidate(items);
        return database.submit(connection -> {
            insertIfAbsent(connection, deliveryId, playerId, type, safeItems, "PENDING");
            return null;
        });
    }

    public CompletableFuture<Void> queueItem(UUID deliveryId, UUID playerId, ItemStack item, String type) {
        return queueItems(deliveryId, playerId, List.of(item), type);
    }

    public static void insertIfAbsent(Connection connection, UUID deliveryId, UUID playerId, String type,
                                      Collection<ItemStack> items, String state) throws Exception {
        String payload = encode(copyAndValidate(items));
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT OR IGNORE INTO pending_deliveries(delivery_uuid,player_uuid,delivery_type,payload_json,state,created_at,updated_at) "
                        + "VALUES(?,?,?,?,?,?,?)")) {
            long now = System.currentTimeMillis();
            statement.setString(1, deliveryId.toString());
            statement.setString(2, playerId.toString());
            statement.setString(3, requireType(type));
            statement.setString(4, payload);
            statement.setString(5, state);
            statement.setLong(6, now);
            statement.setLong(7, now);
            statement.executeUpdate();
        }
    }

    public static void insert(Connection connection, UUID deliveryId, UUID playerId, String type,
                              Collection<ItemStack> items, String state) throws Exception {
        String payload = encode(copyAndValidate(items));
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO pending_deliveries(delivery_uuid,player_uuid,delivery_type,payload_json,state,created_at,updated_at) "
                        + "VALUES(?,?,?,?,?,?,?)")) {
            long now = System.currentTimeMillis();
            statement.setString(1, deliveryId.toString());
            statement.setString(2, playerId.toString());
            statement.setString(3, requireType(type));
            statement.setString(4, payload);
            statement.setString(5, state);
            statement.setLong(6, now);
            statement.setLong(7, now);
            statement.executeUpdate();
        }
    }

    public CompletableFuture<List<Delivery>> load(UUID playerId) {
        return database.submit(connection -> {
            List<Delivery> deliveries = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT delivery_uuid,delivery_type,payload_json FROM pending_deliveries "
                            + "WHERE player_uuid=? AND state='PENDING' ORDER BY created_at,delivery_uuid")) {
                statement.setString(1, playerId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        deliveries.add(new Delivery(
                                UUID.fromString(result.getString("delivery_uuid")),
                                result.getString("delivery_type"),
                                decode(result.getString("payload_json"))));
                    }
                }
            }
            return List.copyOf(deliveries);
        });
    }

    public CompletableFuture<Boolean> markDelivered(UUID id) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='DELIVERED',updated_at=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, id.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> cancel(UUID id) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='CANCELLED',updated_at=? "
                            + "WHERE delivery_uuid=? AND state='PENDING'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, id.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> claimForDelivery(UUID id) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='DELIVERING',attempts=attempts+1,last_error=NULL,updated_at=? "
                            + "WHERE delivery_uuid=? AND state='PENDING'")) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, id.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> release(UUID id, String error) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='PENDING',last_error=?,updated_at=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                statement.setString(1, error);
                statement.setLong(2, System.currentTimeMillis());
                statement.setString(3, id.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    /**
     * Moves interrupted non-voucher inventory deliveries to manual review. The
     * external inventory mutation and SQLite cannot share one ACID transaction,
     * so automatically replaying a DELIVERING row could duplicate items.
     */
    public CompletableFuture<Integer> quarantineInterrupted(UUID playerId) {
        return database.submit(connection -> {
            String sql = "UPDATE pending_deliveries SET state='REVIEW_REQUIRED',"
                    + "last_error=COALESCE(last_error,'Server stopped during inventory delivery; verify before retry'),updated_at=? "
                    + "WHERE state='DELIVERING' AND delivery_type<>'VOUCHER_CLAIM'"
                    + (playerId == null ? "" : " AND player_uuid=?");
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setLong(1, System.currentTimeMillis());
                if (playerId != null) statement.setString(2, playerId.toString());
                return statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<List<ReviewEntry>> reviewRequired() {
        return database.submit(connection -> {
            List<ReviewEntry> rows = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT delivery_uuid,player_uuid,delivery_type,attempts,last_error,created_at "
                            + "FROM pending_deliveries WHERE state='REVIEW_REQUIRED' ORDER BY created_at")) {
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) rows.add(new ReviewEntry(
                            UUID.fromString(result.getString(1)), UUID.fromString(result.getString(2)),
                            result.getString(3), result.getInt(4), result.getString(5), result.getLong(6)));
                }
            }
            return List.copyOf(rows);
        });
    }

    public CompletableFuture<Boolean> retry(UUID id) {
        return reviewTransition(id, "PENDING", "Manually approved retry");
    }

    public CompletableFuture<Boolean> markCompleted(UUID id) {
        return reviewTransition(id, "DELIVERED", "Manually confirmed delivered");
    }

    private CompletableFuture<Boolean> reviewTransition(UUID id, String state, String note) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state=?,last_error=?,updated_at=? "
                            + "WHERE delivery_uuid=? AND state='REVIEW_REQUIRED'")) {
                statement.setString(1, state);
                statement.setString(2, note);
                statement.setLong(3, System.currentTimeMillis());
                statement.setString(4, id.toString());
                return statement.executeUpdate() == 1;
            }
        });
    }

    /** Must be called on the Bukkit main thread. The bundle is delivered only when all stacks fit. */
    public boolean tryDeliverNow(Player player, Collection<ItemStack> items) {
        List<ItemStack> safeItems = copyAndValidate(items);
        if (!fits(player, safeItems)) return false;

        // Bukkit inventory mutation cannot participate in the SQLite transaction. Keep a deep
        // storage snapshot so an unexpected partial add can be rolled back synchronously before
        // another event observes the inventory.
        ItemStack[] snapshot = Arrays.stream(player.getInventory().getStorageContents())
                .map(stack -> stack == null ? null : stack.clone())
                .toArray(ItemStack[]::new);
        try {
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(
                    safeItems.stream().map(ItemStack::clone).toArray(ItemStack[]::new));
            if (leftovers.isEmpty()) return true;
            player.getInventory().setStorageContents(snapshot);
            plugin.getLogger().severe("Inventory changed unexpectedly during delivery for " + player.getUniqueId()
                    + "; the storage snapshot was restored and the delivery requires review.");
            return false;
        } catch (RuntimeException error) {
            player.getInventory().setStorageContents(snapshot);
            throw error;
        }
    }

    public boolean tryDeliverNow(Player player, ItemStack item) {
        return tryDeliverNow(player, List.of(item));
    }

    public boolean fits(Player player, Collection<ItemStack> items) {
        List<InventoryPlanner.Slot> slots = Arrays.stream(player.getInventory().getStorageContents())
                .map(stack -> stack == null || stack.getType().isAir()
                        ? new InventoryPlanner.Slot(null, 0, 64)
                        : new InventoryPlanner.Slot(stackKey(stack), stack.getAmount(), stack.getMaxStackSize()))
                .toList();
        List<InventoryPlanner.Stack> incoming = copyAndValidate(items).stream()
                .map(item -> new InventoryPlanner.Stack(stackKey(item), item.getAmount(), item.getMaxStackSize()))
                .toList();
        return InventoryPlanner.fits(slots, incoming);
    }

    public void deliverOnJoin(Player player) {
        UUID playerId = player.getUniqueId();
        quarantineInterrupted(playerId)
                .thenCompose(ignored -> load(playerId))
                .thenCompose(deliveries -> {
                    CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
                    for (Delivery delivery : deliveries) {
                        chain = chain.thenCompose(ignored -> deliverOne(player, delivery));
                    }
                    return chain;
                })
                .exceptionally(error -> {
                    plugin.getLogger().log(Level.WARNING,
                            "Could not process pending deliveries for " + playerId, error);
                    return null;
                });
    }

    private CompletableFuture<Void> deliverOne(Player player, Delivery delivery) {
        return claimForDelivery(delivery.id()).thenCompose(claimed -> {
            if (!claimed) return CompletableFuture.completedFuture(null);
            return onMainThread(() -> {
                if (!player.isOnline()) return DeliveryAttempt.OFFLINE;
                if (!fits(player, delivery.items())) return DeliveryAttempt.NO_SPACE;
                return tryDeliverNow(player, delivery.items())
                        ? DeliveryAttempt.DELIVERED : DeliveryAttempt.AMBIGUOUS;
            }).thenCompose(attempt -> switch (attempt) {
                case DELIVERED -> markDelivered(delivery.id()).thenAccept(closed -> {
                    if (!closed) plugin.getLogger().severe("Delivered bundle but journal did not close: " + delivery.id());
                });
                case OFFLINE, NO_SPACE -> release(delivery.id(), attempt == DeliveryAttempt.OFFLINE
                        ? "Player went offline" : "Insufficient inventory space").thenAccept(ignored -> {});
                case AMBIGUOUS -> markReview(delivery.id(),
                        "Bukkit inventory changed during delivery; verify contents before retry");
            });
        });
    }

    private CompletableFuture<Void> markReview(UUID id, String error) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE pending_deliveries SET state='REVIEW_REQUIRED',last_error=?,updated_at=? "
                            + "WHERE delivery_uuid=? AND state='DELIVERING'")) {
                statement.setString(1, error);
                statement.setLong(2, System.currentTimeMillis());
                statement.setString(3, id.toString());
                statement.executeUpdate();
            }
            return null;
        });
    }

    private <T> CompletableFuture<T> onMainThread(java.util.concurrent.Callable<T> action) {
        if (Bukkit.isPrimaryThread()) {
            try { return CompletableFuture.completedFuture(action.call()); }
            catch (Exception exception) { return CompletableFuture.failedFuture(exception); }
        }
        CompletableFuture<T> future = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> {
            try { future.complete(action.call()); }
            catch (Exception exception) { future.completeExceptionally(exception); }
        });
        return future;
    }

    public static String encode(Collection<ItemStack> items) {
        StringBuilder builder = new StringBuilder(PAYLOAD_VERSION);
        for (ItemStack item : copyAndValidate(items)) {
            builder.append('\n').append(Base64.getEncoder().encodeToString(item.serializeAsBytes()));
        }
        return Base64.getEncoder().encodeToString(builder.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static List<ItemStack> decode(String payload) {
        try {
            String decoded = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            String[] lines = decoded.split("\\n");
            if (lines.length < 2 || !PAYLOAD_VERSION.equals(lines[0])) {
                // Backward compatibility with the original single-stack payload.
                return List.of(ItemStack.deserializeBytes(Base64.getDecoder().decode(payload)));
            }
            List<ItemStack> items = new ArrayList<>();
            for (int index = 1; index < lines.length; index++) {
                if (!lines[index].isBlank()) {
                    items.add(ItemStack.deserializeBytes(Base64.getDecoder().decode(lines[index])));
                }
            }
            return List.copyOf(items);
        } catch (RuntimeException exception) {
            throw new IllegalArgumentException("Invalid pending-delivery payload", exception);
        }
    }

    private static List<ItemStack> copyAndValidate(Collection<ItemStack> items) {
        if (items == null || items.isEmpty()) throw new IllegalArgumentException("Delivery bundle is empty");
        List<ItemStack> copies = new ArrayList<>();
        for (ItemStack item : items) {
            if (item == null || item.getType().isAir() || item.getAmount() <= 0) {
                throw new IllegalArgumentException("Delivery contains an invalid item");
            }
            copies.add(item.clone());
        }
        return List.copyOf(copies);
    }

    private static String requireType(String type) {
        if (type == null || !type.matches("[A-Z0-9_-]{1,64}")) {
            throw new IllegalArgumentException("Invalid delivery type: " + type);
        }
        return type;
    }

    private static String stackKey(ItemStack input) {
        ItemStack copy = input.clone();
        copy.setAmount(1);
        return Base64.getEncoder().encodeToString(copy.serializeAsBytes());
    }

    private enum DeliveryAttempt { DELIVERED, OFFLINE, NO_SPACE, AMBIGUOUS }

    public record ReviewEntry(UUID id, UUID playerId, String type, int attempts, String lastError, long createdAt) {}

    public record Delivery(UUID id, String type, List<ItemStack> items) {
        public Delivery {
            items = List.copyOf(items);
        }
    }
}
