package dev.crimsonprogression.discord;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import dev.crimsonprogression.core.HmacSigner;
import org.bukkit.Bukkit;

import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.regex.Pattern;

/**
 * Writes signed, short-lived boss-start messages for a trusted CoreDSC Python
 * command. CoreDSC itself is not patched or reflected into.
 */
public final class CoreDscNotifier implements AutoCloseable {
    private static final int SCHEMA_VERSION = 1;
    private static final Pattern CHANNEL_ID = Pattern.compile("[0-9]{15,25}");
    private static final Pattern COMMAND = Pattern.compile("[a-z0-9_:-]{1,80}");

    private final CrimsonProgressionPlugin plugin;
    private final HmacSigner signer;
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor(runnable -> {
        Thread thread = new Thread(runnable, "CrimsonProgression-CoreDSC");
        thread.setDaemon(true);
        return thread;
    });
    private final Map<UUID, Integer> attempts = new ConcurrentHashMap<>();

    private volatile Path outbox;
    private volatile String channel;
    private volatile String command;
    private volatile String template;
    private volatile boolean enabled;
    private volatile int maxAttempts;
    private volatile long retryDelaySeconds;
    private volatile long eventLifetimeMillis;

    public CoreDscNotifier(CrimsonProgressionPlugin plugin, HmacSigner signer) {
        this.plugin = plugin;
        this.signer = signer;
        reload();
    }

    public void reload() {
        var config = plugin.discordConfig();
        Path pluginRoot = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        Path configured = pluginRoot.resolve(config.getString("outbox-directory", "data/discord-outbox")).normalize();
        if (!configured.startsWith(pluginRoot)) {
            plugin.getLogger().severe("Discord outbox-directory escapes the CrimsonProgression data folder; integration disabled.");
            enabled = false;
            return;
        }
        this.outbox = configured;
        this.channel = config.getString("channel-id", "").trim();
        this.command = config.getString("command", "coredscpy:crimsonbossstarted").trim().toLowerCase();
        this.template = config.getString("boss-start-message",
                "**Boss Fight Started**\n**<boss>** was summoned by **<player>**.\nUse `/warp bossfight` to participate.");
        this.maxAttempts = Math.max(1, Math.min(20, config.getInt("max-attempts", 3)));
        this.retryDelaySeconds = Math.max(1L, Math.min(300L, config.getLong("retry-delay-seconds", 10L)));
        this.eventLifetimeMillis = Math.max(60_000L,
                Math.min(TimeUnit.HOURS.toMillis(24), config.getLong("event-lifetime-seconds", 600L) * 1000L));
        boolean featureEnabled = plugin.getConfig().getBoolean("features.discord", true);
        boolean integrationEnabled = config.getBoolean("enabled", false);
        this.enabled = featureEnabled
                && integrationEnabled
                && CHANNEL_ID.matcher(channel).matches()
                && COMMAND.matcher(command).matches();

        if (featureEnabled && integrationEnabled && !CHANNEL_ID.matcher(channel).matches()) {
            plugin.getLogger().warning("CoreDSC boss announcement is disabled until discord.yml channel-id is a valid numeric Discord channel ID.");
        }
        if (!COMMAND.matcher(command).matches()) {
            plugin.getLogger().severe("Invalid CoreDSC bridge command in discord.yml; integration disabled.");
        }
        try {
            Files.createDirectories(outbox);
        } catch (Exception exception) {
            enabled = false;
            plugin.getLogger().log(Level.SEVERE, "Could not create Discord outbox", exception);
            return;
        }
        if (enabled) worker.execute(this::dispatchExistingFiles);
    }

    public void bossStarted(String boss, String player) {
        if (!enabled) return;
        UUID eventId = UUID.randomUUID();
        long createdAt = System.currentTimeMillis();
        long expiresAt = createdAt + eventLifetimeMillis;
        String message = template.replace("<boss>", safeTemplateValue(boss))
                .replace("<player>", safeTemplateValue(player));
        String canonical = canonical(eventId, createdAt, expiresAt, channel, message);
        String signature = signer.sign(canonical);
        String json = "{\n"
                + "  \"schema_version\": " + SCHEMA_VERSION + ",\n"
                + "  \"event_uuid\": \"" + eventId + "\",\n"
                + "  \"created_at\": " + createdAt + ",\n"
                + "  \"expires_at\": " + expiresAt + ",\n"
                + "  \"channel_id\": \"" + jsonEscape(channel) + "\",\n"
                + "  \"message\": \"" + jsonEscape(message) + "\",\n"
                + "  \"signature\": \"" + signature + "\"\n"
                + "}\n";
        worker.execute(() -> writeAndDispatch(eventId, json));
    }

    private void writeAndDispatch(UUID eventId, String json) {
        try {
            Path temporary = safeFile(eventId, ".json.tmp");
            Path finalFile = safeFile(eventId, ".json");
            Files.writeString(temporary, json, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            try {
                Files.move(temporary, finalFile, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, finalFile, StandardCopyOption.REPLACE_EXISTING);
            }
            dispatch(eventId);
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING,
                    "CoreDSC boss-start notification could not be journaled safely [" + eventId + "]", exception);
        }
    }

    private void dispatchExistingFiles() {
        try (DirectoryStream<Path> files = Files.newDirectoryStream(outbox, "*.json")) {
            for (Path file : files) {
                String name = file.getFileName().toString();
                try {
                    dispatch(UUID.fromString(name.substring(0, name.length() - 5)));
                } catch (IllegalArgumentException malformed) {
                    plugin.getLogger().warning("Ignoring malformed CoreDSC outbox file: " + name);
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Could not scan CoreDSC outbox", exception);
        }
    }

    private void dispatch(UUID eventId) {
        if (!enabled || !Files.isRegularFile(safeFile(eventId, ".json"))) return;
        int attempt = attempts.merge(eventId, 1, Integer::sum);
        Bukkit.getScheduler().runTask(plugin, () -> {
            boolean accepted = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command + " " + eventId);
            if (accepted) {
                worker.schedule(() -> confirmOrRetry(eventId), retryDelaySeconds, TimeUnit.SECONDS);
                return;
            }
            scheduleRetryOrStop(eventId, attempt, "CoreDSC bridge command was unavailable");
        });
    }

    private void confirmOrRetry(UUID eventId) {
        Path pending = safeFile(eventId, ".json");
        if (!Files.exists(pending)) {
            attempts.remove(eventId);
            return;
        }
        int attempt = attempts.getOrDefault(eventId, 1);
        scheduleRetryOrStop(eventId, attempt, "CoreDSC Python bridge did not acknowledge the outbox file");
    }

    private void scheduleRetryOrStop(UUID eventId, int attempt, String reason) {
        if (attempt >= maxAttempts) {
            attempts.remove(eventId);
            plugin.getLogger().severe(reason + " after " + attempt + " attempts for event " + eventId
                    + ". The signed .json file remains for manual retry.");
            return;
        }
        worker.schedule(() -> dispatch(eventId), retryDelaySeconds, TimeUnit.SECONDS);
    }

    private Path safeFile(UUID eventId, String suffix) {
        Path file = outbox.resolve(eventId + suffix).normalize();
        if (!file.startsWith(outbox)) throw new IllegalStateException("Unsafe Discord outbox path");
        return file;
    }

    private static String canonical(UUID eventId, long createdAt, long expiresAt, String channel, String message) {
        return SCHEMA_VERSION + "\n" + eventId + "\n" + createdAt + "\n" + expiresAt + "\n" + channel + "\n" + message;
    }

    @Override
    public void close() {
        worker.shutdown();
        try {
            if (!worker.awaitTermination(5, TimeUnit.SECONDS)) worker.shutdownNow();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            worker.shutdownNow();
        }
    }

    private static String safeTemplateValue(String value) {
        if (value == null) return "Unknown";
        return value.replace('\r', ' ').replace('\n', ' ').trim();
    }

    private static String jsonEscape(String value) {
        StringBuilder output = new StringBuilder(value.length() + 16);
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            switch (current) {
                case '\\' -> output.append("\\\\");
                case '"' -> output.append("\\\"");
                case '\r' -> output.append("\\r");
                case '\n' -> output.append("\\n");
                case '\t' -> output.append("\\t");
                default -> {
                    if (current < 0x20) output.append(String.format("\\u%04x", (int) current));
                    else output.append(current);
                }
            }
        }
        return output.toString();
    }
}
