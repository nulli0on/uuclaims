package dev.crimsonprogression.core;

import java.util.*;

public final class DamageLedger {
    private final Map<UUID, Entry> entries = new HashMap<>();

    public synchronized double record(UUID playerId, String name, double finalDamage, double healthBefore, long now) {
        Objects.requireNonNull(playerId, "playerId");
        if (!Double.isFinite(finalDamage) || !Double.isFinite(healthBefore) || finalDamage <= 0 || healthBefore <= 0) return 0D;
        double recorded = Math.min(finalDamage, healthBefore);
        Entry current = entries.get(playerId);
        if (current == null) entries.put(playerId, new Entry(playerId, safeName(name), recorded, 1, now, now, false));
        else entries.put(playerId, new Entry(playerId, safeName(name), current.damage + recorded, current.hitCount + 1, current.firstHitAt, now, current.killingBlow));
        return recorded;
    }

    public synchronized void markKillingBlow(UUID playerId) {
        Entry e = entries.get(playerId);
        if (e != null) entries.put(playerId, new Entry(e.playerId, e.lastKnownName, e.damage, e.hitCount, e.firstHitAt, e.lastHitAt, true));
    }

    public synchronized List<Entry> leaderboard() {
        return entries.values().stream().sorted(Comparator.comparingDouble(Entry::damage).reversed()
                .thenComparingLong(Entry::firstHitAt).thenComparing(e -> e.playerId.toString())).toList();
    }

    public synchronized Map<UUID, Entry> snapshot() { return Map.copyOf(entries); }
    public synchronized void restore(Collection<Entry> restored) { entries.clear(); restored.forEach(e -> entries.put(e.playerId, e)); }
    private static String safeName(String value) { return value == null || value.isBlank() ? "Unknown" : value; }

    public record Entry(UUID playerId, String lastKnownName, double damage, int hitCount, long firstHitAt, long lastHitAt, boolean killingBlow) {}
}
