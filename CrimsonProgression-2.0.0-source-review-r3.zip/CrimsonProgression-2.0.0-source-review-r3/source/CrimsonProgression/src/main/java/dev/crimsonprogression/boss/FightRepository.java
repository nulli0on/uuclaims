package dev.crimsonprogression.boss;

import dev.crimsonprogression.core.DamageLedger;
import dev.crimsonprogression.core.FightState;
import dev.crimsonprogression.core.RewardCalculator;
import dev.crimsonprogression.database.DatabaseService;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class FightRepository {
    private static final String DAMAGE_UPSERT = """
            INSERT INTO fight_damage(
                fight_uuid, player_uuid, last_known_name, damage, hit_count,
                first_hit_at, last_hit_at, killing_blow
            ) VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(fight_uuid,player_uuid) DO UPDATE SET
                last_known_name=excluded.last_known_name,
                damage=excluded.damage,
                hit_count=excluded.hit_count,
                first_hit_at=excluded.first_hit_at,
                last_hit_at=excluded.last_hit_at,
                killing_blow=excluded.killing_blow
            """;

    private final DatabaseService database;

    public FightRepository(DatabaseService database) {
        this.database = database;
    }

    public CompletableFuture<Void> insertEscrowFight(
            ActiveFight fight, String state, long cooldownUntil) {
        return database.transaction(connection -> {
            insertEscrowFightSync(connection, fight, state, cooldownUntil);
            return null;
        });
    }

    static void insertEscrowFightSync(Connection connection, ActiveFight fight,
                                      String state, long cooldownUntil) throws SQLException {
        String sql = """
                INSERT INTO active_fights(
                    singleton_key, fight_uuid, mythic_mob_id, display_name,
                    world_name, x, y, z, yaw, pitch, summoner_id,
                    summoner_player_uuid, state, cooldown_until, created_at, updated_at
                ) VALUES(1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            int index = 1;
            statement.setString(index++, fight.fightId().toString());
            statement.setString(index++, fight.definition().mythicMobId());
            statement.setString(index++, fight.definition().displayName());
            statement.setString(index++, fight.world());
            statement.setDouble(index++, fight.x());
            statement.setDouble(index++, fight.y());
            statement.setDouble(index++, fight.z());
            statement.setFloat(index++, fight.yaw());
            statement.setFloat(index++, fight.pitch());
            statement.setString(index++, fight.definition().summonerId());
            statement.setString(index++, fight.summonerPlayer().toString());
            statement.setString(index++, state);
            statement.setLong(index++, cooldownUntil);
            statement.setLong(index++, fight.createdAt());
            statement.setLong(index, System.currentTimeMillis());
            statement.executeUpdate();
        }
    }

    public CompletableFuture<Void> markSpawned(
            ActiveFight fight, long cooldownUntil, UUID escrowId) {
        return database.transaction(connection -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE active_fights
                    SET boss_entity_uuid=?, max_health=?, state='ACTIVE',
                        started_at=?, cooldown_until=?, updated_at=?
                    WHERE fight_uuid=?
                    """)) {
                statement.setString(1, fight.entityId().toString());
                statement.setDouble(2, fight.maxHealth());
                statement.setLong(3, now);
                statement.setLong(4, cooldownUntil);
                statement.setLong(5, now);
                statement.setString(6, fight.fightId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Fight row disappeared");
                }
            }

            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM fight_chunks WHERE fight_uuid=?")) {
                statement.setString(1, fight.fightId().toString());
                statement.executeUpdate();
            }

            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO fight_chunks(fight_uuid,chunk_x,chunk_z) VALUES(?,?,?)")) {
                for (ActiveFight.ChunkCoordinate chunk : fight.chunks()) {
                    statement.setString(1, fight.fightId().toString());
                    statement.setInt(2, chunk.x());
                    statement.setInt(3, chunk.z());
                    statement.addBatch();
                }
                statement.executeBatch();
            }

            saveCooldownSync(connection, cooldownUntil, now);

            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE summoner_escrow
                    SET state='CONSUMED', resolved_at=?
                    WHERE escrow_uuid=? AND fight_uuid=? AND state='REMOVED'
                    """)) {
                statement.setLong(1, now);
                statement.setString(2, escrowId.toString());
                statement.setString(3, fight.fightId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Escrow row was not in REMOVED state");
                }
            }
            return null;
        });
    }

    /**
     * Persists the exact chunk window before the external MythicMobs spawn side
     * effect. A restart can then load those chunks, remove a partially spawned
     * boss by its fight marker, and reconcile the summoner without duplication.
     */
    public CompletableFuture<Void> markSpawning(ActiveFight fight) {
        List<ActiveFight.ChunkCoordinate> chunks = List.copyOf(fight.chunks());
        return database.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE active_fights SET state='SPAWNING',updated_at=?
                    WHERE fight_uuid=? AND state='ESCROW_PENDING'
                    """)) {
                statement.setLong(1, System.currentTimeMillis());
                statement.setString(2, fight.fightId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Fight was not ready to enter SPAWNING: " + fight.fightId());
                }
            }
            replaceChunksSync(connection, fight.fightId(), chunks);
            return null;
        });
    }

    public CompletableFuture<Void> saveDamage(ActiveFight fight) {
        return database.transaction(connection -> {
            saveDamageSync(connection, fight);
            return null;
        });
    }

    /**
     * Persists the boss's current recovery location and the bounded chunk-ticket
     * window. This is queued through the serialized SQLite writer, so successive
     * chunk crossings cannot be committed out of order.
     */
    public CompletableFuture<Void> saveRuntimePositionAndChunks(
            ActiveFight fight,
            double x,
            double y,
            double z,
            float yaw,
            float pitch,
            Collection<ActiveFight.ChunkCoordinate> chunks) {
        List<ActiveFight.ChunkCoordinate> snapshot = List.copyOf(chunks);
        return database.transaction(connection -> {
            long now = System.currentTimeMillis();
            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE active_fights
                    SET x=?, y=?, z=?, yaw=?, pitch=?, updated_at=?
                    WHERE fight_uuid=? AND state IN ('ACTIVE','SPAWN_CONFIRMED')
                    """)) {
                statement.setDouble(1, x);
                statement.setDouble(2, y);
                statement.setDouble(3, z);
                statement.setFloat(4, yaw);
                statement.setFloat(5, pitch);
                statement.setLong(6, now);
                statement.setString(7, fight.fightId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Active fight disappeared while updating runtime location: "
                            + fight.fightId());
                }
            }
            replaceChunksSync(connection, fight.fightId(), snapshot);
            return null;
        });
    }

    public CompletableFuture<Void> completeWithPayouts(
            ActiveFight fight,
            List<RewardCalculator.Reward> rewards,
            String terminalState) {
        return database.transaction(connection -> {
            saveDamageSync(connection, fight);
            long now = System.currentTimeMillis();

            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE active_fights
                    SET state=?, killing_blow_uuid=?, updated_at=?
                    WHERE fight_uuid=?
                    """)) {
                statement.setString(1, terminalState);
                statement.setString(2, fight.killingBlow() == null
                        ? null : fight.killingBlow().toString());
                statement.setLong(3, now);
                statement.setString(4, fight.fightId().toString());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException(
                            "Active fight disappeared during finalization: " + fight.fightId());
                }
            }

            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT OR IGNORE INTO token_payouts(
                        payout_uuid, fight_uuid, player_uuid, amount,
                        placement, state, created_at
                    ) VALUES(?,?,?,?,?,'PENDING',?)
                    """)) {
                for (RewardCalculator.Reward reward : rewards) {
                    UUID payoutId = UUID.nameUUIDFromBytes(
                            (fight.fightId() + ":" + reward.playerId())
                                    .getBytes(StandardCharsets.UTF_8));
                    statement.setString(1, payoutId.toString());
                    statement.setString(2, fight.fightId().toString());
                    statement.setString(3, reward.playerId().toString());
                    statement.setInt(4, reward.tokens());
                    statement.setInt(5, reward.placement());
                    statement.setLong(6, now);
                    statement.addBatch();
                }
                statement.executeBatch();
            }
            return null;
        });
    }

    private void saveDamageSync(Connection connection, ActiveFight fight) throws SQLException {
        Map<UUID, DamageLedger.Entry> snapshot = fight.damage().snapshot();
        try (PreparedStatement statement = connection.prepareStatement(DAMAGE_UPSERT)) {
            for (DamageLedger.Entry entry : snapshot.values()) {
                statement.setString(1, fight.fightId().toString());
                statement.setString(2, entry.playerId().toString());
                statement.setString(3, entry.lastKnownName());
                statement.setDouble(4, entry.damage());
                statement.setInt(5, entry.hitCount());
                statement.setLong(6, entry.firstHitAt());
                statement.setLong(7, entry.lastHitAt());
                statement.setInt(8, entry.killingBlow() ? 1 : 0);
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    private static void replaceChunksSync(
            Connection connection,
            UUID fightId,
            Collection<ActiveFight.ChunkCoordinate> chunks) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "DELETE FROM fight_chunks WHERE fight_uuid=?")) {
            statement.setString(1, fightId.toString());
            statement.executeUpdate();
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO fight_chunks(fight_uuid,chunk_x,chunk_z) VALUES(?,?,?)")) {
            for (ActiveFight.ChunkCoordinate chunk : chunks) {
                statement.setString(1, fightId.toString());
                statement.setInt(2, chunk.x());
                statement.setInt(3, chunk.z());
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    public CompletableFuture<Void> deleteActive(UUID fightId) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM active_fights WHERE fight_uuid=?")) {
                statement.setString(1, fightId.toString());
                statement.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Optional<RecoveredFight>> loadActive(
            Map<String, BossDefinition> definitions) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT * FROM active_fights
                    WHERE singleton_key=1 AND state IN ('ACTIVE','SPAWN_CONFIRMED','ENDING')
                    """); ResultSet result = statement.executeQuery()) {
                if (!result.next()) return Optional.empty();

                String summonerId = result.getString("summoner_id");
                BossDefinition definition = definitions.get(summonerId);
                if (definition == null) {
                    throw new SQLException(
                            "Unknown summoner id in active fight: " + summonerId);
                }

                ActiveFight fight = new ActiveFight(
                        UUID.fromString(result.getString("fight_uuid")),
                        definition,
                        UUID.fromString(result.getString("summoner_player_uuid")),
                        result.getString("world_name"),
                        result.getDouble("x"),
                        result.getDouble("y"),
                        result.getDouble("z"),
                        result.getFloat("yaw"),
                        result.getFloat("pitch"),
                        result.getLong("created_at"),
                        FightState.valueOf(result.getString("state"))
                );

                String entityId = result.getString("boss_entity_uuid");
                if (entityId != null && !entityId.isBlank()) {
                    fight.entityId(UUID.fromString(entityId));
                }
                String killingBlow = result.getString("killing_blow_uuid");
                if (killingBlow != null && !killingBlow.isBlank()) {
                    fight.killingBlow(UUID.fromString(killingBlow));
                }
                fight.maxHealth(result.getDouble("max_health"));
                loadChunks(connection, fight);
                loadDamage(connection, fight);
                return Optional.of(new RecoveredFight(
                        fight, result.getLong("cooldown_until")));
            }
        });
    }

    public CompletableFuture<Optional<ActiveFight>> loadIncomplete(
            Map<String, BossDefinition> definitions) {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT * FROM active_fights
                    WHERE singleton_key=1
                      AND state NOT IN ('ACTIVE','SPAWN_CONFIRMED','ENDING','COMPLETED')
                    """); ResultSet result = statement.executeQuery()) {
                if (!result.next()) return Optional.empty();
                String summonerId = result.getString("summoner_id");
                BossDefinition definition = definitions.get(summonerId);
                if (definition == null) {
                    throw new SQLException("Unknown summoner id in incomplete fight: " + summonerId);
                }
                ActiveFight fight = new ActiveFight(
                        UUID.fromString(result.getString("fight_uuid")),
                        definition,
                        UUID.fromString(result.getString("summoner_player_uuid")),
                        result.getString("world_name"),
                        result.getDouble("x"), result.getDouble("y"), result.getDouble("z"),
                        result.getFloat("yaw"), result.getFloat("pitch"),
                        result.getLong("created_at"),
                        FightState.valueOf(result.getString("state")));
                String entityId = result.getString("boss_entity_uuid");
                if (entityId != null && !entityId.isBlank()) fight.entityId(UUID.fromString(entityId));
                fight.maxHealth(result.getDouble("max_health"));
                loadChunks(connection, fight);
                return Optional.of(fight);
            }
        });
    }

    private void loadChunks(Connection connection, ActiveFight fight) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT chunk_x,chunk_z FROM fight_chunks WHERE fight_uuid=?")) {
            statement.setString(1, fight.fightId().toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    fight.chunks().add(new ActiveFight.ChunkCoordinate(
                            result.getInt(1), result.getInt(2)));
                }
            }
        }
    }

    private void loadDamage(Connection connection, ActiveFight fight) throws SQLException {
        List<DamageLedger.Entry> entries = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM fight_damage WHERE fight_uuid=?")) {
            statement.setString(1, fight.fightId().toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    entries.add(new DamageLedger.Entry(
                            UUID.fromString(result.getString("player_uuid")),
                            result.getString("last_known_name"),
                            result.getDouble("damage"),
                            result.getInt("hit_count"),
                            result.getLong("first_hit_at"),
                            result.getLong("last_hit_at"),
                            result.getInt("killing_blow") != 0
                    ));
                }
            }
        }
        fight.damage().restore(entries);
    }

    public CompletableFuture<List<UUID>> clearIncompleteFights() {
        return database.transaction(connection -> {
            List<UUID> ids = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT fight_uuid FROM active_fights
                    WHERE state NOT IN ('ACTIVE','SPAWN_CONFIRMED','ENDING')
                    """); ResultSet result = statement.executeQuery()) {
                while (result.next()) ids.add(UUID.fromString(result.getString(1)));
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    DELETE FROM active_fights
                    WHERE state NOT IN ('ACTIVE','SPAWN_CONFIRMED','ENDING')
                    """)) {
                statement.executeUpdate();
            }
            return List.copyOf(ids);
        });
    }

    public CompletableFuture<Long> loadCooldown() {
        return database.submit(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT long_value FROM global_state WHERE state_key='boss_cooldown_until'");
                 ResultSet result = statement.executeQuery()) {
                return result.next() ? Math.max(0L, result.getLong(1)) : 0L;
            }
        });
    }

    public CompletableFuture<Void> saveCooldown(long value) {
        return database.submit(connection -> {
            saveCooldownSync(connection, value, System.currentTimeMillis());
            return null;
        });
    }

    private void saveCooldownSync(Connection connection, long value, long now)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO global_state(state_key,long_value,updated_at)
                VALUES('boss_cooldown_until',?,?)
                ON CONFLICT(state_key) DO UPDATE SET
                    long_value=excluded.long_value,
                    updated_at=excluded.updated_at
                """)) {
            statement.setLong(1, Math.max(0L, value));
            statement.setLong(2, now);
            statement.executeUpdate();
        }
    }

    public record RecoveredFight(ActiveFight fight, long cooldownUntil) {}
}
