package dev.crimsonprogression.placeholder;

import dev.crimsonprogression.CrimsonProgressionPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

public final class CrimsonPlaceholderExpansion extends PlaceholderExpansion {
    private final CrimsonProgressionPlugin plugin;

    public CrimsonPlaceholderExpansion(CrimsonProgressionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "crimsonprogression"; }
    @Override public @NotNull String getAuthor() { return String.join(",", plugin.getDescription().getAuthors()); }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        String key = params.toLowerCase(Locale.ROOT);
        if ("active_boss".equals(key)) {
            return plugin.bossManager() == null ? "" : plugin.bossManager().active()
                    .map(fight -> fight.definition().displayName()).orElse("");
        }
        if (player == null) return "";
        return switch (key) {
            case "tag" -> plugin.tagService().display(player.getUniqueId());
            case "tag_plain" -> plugin.tagService().plain(player.getUniqueId());
            case "tokens", "trophies" -> plugin.cachedTokenBalance(player.getUniqueId());
            default -> null;
        };
    }
}
