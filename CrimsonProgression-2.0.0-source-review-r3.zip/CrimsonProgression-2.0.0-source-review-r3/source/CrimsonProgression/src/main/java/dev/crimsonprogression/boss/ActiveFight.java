package dev.crimsonprogression.boss;

import dev.crimsonprogression.core.DamageLedger;
import dev.crimsonprogression.core.FightState;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public final class ActiveFight {
    private final UUID fightId;
    private final BossDefinition definition;
    private final UUID summonerPlayer;
    private final String world;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;
    private final long createdAt;
    private final DamageLedger damage = new DamageLedger();
    private final Set<ChunkCoordinate> chunks = new LinkedHashSet<>();

    private volatile UUID entityId;
    private volatile double maxHealth;
    private volatile FightState state;
    private volatile UUID killingBlow;

    public ActiveFight(UUID fightId, BossDefinition definition, UUID summonerPlayer,
                       String world, double x, double y, double z, float yaw, float pitch,
                       long createdAt, FightState state) {
        this.fightId = fightId;
        this.definition = definition;
        this.summonerPlayer = summonerPlayer;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.createdAt = createdAt;
        this.state = state;
    }

    public UUID fightId() { return fightId; }
    public BossDefinition definition() { return definition; }
    public UUID summonerPlayer() { return summonerPlayer; }
    public String world() { return world; }
    public double x() { return x; }
    public double y() { return y; }
    public double z() { return z; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
    public long createdAt() { return createdAt; }
    public DamageLedger damage() { return damage; }
    public UUID entityId() { return entityId; }
    public double maxHealth() { return maxHealth; }
    public FightState state() { return state; }
    public UUID killingBlow() { return killingBlow; }
    public Set<ChunkCoordinate> chunks() { return chunks; }

    public void entityId(UUID value) { entityId = value; }
    public void maxHealth(double value) { maxHealth = value; }
    public void state(FightState value) { state = value; }
    public void killingBlow(UUID value) { killingBlow = value; }

    public record ChunkCoordinate(int x, int z) {}
}
