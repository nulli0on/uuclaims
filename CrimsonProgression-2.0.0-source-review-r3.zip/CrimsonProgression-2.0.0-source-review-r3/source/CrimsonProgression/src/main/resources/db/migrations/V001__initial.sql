PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS schema_version(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL, checksum TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS active_fights(
 singleton_key INTEGER PRIMARY KEY CHECK(singleton_key=1), fight_uuid TEXT NOT NULL UNIQUE,
 mythic_mob_id TEXT NOT NULL, boss_entity_uuid TEXT, display_name TEXT NOT NULL,
 world_name TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL, yaw REAL NOT NULL, pitch REAL NOT NULL,
 summoner_id TEXT NOT NULL, summoner_player_uuid TEXT NOT NULL, started_at INTEGER,
 max_health REAL, state TEXT NOT NULL, cooldown_until INTEGER, killing_blow_uuid TEXT,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS fight_chunks(fight_uuid TEXT NOT NULL, chunk_x INTEGER NOT NULL, chunk_z INTEGER NOT NULL, PRIMARY KEY(fight_uuid,chunk_x,chunk_z));
CREATE TABLE IF NOT EXISTS fight_damage(fight_uuid TEXT NOT NULL, player_uuid TEXT NOT NULL, last_known_name TEXT, damage REAL NOT NULL CHECK(damage>=0), hit_count INTEGER NOT NULL, first_hit_at INTEGER, last_hit_at INTEGER, killing_blow INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(fight_uuid,player_uuid));
CREATE TABLE IF NOT EXISTS token_payouts(payout_uuid TEXT PRIMARY KEY, fight_uuid TEXT NOT NULL, player_uuid TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), placement INTEGER NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at INTEGER NOT NULL, paid_at INTEGER, UNIQUE(fight_uuid,player_uuid));
CREATE TABLE IF NOT EXISTS voucher_instances(nonce TEXT PRIMARY KEY, reward_id TEXT NOT NULL, state TEXT NOT NULL, schema_version INTEGER NOT NULL, created_at INTEGER NOT NULL, issuing_player_uuid TEXT, claimed_by_uuid TEXT, claimed_at INTEGER, signature TEXT NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pending_deliveries(delivery_uuid TEXT PRIMARY KEY, player_uuid TEXT NOT NULL, delivery_type TEXT NOT NULL, payload_json TEXT NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS summoner_escrow(escrow_uuid TEXT PRIMARY KEY, fight_uuid TEXT, player_uuid TEXT NOT NULL, summoner_id TEXT NOT NULL, item_blob BLOB NOT NULL, inventory_slot INTEGER, item_fingerprint TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL, resolved_at INTEGER);
CREATE TABLE IF NOT EXISTS owned_tags(player_uuid TEXT NOT NULL, tag_id TEXT NOT NULL, source TEXT NOT NULL, acquired_at INTEGER NOT NULL, PRIMARY KEY(player_uuid,tag_id));
CREATE TABLE IF NOT EXISTS selected_tags(player_uuid TEXT PRIMARY KEY, tag_id TEXT, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS cosmetic_unlocks(player_uuid TEXT NOT NULL, cosmetic_id TEXT NOT NULL, source TEXT NOT NULL, acquired_at INTEGER NOT NULL, PRIMARY KEY(player_uuid,cosmetic_id));
CREATE TABLE IF NOT EXISTS selected_cosmetics(player_uuid TEXT NOT NULL, cosmetic_slot TEXT NOT NULL, cosmetic_id TEXT, updated_at INTEGER NOT NULL, PRIMARY KEY(player_uuid,cosmetic_slot));
CREATE TABLE IF NOT EXISTS shop_deliveries(transaction_uuid TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE, player_uuid TEXT NOT NULL, product_id TEXT NOT NULL, state TEXT NOT NULL, payload_json TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS discord_outbox(event_uuid TEXT PRIMARY KEY, event_type TEXT NOT NULL, payload_json TEXT NOT NULL, signature TEXT NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS legacy_imports(import_key TEXT PRIMARY KEY, source_hash TEXT NOT NULL, imported_at INTEGER NOT NULL, summary_json TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_damage_fight ON fight_damage(fight_uuid, damage DESC);
CREATE INDEX IF NOT EXISTS idx_payout_state ON token_payouts(state, created_at);
CREATE INDEX IF NOT EXISTS idx_delivery_player_state ON pending_deliveries(player_uuid,state);
