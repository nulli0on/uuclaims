ALTER TABLE summoner_escrow ADD COLUMN summoner_nonce TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS uq_summoner_escrow_live_nonce
ON summoner_escrow(summoner_nonce)
WHERE summoner_nonce IS NOT NULL
  AND state IN ('PENDING_REMOVAL','REMOVED','CONSUMED','REFUND_PENDING','FORFEITED');
