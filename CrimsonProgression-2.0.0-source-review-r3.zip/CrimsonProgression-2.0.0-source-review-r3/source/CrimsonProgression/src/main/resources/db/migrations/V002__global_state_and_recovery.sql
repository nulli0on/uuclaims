CREATE TABLE IF NOT EXISTS global_state(
 state_key TEXT PRIMARY KEY,
 long_value INTEGER,
 text_value TEXT,
 updated_at INTEGER NOT NULL
);
INSERT OR IGNORE INTO global_state(state_key,long_value,updated_at)
VALUES('boss_cooldown_until',0,strftime('%s','now')*1000);
