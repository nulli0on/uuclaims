ALTER TABLE token_payouts ADD COLUMN processing_started_at INTEGER;
ALTER TABLE token_payouts ADD COLUMN updated_at INTEGER;
UPDATE token_payouts SET updated_at=COALESCE(paid_at,created_at) WHERE updated_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_payout_processing ON token_payouts(state,processing_started_at);
CREATE INDEX IF NOT EXISTS idx_shop_delivery_state ON shop_deliveries(state,created_at);
