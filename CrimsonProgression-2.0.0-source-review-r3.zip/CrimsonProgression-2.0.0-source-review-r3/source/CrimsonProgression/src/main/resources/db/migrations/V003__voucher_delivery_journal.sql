ALTER TABLE voucher_instances ADD COLUMN claim_delivery_uuid TEXT;
CREATE INDEX IF NOT EXISTS idx_voucher_claim_delivery ON voucher_instances(claim_delivery_uuid);
