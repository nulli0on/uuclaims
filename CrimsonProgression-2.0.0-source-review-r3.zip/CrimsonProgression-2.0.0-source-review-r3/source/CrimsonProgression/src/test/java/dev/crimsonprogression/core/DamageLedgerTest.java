package dev.crimsonprogression.core;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DamageLedgerTest {
    @Test
    void clampsOverkillToHealthBeforeHit() {
        DamageLedger ledger = new DamageLedger();
        UUID player = UUID.randomUUID();
        assertEquals(4.5D, ledger.record(player, "Steve", 20D, 4.5D, 1L));
        assertEquals(4.5D, ledger.snapshot().get(player).damage());
    }

    @Test
    void rejectsInvalidDamageAndOrdersDeterministically() {
        DamageLedger ledger = new DamageLedger();
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();
        assertEquals(0D, ledger.record(first, "A", Double.NaN, 20D, 1L));
        ledger.record(second, "B", 10D, 20D, 2L);
        ledger.record(first, "A", 10D, 20D, 1L);
        assertEquals(first, ledger.leaderboard().getFirst().playerId());
    }

    @Test
    void marksKillingBlowWithoutChangingDamage() {
        DamageLedger ledger = new DamageLedger();
        UUID player = UUID.randomUUID();
        ledger.record(player, "A", 3D, 5D, 1L);
        ledger.markKillingBlow(player);
        assertTrue(ledger.snapshot().get(player).killingBlow());
        assertEquals(3D, ledger.snapshot().get(player).damage());
    }
}
