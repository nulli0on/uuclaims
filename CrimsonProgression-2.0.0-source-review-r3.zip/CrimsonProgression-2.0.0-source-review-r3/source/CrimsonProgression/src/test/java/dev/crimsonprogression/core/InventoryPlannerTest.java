package dev.crimsonprogression.core;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InventoryPlannerTest {
    @Test
    void fillsPartialStacksBeforeEmptySlots() {
        var storage = List.of(
                new InventoryPlanner.Slot("STONE", 60, 64),
                new InventoryPlanner.Slot(null, 0, 64));
        assertTrue(InventoryPlanner.fits(storage, List.of(new InventoryPlanner.Stack("STONE", 68, 64))));
        assertFalse(InventoryPlanner.fits(storage, List.of(new InventoryPlanner.Stack("STONE", 69, 64))));
    }

    @Test
    void respectsNonStandardMaximumStackSize() {
        var storage = List.of(new InventoryPlanner.Slot(null, 0, 1));
        assertTrue(InventoryPlanner.fits(storage, List.of(new InventoryPlanner.Stack("UNSTACKABLE", 1, 1))));
        assertFalse(InventoryPlanner.fits(storage, List.of(new InventoryPlanner.Stack("UNSTACKABLE", 2, 1))));
    }
}
