package dev.crimsonprogression.database;

import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseMigrationsTest {
    private static final List<String> MIGRATIONS = List.of(
            "db/migrations/V001__initial.sql",
            "db/migrations/V002__global_state_and_recovery.sql",
            "db/migrations/V003__voucher_delivery_journal.sql",
            "db/migrations/V004__payout_and_shop_recovery.sql",
            "db/migrations/V005__summoner_nonce_replay_protection.sql"
    );

    @Test
    void appliesAllMigrationsAndCreatesRecoveryColumns() throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite::memory:")) {
            for (String migration : MIGRATIONS) executeScript(connection, resource(migration));

            assertTrue(hasColumn(connection, "voucher_instances", "claim_delivery_uuid"));
            assertTrue(hasColumn(connection, "token_payouts", "processing_started_at"));
            assertTrue(hasColumn(connection, "token_payouts", "updated_at"));
            assertTrue(hasTable(connection, "global_state"));
            assertTrue(hasTable(connection, "shop_deliveries"));
            assertTrue(hasColumn(connection, "summoner_escrow", "summoner_nonce"));
        }
    }

    @Test
    void protectedSummonerNonceCannotBeReservedTwiceWhileLive() throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite::memory:")) {
            for (String migration : MIGRATIONS) executeScript(connection, resource(migration));
            String nonce = UUID.randomUUID().toString();
            long now = System.currentTimeMillis();
            try (Statement statement = connection.createStatement()) {
                assertEquals(1, statement.executeUpdate("INSERT INTO summoner_escrow(escrow_uuid,player_uuid,"
                        + "summoner_id,item_blob,inventory_slot,item_fingerprint,state,created_at,summoner_nonce) VALUES('"
                        + UUID.randomUUID() + "','player','boss',X'01',0,'fingerprint','REMOVED'," + now
                        + ",'" + nonce + "')"));
                assertThrows(SQLException.class, () -> statement.executeUpdate(
                        "INSERT INTO summoner_escrow(escrow_uuid,player_uuid,summoner_id,item_blob,inventory_slot,"
                                + "item_fingerprint,state,created_at,summoner_nonce) VALUES('" + UUID.randomUUID()
                                + "','player','boss',X'01',0,'fingerprint','PENDING_REMOVAL'," + now
                                + ",'" + nonce + "')"));
                assertEquals(1, statement.executeUpdate("UPDATE summoner_escrow SET state='REFUNDED' "
                        + "WHERE summoner_nonce='" + nonce + "'"));
                assertEquals(1, statement.executeUpdate(
                        "INSERT INTO summoner_escrow(escrow_uuid,player_uuid,summoner_id,item_blob,inventory_slot,"
                                + "item_fingerprint,state,created_at,summoner_nonce) VALUES('" + UUID.randomUUID()
                                + "','player','boss',X'01',0,'fingerprint','PENDING_REMOVAL'," + now
                                + ",'" + nonce + "')"));
            }
        }
    }

    @Test
    void duplicatedVoucherNonceCannotBeIssuedTwiceAndClaimTransitionIsCompareAndSet() throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite::memory:")) {
            for (String migration : MIGRATIONS) executeScript(connection, resource(migration));
            String nonce = UUID.randomUUID().toString();
            long now = System.currentTimeMillis();
            String insert = "INSERT INTO voucher_instances(nonce,reward_id,state,schema_version,created_at,signature,updated_at) "
                    + "VALUES('" + nonce + "','builder_supplies','ISSUED',1," + now + ",'sig'," + now + ")";
            try (Statement statement = connection.createStatement()) {
                assertEquals(1, statement.executeUpdate(insert));
                assertThrows(SQLException.class, () -> statement.executeUpdate(insert));
                assertEquals(1, statement.executeUpdate("UPDATE voucher_instances SET state='CLAIMING' "
                        + "WHERE nonce='" + nonce + "' AND state='ISSUED'"));
                assertEquals(0, statement.executeUpdate("UPDATE voucher_instances SET state='CLAIMING' "
                        + "WHERE nonce='" + nonce + "' AND state='ISSUED'"));
            }
        }
    }

    private static String resource(String name) throws Exception {
        try (InputStream input = DatabaseMigrationsTest.class.getClassLoader().getResourceAsStream(name)) {
            assertNotNull(input, "Missing migration resource " + name);
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static void executeScript(Connection connection, String script) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            for (String chunk : script.split(";")) {
                String sql = chunk.trim();
                if (!sql.isEmpty()) statement.execute(sql);
            }
        }
    }

    private static boolean hasColumn(Connection connection, String table, String column) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (result.next()) if (column.equalsIgnoreCase(result.getString("name"))) return true;
            return false;
        }
    }

    private static boolean hasTable(Connection connection, String table) throws SQLException {
        try (var statement = connection.prepareStatement(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?")) {
            statement.setString(1, table);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }
}
