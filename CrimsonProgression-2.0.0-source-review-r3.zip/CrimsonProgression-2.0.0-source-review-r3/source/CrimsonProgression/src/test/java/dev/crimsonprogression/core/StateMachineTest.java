package dev.crimsonprogression.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StateMachineTest {
    @Test
    void permitsExpectedFightPath() {
        var machine = FightTransitions.create();
        machine.require(FightState.ESCROW_PENDING, FightState.ESCROWED);
        machine.require(FightState.SPAWNING, FightState.SPAWN_CONFIRMED);
        machine.require(FightState.ACTIVE, FightState.ENDING);
        machine.require(FightState.ENDING, FightState.COMPLETED);
    }

    @Test
    void rejectsImpossibleTransition() {
        assertThrows(IllegalStateException.class,
                () -> FightTransitions.create().require(FightState.ACTIVE, FightState.SPAWNING));
    }
}
