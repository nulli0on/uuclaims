package dev.crimsonprogression.core;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class RewardCalculatorTest {
    @Test
    void awardsConfiguredTopFiveExactly() {
        List<DamageLedger.Entry> entries = java.util.stream.IntStream.range(0, 6)
                .mapToObj(i -> new DamageLedger.Entry(UUID.randomUUID(), "P" + i, 100D - i,
                        1, i, i, i == 0)).toList();
        var rewards = RewardCalculator.calculate(entries, Map.of(1, 250, 2, 150, 3, 100, 4, 60, 5, 40));
        assertEquals(List.of(250, 150, 100, 60, 40), rewards.stream().map(RewardCalculator.Reward::tokens).toList());
        assertEquals(5, rewards.size());
        assertTrue(rewards.getFirst().killingBlow());
    }

    @Test
    void ignoresZeroOrNegativeConfiguredRewards() {
        var entry = new DamageLedger.Entry(UUID.randomUUID(), "P", 1D, 1, 1L, 1L, false);
        assertTrue(RewardCalculator.calculate(List.of(entry), Map.of(1, -5)).isEmpty());
    }
}
