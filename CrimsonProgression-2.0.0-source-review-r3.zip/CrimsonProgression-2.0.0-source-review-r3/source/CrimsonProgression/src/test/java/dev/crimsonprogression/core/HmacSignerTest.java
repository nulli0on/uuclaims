package dev.crimsonprogression.core;

import org.junit.jupiter.api.Test;

import java.security.SecureRandom;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class HmacSignerTest {
    private static HmacSigner signer() {
        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);
        return new HmacSigner(key);
    }

    @Test
    void validatesUntamperedPayloadAndRejectsTampering() {
        HmacSigner signer = signer();
        VoucherPayload payload = new VoucherPayload("builder_supplies", UUID.randomUUID(), 1, 1234L, UUID.randomUUID());
        String signature = signer.sign(payload.canonical());
        assertTrue(signer.verify(payload.canonical(), signature));
        assertFalse(signer.verify(payload.canonical() + "x", signature));
        assertFalse(signer.verify(payload.canonical(), "not-hex"));
    }

    @Test
    void requiresStrongSecret() {
        assertThrows(IllegalArgumentException.class, () -> new HmacSigner(new byte[16]));
    }
}
