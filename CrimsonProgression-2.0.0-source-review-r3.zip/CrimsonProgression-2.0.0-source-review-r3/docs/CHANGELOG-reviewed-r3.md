# Reviewed source r3 changelog

## CrimsonProgression

- Added signed summoner nonce generation, validation, database storage, and replay prevention migration V005.
- Made summoner escrow plus pre-spawn fight reservation atomic.
- Added terminal escrow forfeit handling for no-refund resets.
- Added arena/world/spawn validation, chunk and cooldown caps, and missing-entity recovery.
- Persisted `SPAWNING` and the exact recovery chunks before the MythicMobs side effect.
- Added UUID-first active entity recovery and a bounded moving chunk-ticket window.
- Added durable finalization retries and safer active-fight recovery locking.
- Added Mythic item/mob definition checks.
- Made boss rewards, definitions, boss bar, armor abilities, spawn filtering, shop products, and Discord settings reloadable.
- Added safe, durable admin item delivery reporting.
- Added bounded shop retries and manual-review quarantine for ambiguous non-idempotent rewards.
- Quarantined exceptional economy payouts and capped explicit rejection retries.
- Hardened voucher compare-and-set transitions and uncertain inventory-failure recovery.
- Added local fallback for malformed voucher and boss MiniMessage configuration.
- Stopped global retries of offline shop rows; join processing remains enabled.
- Added plugin-local path validation and missing-default config merging with backup.
- Disabled unsigned legacy summoners and Discord bridge by default.
- Corrected boss-hunter crate configuration inconsistencies.

## UltimateClaims

- Prevented administrative entitlement changes from reducing used claim area.
- Added immutable persistence snapshots and serialized SQLite writes.
- Added atomic claim/player create/delete persistence with in-memory rollback.
- Added bounded spatial indexing with large-claim overflow handling.
- Improved indexed overlap and nearby queries.
- Added startup used-block reconciliation.
- Added configurable default trust flags.
- Disabled name-only legacy claim tools by default.
- Added particle, vertical-range, and spatial-index hard caps.
- Tightened off-hand and piston protection handling.
- Protected generic interactable blocks and rejected corrupt/out-of-claim stored spawn points.
- Normalized nullable claim owner/name/WorldGuard fields.
- Added plugin-local storage path validation and bounded shutdown flush.
- Updated tests to reflect revised accounting and spatial-index behavior; tests were not executed in this review.

## Packaging

- Removed all compiled artifacts from the reviewed deliverable.
- Replaced unsupported build/test claims with an explicit static-review boundary.
- Added build requirements and a detailed staged runtime acceptance checklist.
