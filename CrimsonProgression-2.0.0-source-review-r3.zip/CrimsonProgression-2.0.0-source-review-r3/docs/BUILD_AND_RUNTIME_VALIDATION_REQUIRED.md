# Build and runtime validation required

The reviewed archive intentionally contains no JARs.

## Clean build requirements

Use a clean machine or CI runner with:

- the Java release requested by the POMs;
- Maven with network access to the declared repositories;
- the exact Paper API coordinate requested by the project;
- no pre-existing `target/` directories or locally fabricated dependency artifacts.

Run from `source/`:

```bash
mvn --no-transfer-progress clean verify
```

Record:

- Java and Maven versions;
- complete Maven output;
- resolved dependency tree;
- test counts and failures/skips;
- generated JAR SHA-256 values;
- `jar tf` listings;
- the effective POM for each module.

A successful build is necessary but not sufficient.

## Binary inspection

For each generated JAR, verify:

- `plugin.yml` has the expected version, main class, API version, commands, and permissions;
- V001–V005 SQL resources are present in CrimsonProgression;
- SQLite JDBC and required service metadata are shaded exactly once;
- provided dependencies such as Paper are not accidentally bundled;
- no source, secrets, production databases, or old JARs are embedded;
- class versions match the server JVM.

## Staged server requirement

Use a copy of the production plugin set and configuration. Do not first-test on production. Capture the full startup log and reject the build on any linkage error, reflective API error, invalid configuration, migration failure, scheduler/thread exception, or disabled feature.

The complete acceptance sequence is in `RUNTIME_ACCEPTANCE_CHECKLIST.md`.
