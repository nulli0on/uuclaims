# Static review report

Date: 20 July 2026

## Scope

Reviewed the supplied Java source, Maven descriptors, bundled resources, SQL migrations, and installation YAML for CrimsonProgression and UltimateClaims. Compilation and server execution were intentionally excluded.

## Checks completed

- 83 Java files inspected by source-structure tooling.
- Java delimiter and lexical smoke checks completed.
- Package declarations match source paths.
- Public top-level type names match filenames.
- Internal `dev.crimsonprogression.*` and `dev.ultimateclaims.*` imports resolve to supplied source.
- Plugin main classes exist.
- Declared command sets match the explicit registration code.
- All source/install YAML files parse.
- ExcellentShop references 14 defined products; all 14 are used.
- Product targets resolve across 7 crate IDs, 23 tags, 6 cosmetics, and the configured claim/LuckPerms integrations.
- ExcellentCrates reward commands resolve across 21 boss summoners and 11 voucher definitions.
- CrimsonProgression migrations V001 through V005 apply to a fresh in-memory SQLite database.
- V005 rejects duplicate protected summoner nonces and preserves the intended cancelled/refunded reuse lifecycle.
- No merge-conflict markers or whitespace errors were found.

## Confirmed defects addressed

### CrimsonProgression

1. **Summoner replay:** signed item identity had no durable one-use nonce reservation. Added PDC nonce plus a unique partial SQLite index.
2. **Escrow/fight crash window:** escrow and singleton fight creation were separate operations. Combined them in one transaction.
3. **Unresolved no-refund reset:** reset could remove the fight while leaving recoverable escrow. Added terminal `FORFEITED` handling.
4. **Unsafe arena startup:** missing/invalid world and spawn conditions could reach the spawn path. Added fail-closed validation and refund handling.
5. **Spawn-side-effect crash window:** `SPAWNING` plus the exact chunk window is persisted before MythicMobs is called; partially spawned marked entities are removed before escrow resolution.
6. **Moving boss recovery gap:** recovery now prefers the persisted entity UUID and persists a bounded chunk-ticket window as the boss changes chunks.
7. **Unbounded chunk/config work:** added runtime caps for chunk radius, cooldown, and recovery chunk sets.
8. **Lost finalization risk:** failed fight finalization now keeps the fight locked and retries instead of clearing runtime state.
9. **Missing entity recovery:** persisted fights whose entity disappears are aborted through a durable refund path after a bounded threshold.
10. **Payout ambiguity:** exceptional ExcellentEconomy results no longer retry automatically; explicit rejection retries are capped.
11. **Voucher journal races:** rollback/recovery transitions now verify both voucher and delivery row state; uncertain Bukkit inventory failures are quarantined.
12. **Configuration text failures:** malformed voucher or boss MiniMessage strings use local plain-text fallback instead of failing startup/tasks.
13. **Stale reload values:** boss definitions/rewards, boss bar settings, armor abilities, spawn filtering, shop products, and Discord settings now reload.
14. **Unsafe admin delivery reporting:** item commands now report success only after inventory insertion or durable queueing.
15. **Shop retry ambiguity:** non-idempotent external reward failures are quarantined for review; offline rows no longer churn every minute.
16. **Path traversal:** database, secret, and Discord outbox paths are constrained to the plugin data directory.
17. **Configuration replacement risk:** new defaults are merged with backup rather than overwriting administrator values.

### UltimateClaims

1. **Entitlement corruption:** reducing total claim blocks could shrink `usedClaimBlocks`, effectively making existing claim area free. Total entitlement now cannot fall below used area.
2. **Mutable async persistence:** asynchronous writers could observe partially changed claim/player objects. Writes now use immutable snapshots.
3. **Claim/balance split writes:** creation/deletion and balance changes are handled in a single SQLite transaction.
4. **Overlap race:** claims are reserved in memory before the asynchronous commit, with rollback on persistence failure.
5. **Spatial-index memory risk:** very large claims now use a bounded per-world overflow set.
6. **Expensive nearby scans:** nearby and overlap lookups use the spatial index and squared-distance checks.
7. **Forgeable tool fallback:** display-name-only claim tools are disabled by default.
8. **Particle abuse:** vertical range, click particles, and render count are hard-capped.
9. **Trust usability:** `/claim trust` now grants configurable default flags instead of creating a nominally trusted player with no practical rights.
10. **Interaction gaps:** off-hand item checks, piston boundary behavior, and generic interactable-block protection were tightened.
11. **Stored teleport corruption:** non-finite, wrong-world, or out-of-claim spawn points are ignored; nullable claim fields are normalized.
12. **Storage safety:** paths are constrained to the plugin directory; SQLite uses one serialized writer and a bounded shutdown flush.
13. **Accounting recovery:** used block totals are recalculated from loaded claims and repaired when inconsistent.

## Findings not represented as fixed

- Exact Paper/API compilation compatibility is unknown.
- Reflection against the installed MythicMobs and Excellent* versions is unknown.
- WorldGuard and CelestCombat behavior is unknown without those exact plugins.
- The ExcellentShop command lacks a documented stable external transaction ID in the supplied config, so duplicate command invocation cannot be deduplicated across separate journal rows.
- Placeholder arena coordinates and Mythic definitions must be validated by the server administrator.
- Static checks cannot prove thread safety under Paper event timing, correctness after process termination at every persistence boundary, or acceptable performance with production-scale data.

## Original binaries

The original JARs were retained only outside the reviewed deliverable as unverified inputs. Their manifests and `META-INF/maven` entries are not sufficient build provenance. No claim is made that they are fake or valid; only that they were not reproducibly verified against this source.
