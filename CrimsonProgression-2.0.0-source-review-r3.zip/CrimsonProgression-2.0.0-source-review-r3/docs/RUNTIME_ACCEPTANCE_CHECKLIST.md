# Runtime acceptance checklist

Complete every applicable item on a disposable or backed-up staging server.

## 1. Build and startup

- [ ] Clean Maven `verify` succeeds from a fresh checkout/source extraction.
- [ ] No test is skipped unexpectedly.
- [ ] Generated JAR SHA-256 values are recorded.
- [ ] Paper starts both plugins without stack traces or linkage errors.
- [ ] `/plugins` shows both enabled.
- [ ] `/cp debug` reports expected integrations and disabled optional integrations accurately.
- [ ] UltimateClaims loads stored players and claims without reconciliation errors that are not understood.

## 2. Configuration and migrations

- [ ] Back up both plugin directories and databases.
- [ ] Confirm database files remain inside each plugin directory.
- [ ] Start from a copy of the current production data and inspect migration backups.
- [ ] Restart twice; migrations are not reapplied and no checksum mismatch occurs.
- [ ] Existing customized YAML values remain unchanged after new-default merging.
- [ ] Invalid YAML causes a safe startup/reload failure rather than silent replacement.

## 3. Boss arena and MythicMobs

- [ ] Replace the placeholder `bossarena` and `0,0,0` spawn values.
- [ ] Verify the feet and head blocks are passable and the floor is solid.
- [ ] Verify all 21 configured Mythic item IDs exist.
- [ ] Verify all 21 configured Mythic mob IDs exist.
- [ ] Verify natural-spawn filtering only affects the configured arena world/reasons.
- [ ] Confirm boss spawn, bar, health, announcements, damage ranking, killing blow, and top rewards.
- [ ] Confirm projectiles are attributed to their player shooter.
- [ ] Confirm Crimson armor multiplier, lifesteal, and wither immunity match config after reload.

## 4. Summoner security and crash recovery

- [ ] Issue a new signed summoner with `/cp summoner give`.
- [ ] Confirm unsigned/name-only summoners are rejected while legacy mode is off.
- [ ] Copy the exact item/NBT in staging; one nonce may start at most one fight.
- [ ] Confirm a second use of the same nonce reports already used.
- [ ] Test a full inventory: the item is durably queued, not silently lost.
- [ ] Stop the server after reservation but before item removal; intact inventory item is not duplicated.
- [ ] Stop after removal but before spawn; one refund is queued.
- [ ] Stop during the MythicMobs spawn call; a marked partial entity is removed before any refund.
- [ ] Stop after spawn persistence; the active fight and chunk tickets recover.
- [ ] Move/knock the boss across several chunks, restart, and verify UUID/current-window recovery without retained old tickets.
- [ ] Remove the boss entity externally; bounded recovery queues one refund and unlocks safely.
- [ ] Kill the boss, then stop during `ENDING`; payouts recover without duplication.
- [ ] Test `/cp boss reset` with refund and without refund.
- [ ] Confirm no-refund reset leaves escrow `FORFEITED`, not refund-pending.
- [ ] Test `/cp boss recover` after an intentionally repaired recovery blocker.

## 5. Shop, payouts, vouchers, and item delivery

- [ ] Validate every ExcellentShop item loads with the exact installed version.
- [ ] Buy each of the 14 products online.
- [ ] Buy applicable products while the player disconnects during delivery.
- [ ] Confirm offline rows wait until join and do not retry every minute.
- [ ] Force crate-key and claim-block integration failures; rows become `REVIEW_REQUIRED`.
- [ ] Verify manual retry only after checking whether the external reward already landed.
- [ ] Force repeated idempotent failures; automatic retry stops at the configured limit.
- [ ] Determine whether the installed ExcellentShop exposes a stable transaction placeholder. If yes, add and test it before claiming cross-command deduplication.
- [ ] Restart during token payout and verify deterministic payout IDs prevent duplicates.
- [ ] Force an exceptional economy response and verify the payout becomes `REVIEW_REQUIRED`, not `RETRY`.
- [ ] Force repeated explicit deposit rejection and verify automatic retries stop at the configured cap.
- [ ] Issue, trade, redeem, restart during redemption, and attempt replay of signed vouchers.
- [ ] Corrupt voucher/boss MiniMessage text on staging and verify plain fallback without task/plugin failure.
- [ ] Test queued admin grants with a full inventory and reconnect.

## 6. UltimateClaims accounting and persistence

- [ ] Create a claim, restart, and verify geometry, flags, trust, spawn, and owner data.
- [ ] Delete a claim and verify exactly its area returns to available blocks.
- [ ] Attempt to set/take total blocks below used area; existing claims remain fully accounted.
- [ ] Create/delete rapidly; overlapping reservations and balances remain consistent.
- [ ] Force a SQLite failure during create/delete and verify in-memory rollback.
- [ ] Import a copy of legacy YAML and verify backup, retention, and one-time import behavior.
- [ ] Compare `usedClaimBlocks` with the sum of owned claim areas after startup reconciliation.
- [ ] Test offline API claim-block grants through CrimsonProgression.

## 7. UltimateClaims protection

- [ ] Test block break/place, doors, trapdoors, gates, chests, containers, buckets, spawn eggs, entities, vehicles, pearls, chorus fruit, portals, explosions, fire, fluids, hoppers, and redstone-relevant interactions.
- [ ] Test buttons, levers, beds, bells, workstations, and other interactable blocks as an untrusted player.
- [ ] Insert an invalid/out-of-claim stored claim spawn point and verify it is ignored safely.
- [ ] Test every action as owner, configured trusted player, unrelated player, operator, and bypass user.
- [ ] Verify `/claim trust` grants only the configured default trust flags.
- [ ] Verify `/claim trustflag` can remove and add individual rights.
- [ ] Test main-hand and off-hand interactions while holding the claiming tool.
- [ ] Confirm a renamed anvil item is not accepted as the claiming tool by default.
- [ ] Test piston movement within wilderness, within one claim, and across every claim boundary combination.
- [ ] Test WorldGuard overlap and managed-region cleanup behavior.
- [ ] Test CelestCombat entry/teleport behavior with the exact installed plugin.

## 8. Load and shutdown

- [ ] Populate production-scale claim and player counts on staging.
- [ ] Create a very large permitted claim and verify bounded index memory behavior.
- [ ] Exercise nearby searches and border particles under concurrent players.
- [ ] Profile tick time during boss combat, claim lookups, autosave, and join delivery.
- [ ] Stop normally and confirm final storage flush completes within the configured timeout.
- [ ] Force-kill staging and verify the next startup recovery paths without duplication or loss.

Do not mark the release production-ready until failures are fixed and the entire relevant checklist is rerun from a clean build.
