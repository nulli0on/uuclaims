# LPCPlus patch requires the live LPCPlus 0.1-SNAPSHOT configuration

Implemented PlaceholderAPI value:

```text
%crimsonprogression_tag%
```

The intended chat order is:

```text
%crimsonprogression_tag%<LuckPerms rank prefix><player name>: <message>
```

No exact LPCPlus key/path is claimed because the live configuration was not included.
