"""Trusted CoreDSC bridge for CrimsonProgression boss-start announcements.

Install into plugins/CoreDSC/bot/scripts/. This script uses CoreDSC's existing
JDA connection; it does not create a bot, token, webhook, or Java patch.
"""
from coredsc_api import command
from pathlib import Path
import base64
import hashlib
import hmac
import json
import re
import time
import uuid

SCHEMA_VERSION = 1
ROOT = Path("plugins/CrimsonProgression").resolve()
OUTBOX = (ROOT / "data" / "discord-outbox").resolve()
SECRET = (ROOT / "data" / "secret.key").resolve()
UUID_RE = re.compile(r"^[0-9a-fA-F-]{36}$")
CHANNEL_RE = re.compile(r"^[0-9]{15,25}$")
MAX_FILE_BYTES = 16 * 1024
MAX_MESSAGE_LENGTH = 1900
MAX_CLOCK_SKEW_MILLIS = 30_000


def _load_secret():
    raw = base64.b64decode(SECRET.read_text(encoding="utf-8").strip(), validate=True)
    if len(raw) < 32:
        raise ValueError("CrimsonProgression secret is too short")
    return raw


def _canonical(data):
    return (
        f"{data['schema_version']}\n{data['event_uuid']}\n{data['created_at']}\n"
        f"{data['expires_at']}\n{data['channel_id']}\n{data['message']}"
    )


def _safe_event_file(event_id):
    OUTBOX.mkdir(parents=True, exist_ok=True)
    candidate = (OUTBOX / f"{event_id}.json").resolve(strict=True)
    if candidate.parent != OUTBOX:
        raise ValueError("Path traversal rejected")
    if candidate.stat().st_size > MAX_FILE_BYTES:
        raise ValueError("Event file is too large")
    return candidate


@command(
    name="crimsonbossstarted",
    description="Internal CrimsonProgression Discord bridge",
    platforms=("MINECRAFT",),
    permission="crimsonprogression.discord.bridge",
    cooldown_seconds=0,
)
def crimson_boss_started(ctx):
    if ctx.platform != "MINECRAFT" or not ctx.args or not UUID_RE.fullmatch(str(ctx.args[0])):
        ctx.log("Rejected malformed CrimsonProgression event id", "WARNING")
        return
    try:
        event_id = str(uuid.UUID(str(ctx.args[0])))
        event_file = _safe_event_file(event_id)
        data = json.loads(event_file.read_text(encoding="utf-8"))

        if int(data.get("schema_version", -1)) != SCHEMA_VERSION:
            raise ValueError("Unsupported event schema")
        if data.get("event_uuid") != event_id:
            raise ValueError("Event UUID mismatch")
        channel_id = str(data.get("channel_id", ""))
        if not CHANNEL_RE.fullmatch(channel_id):
            raise ValueError("Invalid Discord channel ID")
        message = str(data.get("message", ""))
        if not message or len(message) > MAX_MESSAGE_LENGTH:
            raise ValueError("Invalid Discord message length")

        now = int(time.time() * 1000)
        created_at = int(data["created_at"])
        expires_at = int(data["expires_at"])
        if created_at > now + MAX_CLOCK_SKEW_MILLIS:
            raise ValueError("Event creation time is in the future")
        if now > expires_at:
            event_file.rename(event_file.with_suffix(".expired"))
            raise ValueError("Event expired")

        expected = hmac.new(_load_secret(), _canonical(data).encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, str(data.get("signature", ""))):
            raise ValueError("Invalid HMAC")

        # CoreDSC sanitizes mass mentions and uses its existing JDA connection.
        ctx.discord.send(channel_id, message)
        event_file.rename(event_file.with_suffix(".queued"))
        ctx.log(f"Queued CrimsonProgression boss-start event {event_id}", "INFO")
    except Exception as error:
        ctx.log(f"CrimsonProgression Discord event failed: {error}", "WARNING")
