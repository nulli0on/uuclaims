# ExcellentShop 5.1.3 configuration for CrimsonProgression

These are native ExcellentShop 5.1.x Virtual Shop YAML files, not an editor
import list.

## Version binding

- ExcellentShop 5.1.3
- matching NightCore required by ExcellentShop 5.1.3
- ExcellentEconomy 2.8.0
- PlaceholderAPI 2.12.3
- Paper 26.1.2 / Java 25

## Installation

1. Stop the server and back up `plugins/ExcellentShop/`.
2. Start ExcellentShop 5.1.3 once to generate its files, then stop the server.
3. Merge `config.merge.yml` into `plugins/ExcellentShop/config.yml`.
4. Merge `virtual_shop/settings.merge.yml` into
   `plugins/ExcellentShop/virtual_shop/settings.yml`.
5. Copy `virtual_shop/shops/coin_shop.yml` and `token_shop.yml` to
   `plugins/ExcellentShop/virtual_shop/shops/`.
6. Confirm ExcellentEconomy contains `coins.yml` and `tokens.yml`.
7. Restart the complete server.
8. Verify NightCore logs both registrations:
   - `excellenteconomy_coins`
   - `excellenteconomy_tokens`
9. Test `/vshop open coin_shop`, `/vshop open token_shop`, `/coinshop` and
   `/tokenshop` on a server copy.

## Important currency distinction

ExcellentEconomy file IDs are `coins` and `tokens`. ExcellentShop uses the
NightCore bridge IDs `excellenteconomy_coins` and `excellenteconomy_tokens`.
Using plain `coins` or `tokens` in ExcellentShop is incorrect for this bridge.

## Delivery command

ExcellentShop executes command products as console and resolves PlaceholderAPI.
Every product calls:

`crimsonprogression shop deliver %player_name% <product-id>`

CrimsonProgression rejects player execution and journals delivery before calling
ExcellentCrates, LuckPerms or UltimateClaims.

## Limits and ownership

Keys and Claim Block bundles are repeatable. Permanent ranks, tags and cosmetics
have an ExcellentShop buy limit of one per player. A YAML-only shop cannot know
about ownership acquired outside the shop; test existing-owner cases before
production. CrimsonProgression journals and safely retries each individual recorded delivery. However, the supplied command does not include a stable ExcellentShop transaction ID, so two separate command invocations create two separate journal rows. An allowed or duplicated repeat purchase can therefore still be charged and delivered by ExcellentShop.

## Command conflicts

Disable old Skript/DeluxeMenus registrations for `/coinshop` and `/tokenshop`
before enabling these aliases.

## Verification scope

The YAML and CrimsonProgression cross-references are internally consistent. Compatibility with the exact ExcellentShop/NightCore schema and runtime behavior was not verified because the exact live plugin set and generated configuration were not available.
