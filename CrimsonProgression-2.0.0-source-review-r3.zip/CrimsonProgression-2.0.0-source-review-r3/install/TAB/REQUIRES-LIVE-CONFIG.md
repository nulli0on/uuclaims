# TAB patch requires the live TAB 6.1.0 files

Implemented PlaceholderAPI value:

```text
%crimsonprogression_tag%
```

The value already contains its color reset and trailing separator. The intended order is:

```text
%crimsonprogression_tag%<LuckPerms rank prefix><player name>
```

Do not paste a guessed groups.yml/config.yml from another TAB version. Supply the live files to produce an exact patch.
