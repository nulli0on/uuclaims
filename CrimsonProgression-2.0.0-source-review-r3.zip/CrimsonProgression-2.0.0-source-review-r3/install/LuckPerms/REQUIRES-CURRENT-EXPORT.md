# ranks.json.gz not generated

A production LuckPerms import must preserve the server's current group definitions while adding Warlord, BossHunter and any required tag metadata. The supplied server archive contained no current LuckPerms export.

Generating an import from the old reference package could overwrite or omit current groups and permissions. That would be unsafe.

Required input:

1. current `/lp export` file;
2. installed convenience-plugin list/JARs;
3. confirmation of the current inheritance track;
4. confirmation that the users section should be empty.

After those files are supplied, generate the compressed import with no stale user assignments and no wildcard permissions such as `essentials.*`.
